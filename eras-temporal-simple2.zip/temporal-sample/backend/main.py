"""
FastAPI Backend - The Bridge Between Frontend and Temporal

This is a REST API that acts as a middleman:
- Frontend (user) → Backend (this file) → Temporal (workflows)

Think of it like a restaurant:
- Frontend = Customer
- Backend = Waiter (takes orders, brings food)
- Temporal = Kitchen (does the actual cooking)

The backend provides 3 main endpoints:
1. POST /start - Start a new workflow
2. GET /status/{workflow_id} - Check workflow status
3. POST /input - Send user input to workflow
"""

import os  # For reading environment variables
import uuid  # For generating unique workflow IDs
from fastapi import FastAPI, HTTPException  # Web framework for building APIs
from fastapi.middleware.cors import CORSMiddleware  # For allowing frontend to call backend
from pydantic import BaseModel  # For validating request/response data
from temporalio.client import Client, WorkflowExecutionStatus  # Temporal client for talking to workflows


# Create the FastAPI application
# This is like opening a restaurant - we're ready to serve requests
app = FastAPI()

# Enable CORS (Cross-Origin Resource Sharing)
# This allows the frontend (running on port 3000) to call the backend (running on port 8000)
# Without this, browsers would block the requests for security reasons
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow requests from any origin (* means all)
    allow_credentials=True,  # Allow cookies/authentication
    allow_methods=["*"],  # Allow all HTTP methods (GET, POST, etc.)
    allow_headers=["*"],  # Allow all headers
)

# Global variable to store the Temporal client
# We'll initialize this when the server starts up
# 'None' means it hasn't been initialized yet
temporal_client = None


# ===== Data Models (Request/Response Shapes) =====
# These classes define what data looks like going in and out of our API
# Think of them as forms that must be filled out correctly

class StartWorkflowResponse(BaseModel):
    """
    Response when starting a workflow.

    Example:
    {
        "workflow_id": "hello-workflow-123e4567-e89b-12d3-a456-426614174000"
    }
    """
    workflow_id: str  # The unique ID of the workflow we just created


class WorkflowStatusResponse(BaseModel):
    """
    Response when checking workflow status.

    Example:
    {
        "workflow_id": "hello-workflow-...",
        "state": "WAITING_FOR_INPUT",
        "result": null
    }
    """
    workflow_id: str  # The workflow ID
    state: str  # Current state: "STARTING", "WAITING_FOR_INPUT", or "COMPLETED"
    result: str | None = None  # The final result (only set when COMPLETED)


class SendInputRequest(BaseModel):
    """
    Request body when sending input to workflow.

    Example:
    {
        "workflow_id": "hello-workflow-...",
        "message": "Alice"
    }
    """
    workflow_id: str  # Which workflow to send input to
    message: str  # The user's message


class SendInputResponse(BaseModel):
    """
    Response after sending input to workflow.

    Example:
    {
        "workflow_id": "hello-workflow-...",
        "result": "hello world, Alice"
    }
    """
    workflow_id: str  # The workflow ID
    result: str  # The final result from the workflow


@app.on_event("startup")
async def startup_event():
    """
    Runs when the FastAPI server starts up.

    This is like a restaurant opening for the day:
    - Connect to Temporal server
    - Get ready to handle requests

    This runs ONCE when the container starts.
    """
    global temporal_client  # We're going to modify the global variable

    # Get Temporal server address from environment variable
    # In Docker Compose, this is set to "temporal:7233"
    temporal_host = os.getenv("TEMPORAL_HOST", "localhost:7233")

    # Connect to Temporal server
    # This creates a client that can start workflows, send signals, etc.
    temporal_client = await Client.connect(temporal_host)

    print(f"Connected to Temporal at: {temporal_host}")


@app.get("/")
async def root():
    """
    Health check endpoint.

    Returns a simple message to confirm the API is running.
    You can test this with: curl http://localhost:8000/
    """
    return {"message": "Temporal Backend API"}


@app.post("/start", response_model=StartWorkflowResponse)
async def start_workflow():
    """
    ENDPOINT 1: Start a new HelloWorldWorkflow

    This is called when the user clicks "Start Workflow" in the frontend.

    What happens:
    1. Generate a unique workflow ID
    2. Tell Temporal "start HelloWorldWorkflow with this ID"
    3. Temporal puts the workflow on the "hello-tasks" queue
    4. The worker picks it up and starts executing
    5. Return the workflow ID to the frontend

    Returns:
        StartWorkflowResponse: Contains the workflow_id
    """
    try:
        # Generate a unique ID for this workflow
        # Format: "hello-workflow-" + random UUID
        # Example: "hello-workflow-123e4567-e89b-12d3-a456-426614174000"
        workflow_id = f"hello-workflow-{uuid.uuid4()}"

        # Start the workflow!
        # This tells Temporal: "Please run HelloWorldWorkflow"
        # temporal_client.start_workflow() returns a "handle" we can use to:
        # - Check status
        # - Send signals
        # - Get results
        handle = await temporal_client.start_workflow(
            "HelloWorldWorkflow",  # The name of the workflow class
            id=workflow_id,  # The unique ID we generated
            task_queue="hello-tasks",  # Which queue to put it on (must match worker!)
        )

        # Return the workflow ID to the frontend
        # The frontend will use this ID to check status and send input
        return StartWorkflowResponse(workflow_id=handle.id)

    except Exception as e:
        # If something goes wrong, return a 500 error
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/status/{workflow_id}", response_model=WorkflowStatusResponse)
async def get_workflow_status(workflow_id: str):
    """
    ENDPOINT 2: Get the current status of a workflow

    This is called when the user clicks "Refresh Status" in the frontend.

    What happens:
    1. Get a "handle" to the workflow using its ID
    2. Query the workflow: "What's your current state?"
    3. Check if the workflow is completed
    4. Return the state and result (if completed)

    Args:
        workflow_id: The unique ID of the workflow (from the URL path)

    Returns:
        WorkflowStatusResponse: Contains workflow_id, state, and result

    Possible states:
    - "STARTING": Workflow just started, executing the activity
    - "WAITING_FOR_INPUT": Workflow is paused, waiting for user to respond
    - "COMPLETED": Workflow finished
    - "UNKNOWN": Something went wrong
    """
    try:
        # Get a "handle" to the workflow
        # This is like getting a remote control for the workflow
        # We can use it to query, signal, or get results
        handle = temporal_client.get_workflow_handle(workflow_id)

        # Query the workflow's current state
        # This calls the @workflow.query method "current_state" in workflows.py
        # The workflow will respond with "STARTING", "WAITING_FOR_INPUT", or "COMPLETED"
        try:
            state = await handle.query("current_state")
        except Exception:
            # If the query fails, the workflow might not be running anymore
            state = "UNKNOWN"

        # Check if the workflow is completed
        # We need to ask Temporal's server, not the workflow itself
        result = None
        try:
            # describe() gets metadata about the workflow from Temporal
            description = await handle.describe()

            # Check if the workflow's status is COMPLETED
            if description.status == WorkflowExecutionStatus.COMPLETED:
                state = "COMPLETED"

                # Get the final result from the workflow
                # This is what the workflow's run() method returned
                result = await handle.result()
        except Exception:
            # If something goes wrong, just leave result as None
            pass

        # Return the workflow status to the frontend
        return WorkflowStatusResponse(
            workflow_id=workflow_id,
            state=state,
            result=result
        )

    except Exception as e:
        # If something goes wrong, return a 500 error
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/input", response_model=SendInputResponse)
async def send_input(request: SendInputRequest):
    """
    ENDPOINT 3: Send user input to the workflow

    This is called when the user types a message and clicks "Send Input".

    What happens:
    1. Get a handle to the workflow
    2. Send a "signal" (message) to the workflow with the user's input
    3. The workflow receives it in the user_input() method
    4. The wait_condition() unblocks and the workflow continues
    5. Wait for the workflow to finish and return the result

    Args:
        request: Contains workflow_id and message (user's input)

    Returns:
        SendInputResponse: Contains workflow_id and final result

    Example flow:
    - User types "Alice" and clicks "Send Input"
    - We send signal("user_input", "Alice") to the workflow
    - Workflow wakes up, combines "hello world" + "Alice"
    - Returns "hello world, Alice"
    """
    try:
        # Get a handle to the workflow using its ID
        handle = temporal_client.get_workflow_handle(request.workflow_id)

        # Send a signal to the workflow!
        # This calls the @workflow.signal method "user_input" in workflows.py
        # The workflow will:
        # 1. Store the message in self._user_input
        # 2. The wait_condition() will become true
        # 3. Continue execution
        await handle.signal("user_input", request.message)

        # Wait for the workflow to finish and get the result
        # Since we just unblocked the workflow, it should finish quickly
        # The workflow's run() method will return something like "hello world, Alice"
        result = await handle.result()

        # Return the final result to the frontend
        return SendInputResponse(
            workflow_id=request.workflow_id,
            result=result
        )

    except Exception as e:
        # If something goes wrong, return a 500 error
        raise HTTPException(status_code=500, detail=str(e))


# ===== JOB INTERVIEW WORKFLOW ENDPOINTS =====

class StartJobInterviewRequest(BaseModel):
    candidate_name: str
    position: str


class JobInterviewFeedbackRequest(BaseModel):
    workflow_id: str
    approved: bool
    comments: str = ""


@app.post("/job-interview/start")
async def start_job_interview(request: StartJobInterviewRequest):
    """
    Start a new job interview workflow.

    Args:
        request: Contains candidate_name and position

    Returns:
        {"workflow_id": "..."}
    """
    try:
        workflow_id = f"job-interview-{uuid.uuid4()}"

        handle = await temporal_client.start_workflow(
            "JobInterviewWorkflow",
            args=[request.candidate_name, request.position],
            id=workflow_id,
            task_queue="hello-tasks",
        )

        return {"workflow_id": handle.id}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/job-interview/status/{workflow_id}")
async def get_job_interview_status(workflow_id: str):
    """
    Get the current status of a job interview workflow.

    Returns detailed status including:
    - current_stage
    - outcome
    - which feedback has been received
    """
    try:
        handle = temporal_client.get_workflow_handle(workflow_id)

        # Query the workflow status
        try:
            status = await handle.query("get_status")
        except Exception:
            status = {"current_stage": "UNKNOWN"}

        # Check if workflow is completed
        try:
            description = await handle.describe()
            if description.status == WorkflowExecutionStatus.COMPLETED:
                result = await handle.result()
                status["result"] = result
        except Exception:
            pass

        return status

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/job-interview/hr-feedback")
async def send_hr_feedback(request: JobInterviewFeedbackRequest):
    """
    Send HR interview feedback to the workflow.

    Args:
        request: Contains workflow_id, approved, comments
    """
    try:
        handle = temporal_client.get_workflow_handle(request.workflow_id)

        # Send signal with args parameter for multiple arguments
        await handle.signal(
            "hr_feedback",
            args=[request.approved, request.comments if request.comments else ""]
        )

        return {"message": "HR feedback sent"}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/job-interview/tech-feedback")
async def send_tech_feedback(request: JobInterviewFeedbackRequest):
    """
    Send technical interview feedback to the workflow.

    Args:
        request: Contains workflow_id, approved, comments
    """
    try:
        handle = temporal_client.get_workflow_handle(request.workflow_id)

        # Send signal with args parameter for multiple arguments
        await handle.signal(
            "tech_feedback",
            args=[request.approved, request.comments if request.comments else ""]
        )

        return {"message": "Technical feedback sent"}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/job-interview/final-feedback")
async def send_final_feedback(request: JobInterviewFeedbackRequest):
    """
    Send final interview feedback to the workflow.

    Args:
        request: Contains workflow_id, approved, comments
    """
    try:
        handle = temporal_client.get_workflow_handle(request.workflow_id)

        # Send signal with args parameter for multiple arguments
        await handle.signal(
            "final_feedback",
            args=[request.approved, request.comments if request.comments else ""]
        )

        # Wait for workflow to complete
        result = await handle.result()

        return {"message": "Final feedback sent", "result": result}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Standard Python pattern: only run the server if this file is executed directly
if __name__ == "__main__":
    # Import uvicorn (the web server that runs FastAPI)
    import uvicorn

    # Run the FastAPI app
    # host="0.0.0.0" means "accept connections from any IP address"
    # port=8000 means "listen on port 8000"
    uvicorn.run(app, host="0.0.0.0", port=8000)
