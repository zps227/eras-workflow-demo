# Temporal Workflow Demo - Full Stack Docker Compose Project

This project demonstrates a complete Temporal workflow implementation with user interaction, featuring a Next.js frontend, FastAPI backend, Python Temporal worker, and Temporal server with Postgres.

## Architecture

```
┌─────────────┐      ┌─────────────┐      ┌─────────────┐
│   Next.js   │─────▶│   FastAPI   │─────▶│   Temporal  │
│  Frontend   │      │   Backend   │      │   Server    │
│  (port 3000)│      │  (port 8000)│      │  (port 7233)│
└─────────────┘      └─────────────┘      └─────────────┘
                            │                     │
                            │                     │
                            └────────────┬────────┘
                                         │
                                  ┌──────▼──────┐
                                  │   Temporal  │
                                  │   Worker    │
                                  └─────────────┘
```

## Services

1. **Frontend (Next.js)** - Port 3000
   - Interactive UI with "Start Workflow" button
   - Polls backend for workflow status every 2 seconds
   - Shows input field when workflow waits for user input
   - Displays final workflow result

2. **Backend (FastAPI)** - Port 8000
   - `POST /start` - Starts HelloWorldWorkflow, returns workflow_id
   - `GET /status/{workflow_id}` - Queries workflow state (STARTING, WAITING_FOR_INPUT, COMPLETED)
   - `POST /input` - Sends user input signal to workflow, returns final result

3. **Worker (Python Temporal SDK)**
   - HelloWorldWorkflow with:
     - Activity `say_hello()` returns "hello world"
     - Waits for "user_input" signal
     - Returns "hello world, <user_input>"
     - Implements `current_state` query

4. **Temporal Server** - Port 7233 (gRPC), Port 8233 (Web UI)
   - Temporal auto-setup with Postgres backend
   - Web UI for workflow inspection

5. **Postgres** - Port 5432
   - Database for Temporal server

## Project Structure

```
temporal-sample/
├── docker-compose.yml
├── frontend/
│   ├── Dockerfile
│   ├── package.json
│   ├── tsconfig.json
│   ├── next.config.js
│   └── app/
│       ├── page.tsx
│       └── layout.tsx
├── backend/
│   ├── Dockerfile
│   ├── requirements.txt
│   └── main.py
└── worker/
    ├── Dockerfile
    ├── requirements.txt
    ├── worker.py
    ├── workflows.py
    └── activities.py
```

## Getting Started

### Prerequisites

- Docker
- Docker Compose

### Running the Application

1. Navigate to the project directory:
```bash
cd temporal-sample
```

2. Build and start all services:
```bash
docker-compose up --build
```

3. Wait for all services to start (this may take a minute or two)

4. Access the application:
   - **Frontend**: http://localhost:3000
   - **Backend API**: http://localhost:8000
   - **Temporal Web UI**: http://localhost:8233

### Using the Application

1. Open http://localhost:3000 in your browser

2. Click the "Start Workflow" button
   - The workflow will be created and start executing
   - The activity `say_hello()` will execute
   - The workflow status will change to "WAITING_FOR_INPUT"

3. When the status shows "WAITING_FOR_INPUT":
   - A text input field and "Send Input" button will appear
   - Enter your message (e.g., "Alice")
   - Click "Send Input"

4. The workflow will complete and display the result:
   - Final result: "hello world, Alice"

5. Click "Start New Workflow" to try again

### Viewing Workflow History

Open http://localhost:8233 to access the Temporal Web UI where you can:
- See all workflow executions
- View detailed workflow history and events
- Inspect activity executions and signals

## Workflow Details

### HelloWorldWorkflow Behavior

1. **Start**: Workflow begins execution
2. **Activity Execution**: Calls `say_hello()` activity which returns "hello world"
3. **Wait for Signal**: Workflow pauses and waits for "user_input" signal
4. **Signal Received**: User submits input through frontend
5. **Complete**: Workflow returns "hello world, <user_input>"

### State Management

The workflow implements a `current_state` query that returns:
- `STARTING` - Workflow is executing the initial activity
- `WAITING_FOR_INPUT` - Workflow is waiting for user signal
- `COMPLETED` - Workflow has finished

### Task Queue

All workers and workflows use the task queue: `hello-tasks`

## API Endpoints

### POST /start
Starts a new workflow instance.

**Response:**
```json
{
  "workflow_id": "hello-workflow-123e4567-e89b-12d3-a456-426614174000"
}
```

### GET /status/{workflow_id}
Gets the current state of a workflow.

**Response:**
```json
{
  "workflow_id": "hello-workflow-...",
  "state": "WAITING_FOR_INPUT",
  "result": null
}
```

### POST /input
Sends user input to the workflow.

**Request:**
```json
{
  "workflow_id": "hello-workflow-...",
  "message": "Alice"
}
```

**Response:**
```json
{
  "workflow_id": "hello-workflow-...",
  "result": "hello world, Alice"
}
```

## Stopping the Application

Press `Ctrl+C` in the terminal where docker-compose is running, then:

```bash
docker-compose down
```

To remove all data including the Postgres volume:

```bash
docker-compose down -v
```

## Troubleshooting

### Services not starting
- Ensure Docker has enough resources (at least 4GB RAM recommended)
- Check logs: `docker-compose logs -f [service-name]`

### Worker connection issues
- The worker waits for Temporal server to be healthy before starting
- Check Temporal server logs: `docker-compose logs temporal`

### Frontend can't connect to backend
- Ensure backend is running: `docker-compose logs backend`
- Check that port 8000 is not being used by another application

### Workflow not appearing in Temporal Web UI
- Ensure the workflow has been started via the frontend
- Check worker logs: `docker-compose logs worker`
- Verify task queue name matches in worker and backend

## Development

### Modifying the Workflow

To modify the workflow logic, edit `worker/workflows.py` and restart the worker:

```bash
docker-compose restart worker
```

### Modifying the Frontend

Edit files in `frontend/app/` and rebuild:

```bash
docker-compose up --build frontend
```

### Modifying the Backend

Edit `backend/main.py` and restart:

```bash
docker-compose restart backend
```

## Technologies Used

- **Frontend**: Next.js 14, React 18, TypeScript
- **Backend**: FastAPI, Python 3.11
- **Workflow Engine**: Temporal Python SDK 1.5.1
- **Database**: PostgreSQL 13
- **Containerization**: Docker, Docker Compose

## License

This is a demonstration project for educational purposes.
