'use client';

import { useState, useEffect } from 'react';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

type WorkflowState = 'IDLE' | 'STARTING' | 'WAITING_FOR_INPUT' | 'COMPLETED';

export default function Home() {
  const [workflowId, setWorkflowId] = useState<string | null>(null);
  const [state, setState] = useState<WorkflowState>('IDLE');
  const [userInput, setUserInput] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Function to refresh workflow status
  const refreshStatus = async () => {
    if (!workflowId) return;

    setError(null);

    try {
      const response = await fetch(`${API_URL}/status/${workflowId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch workflow status');
      }

      const data = await response.json();
      setState(data.state as WorkflowState);

      if (data.state === 'COMPLETED' && data.result) {
        setResult(data.result);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      console.error('Error refreshing workflow status:', err);
    }
  };

  const startWorkflow = async () => {
    setError(null);
    setLoading(true);
    setResult(null);

    try {
      const response = await fetch(`${API_URL}/start`, {
        method: 'POST',
      });

      if (!response.ok) {
        throw new Error('Failed to start workflow');
      }

      const data = await response.json();
      setWorkflowId(data.workflow_id);
      setState('STARTING');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  const sendInput = async () => {
    if (!workflowId || !userInput.trim()) return;

    setError(null);
    setLoading(true);

    try {
      const response = await fetch(`${API_URL}/input`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          workflow_id: workflowId,
          message: userInput.trim(),
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to send input');
      }

      const data = await response.json();
      setResult(data.result);
      setState('COMPLETED');
      setUserInput('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setWorkflowId(null);
    setState('IDLE');
    setUserInput('');
    setResult(null);
    setError(null);
  };

  return (
    <main style={styles.main}>
      <div style={styles.container}>
        <h1 style={styles.title}>Temporal Workflow Demo</h1>

        {error && (
          <div style={styles.error}>
            Error: {error}
          </div>
        )}

        {state === 'IDLE' && (
          <div style={styles.section}>
            <button
              onClick={startWorkflow}
              disabled={loading}
              style={styles.button}
            >
              {loading ? 'Starting...' : 'Start Workflow'}
            </button>
          </div>
        )}

        {workflowId && state !== 'COMPLETED' && (
          <div style={styles.section}>
            <p style={styles.info}>
              <strong>Workflow ID:</strong> {workflowId}
            </p>
            <p style={styles.info}>
              <strong>Status:</strong> {state}
            </p>
            <button
              onClick={refreshStatus}
              style={styles.refreshButton}
            >
              Refresh Status
            </button>
          </div>
        )}

        {state === 'WAITING_FOR_INPUT' && (
          <div style={styles.section}>
            <h2 style={styles.subtitle}>Workflow is waiting for your input</h2>
            <input
              type="text"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              placeholder="Enter your message"
              style={styles.input}
              onKeyPress={(e) => {
                if (e.key === 'Enter' && !loading) {
                  sendInput();
                }
              }}
            />
            <button
              onClick={sendInput}
              disabled={loading || !userInput.trim()}
              style={styles.button}
            >
              {loading ? 'Sending...' : 'Send Input'}
            </button>
          </div>
        )}

        {result && (
          <div style={styles.section}>
            <h2 style={styles.subtitle}>Final Result</h2>
            <div style={styles.result}>
              {result}
            </div>
            <button onClick={reset} style={styles.button}>
              Start New Workflow
            </button>
          </div>
        )}

        <div style={styles.footer}>
          <p>
            <a href="/job-interview" style={styles.link}>Try the Complex Job Interview Workflow →</a>
          </p>
          <p>Temporal Web UI available at: <a href="http://localhost:8233" target="_blank" rel="noopener noreferrer" style={styles.link}>http://localhost:8233</a></p>
        </div>
      </div>
    </main>
  );
}

const styles: { [key: string]: React.CSSProperties } = {
  main: {
    minHeight: '100vh',
    padding: '2rem',
    backgroundColor: '#f5f5f5',
  },
  container: {
    maxWidth: '600px',
    margin: '0 auto',
    backgroundColor: 'white',
    padding: '2rem',
    borderRadius: '8px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
  },
  title: {
    fontSize: '2rem',
    fontWeight: 'bold',
    marginBottom: '1.5rem',
    textAlign: 'center',
    color: '#333',
  },
  subtitle: {
    fontSize: '1.25rem',
    fontWeight: '600',
    marginBottom: '1rem',
    color: '#555',
  },
  section: {
    marginBottom: '2rem',
  },
  button: {
    backgroundColor: '#0070f3',
    color: 'white',
    padding: '0.75rem 1.5rem',
    border: 'none',
    borderRadius: '4px',
    fontSize: '1rem',
    cursor: 'pointer',
    width: '100%',
    transition: 'background-color 0.2s',
  },
  refreshButton: {
    backgroundColor: '#6c757d',
    color: 'white',
    padding: '0.5rem 1rem',
    border: 'none',
    borderRadius: '4px',
    fontSize: '0.875rem',
    cursor: 'pointer',
    width: '100%',
    marginTop: '0.5rem',
    transition: 'background-color 0.2s',
  },
  input: {
    width: '100%',
    padding: '0.75rem',
    border: '1px solid #ddd',
    borderRadius: '4px',
    fontSize: '1rem',
    marginBottom: '1rem',
    boxSizing: 'border-box',
  },
  info: {
    margin: '0.5rem 0',
    color: '#666',
  },
  result: {
    backgroundColor: '#e8f5e9',
    padding: '1rem',
    borderRadius: '4px',
    marginBottom: '1rem',
    fontSize: '1.125rem',
    fontWeight: '500',
    color: '#2e7d32',
  },
  error: {
    backgroundColor: '#ffebee',
    color: '#c62828',
    padding: '1rem',
    borderRadius: '4px',
    marginBottom: '1rem',
  },
  footer: {
    marginTop: '2rem',
    paddingTop: '1rem',
    borderTop: '1px solid #ddd',
    textAlign: 'center',
    color: '#666',
    fontSize: '0.875rem',
  },
  link: {
    color: '#0070f3',
    textDecoration: 'none',
  },
};
