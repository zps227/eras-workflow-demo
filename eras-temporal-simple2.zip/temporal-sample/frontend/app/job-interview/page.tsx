'use client';

import { useState, useEffect } from 'react';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

/**
 * Job Interview Workflow Frontend
 *
 * This page demonstrates a complex multi-stage workflow with:
 * - Branching logic (rejection at any stage ends the workflow)
 * - Multiple human-in-the-loop decision points
 * - Progress tracking and visual feedback
 * - Stage-specific input forms
 */

// Type definitions for workflow status
type InterviewStage =
  | 'RESUME_SCREENING'
  | 'HR_INTERVIEW'
  | 'TECH_INTERVIEW'
  | 'FINAL_INTERVIEW'
  | 'COMPLETED';

type Outcome = 'HIRED' | 'REJECTED' | null;

interface WorkflowStatus {
  current_stage: InterviewStage;
  outcome: Outcome;
  hr_feedback_received: boolean;
  tech_feedback_received: boolean;
  final_feedback_received: boolean;
  rejection_stage: string | null;
  rejection_reason: string | null;
  result?: {
    candidate_name: string;
    position: string;
    outcome: string;
    rejection_stage: string | null;
    rejection_reason: string | null;
  };
}

export default function JobInterviewPage() {
  // Form state for starting workflow
  const [candidateName, setCandidateName] = useState('');
  const [position, setPosition] = useState('');

  // Workflow state
  const [workflowId, setWorkflowId] = useState<string | null>(null);
  const [status, setStatus] = useState<WorkflowStatus | null>(null);

  // Feedback form state
  const [approved, setApproved] = useState<boolean>(true);
  const [comments, setComments] = useState('');

  // UI state
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Start a new job interview workflow
  const startWorkflow = async () => {
    if (!candidateName.trim() || !position.trim()) {
      setError('Please enter candidate name and position');
      return;
    }

    setError(null);
    setLoading(true);

    try {
      const response = await fetch(`${API_URL}/job-interview/start`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          candidate_name: candidateName.trim(),
          position: position.trim(),
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to start workflow');
      }

      const data = await response.json();
      setWorkflowId(data.workflow_id);

      // Immediately fetch status
      setTimeout(() => refreshStatus(data.workflow_id), 500);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  // Refresh workflow status
  const refreshStatus = async (wfId?: string) => {
    const id = wfId || workflowId;
    if (!id) return;

    setError(null);

    try {
      const response = await fetch(`${API_URL}/job-interview/status/${id}`);
      if (!response.ok) {
        throw new Error('Failed to fetch workflow status');
      }

      const data = await response.json();
      setStatus(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
      console.error('Error refreshing workflow status:', err);
    }
  };

  // Send HR feedback
  const sendHRFeedback = async () => {
    if (!workflowId) return;

    setError(null);
    setLoading(true);

    try {
      const response = await fetch(`${API_URL}/job-interview/hr-feedback`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          workflow_id: workflowId,
          approved,
          comments: comments.trim(),
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to send HR feedback');
      }

      // Reset form
      setApproved(true);
      setComments('');

      // Refresh status after a short delay
      setTimeout(() => refreshStatus(), 500);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  // Send Technical feedback
  const sendTechFeedback = async () => {
    if (!workflowId) return;

    setError(null);
    setLoading(true);

    try {
      const response = await fetch(`${API_URL}/job-interview/tech-feedback`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          workflow_id: workflowId,
          approved,
          comments: comments.trim(),
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to send technical feedback');
      }

      // Reset form
      setApproved(true);
      setComments('');

      // Refresh status after a short delay
      setTimeout(() => refreshStatus(), 500);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  // Send Final feedback
  const sendFinalFeedback = async () => {
    if (!workflowId) return;

    setError(null);
    setLoading(true);

    try {
      const response = await fetch(`${API_URL}/job-interview/final-feedback`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          workflow_id: workflowId,
          approved,
          comments: comments.trim(),
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to send final feedback');
      }

      // Reset form
      setApproved(true);
      setComments('');

      // Refresh status after a short delay
      setTimeout(() => refreshStatus(), 500);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  // Reset to start a new workflow
  const reset = () => {
    setWorkflowId(null);
    setStatus(null);
    setCandidateName('');
    setPosition('');
    setApproved(true);
    setComments('');
    setError(null);
  };

  // Get progress percentage based on current stage
  const getProgressPercentage = (): number => {
    if (!status) return 0;

    switch (status.current_stage) {
      case 'RESUME_SCREENING': return 20;
      case 'HR_INTERVIEW': return 40;
      case 'TECH_INTERVIEW': return 60;
      case 'FINAL_INTERVIEW': return 80;
      case 'COMPLETED': return 100;
      default: return 0;
    }
  };

  // Get human-readable stage name
  const getStageName = (stage: InterviewStage): string => {
    switch (stage) {
      case 'RESUME_SCREENING': return 'Resume Screening';
      case 'HR_INTERVIEW': return 'HR Interview';
      case 'TECH_INTERVIEW': return 'Technical Interview';
      case 'FINAL_INTERVIEW': return 'Final Interview';
      case 'COMPLETED': return 'Completed';
      default: return stage;
    }
  };

  return (
    <main style={styles.main}>
      <div style={styles.container}>
        <h1 style={styles.title}>Job Interview Workflow</h1>
        <p style={styles.description}>
          Multi-stage interview process with automatic screening and human decision points
        </p>

        {error && (
          <div style={styles.error}>
            Error: {error}
          </div>
        )}

        {/* START WORKFLOW FORM */}
        {!workflowId && (
          <div style={styles.section}>
            <h2 style={styles.subtitle}>Start New Interview Process</h2>

            <div style={styles.formGroup}>
              <label style={styles.label}>Candidate Name</label>
              <input
                type="text"
                value={candidateName}
                onChange={(e) => setCandidateName(e.target.value)}
                placeholder="e.g., Jane Smith"
                style={styles.input}
              />
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>Position</label>
              <input
                type="text"
                value={position}
                onChange={(e) => setPosition(e.target.value)}
                placeholder="e.g., Senior Software Engineer"
                style={styles.input}
              />
            </div>

            <button
              onClick={startWorkflow}
              disabled={loading}
              style={styles.button}
            >
              {loading ? 'Starting...' : 'Start Interview Process'}
            </button>
          </div>
        )}

        {/* WORKFLOW STATUS AND PROGRESS */}
        {workflowId && status && (
          <>
            <div style={styles.section}>
              <p style={styles.info}>
                <strong>Workflow ID:</strong> {workflowId}
              </p>
              <p style={styles.info}>
                <strong>Current Stage:</strong> {getStageName(status.current_stage)}
              </p>

              {/* Progress Bar */}
              <div style={styles.progressContainer}>
                <div
                  style={{
                    ...styles.progressBar,
                    width: `${getProgressPercentage()}%`,
                  }}
                />
              </div>
              <p style={styles.progressText}>{getProgressPercentage()}% Complete</p>

              <button
                onClick={() => refreshStatus()}
                style={styles.refreshButton}
              >
                Refresh Status
              </button>
            </div>

            {/* STAGE-SPECIFIC FEEDBACK FORMS */}
            {status.current_stage === 'RESUME_SCREENING' && (
              <div style={styles.section}>
                <div style={styles.infoBox}>
                  <p style={styles.infoBoxText}>
                    ⏳ Resume is being automatically screened...
                  </p>
                  <p style={styles.infoBoxSubtext}>
                    This happens automatically. Click &quot;Refresh Status&quot; to check progress.
                  </p>
                </div>
              </div>
            )}

            {status.current_stage === 'HR_INTERVIEW' && !status.hr_feedback_received && (
              <div style={styles.section}>
                <h2 style={styles.subtitle}>HR Interview Feedback</h2>
                <p style={styles.stageDescription}>
                  The HR interview has been scheduled. Please provide your feedback.
                </p>

                <div style={styles.formGroup}>
                  <label style={styles.label}>Decision</label>
                  <div style={styles.radioGroup}>
                    <label style={styles.radioLabel}>
                      <input
                        type="radio"
                        checked={approved}
                        onChange={() => setApproved(true)}
                        style={styles.radio}
                      />
                      Approve
                    </label>
                    <label style={styles.radioLabel}>
                      <input
                        type="radio"
                        checked={!approved}
                        onChange={() => setApproved(false)}
                        style={styles.radio}
                      />
                      Reject
                    </label>
                  </div>
                </div>

                <div style={styles.formGroup}>
                  <label style={styles.label}>Comments (Optional)</label>
                  <textarea
                    value={comments}
                    onChange={(e) => setComments(e.target.value)}
                    placeholder="Add any feedback or notes..."
                    style={styles.textarea}
                    rows={3}
                  />
                </div>

                <button
                  onClick={sendHRFeedback}
                  disabled={loading}
                  style={styles.button}
                >
                  {loading ? 'Submitting...' : 'Submit HR Feedback'}
                </button>
              </div>
            )}

            {status.current_stage === 'TECH_INTERVIEW' && !status.tech_feedback_received && (
              <div style={styles.section}>
                <h2 style={styles.subtitle}>Technical Interview Feedback</h2>
                <p style={styles.stageDescription}>
                  The technical interview has been scheduled. Please provide your feedback.
                </p>

                <div style={styles.formGroup}>
                  <label style={styles.label}>Decision</label>
                  <div style={styles.radioGroup}>
                    <label style={styles.radioLabel}>
                      <input
                        type="radio"
                        checked={approved}
                        onChange={() => setApproved(true)}
                        style={styles.radio}
                      />
                      Approve
                    </label>
                    <label style={styles.radioLabel}>
                      <input
                        type="radio"
                        checked={!approved}
                        onChange={() => setApproved(false)}
                        style={styles.radio}
                      />
                      Reject
                    </label>
                  </div>
                </div>

                <div style={styles.formGroup}>
                  <label style={styles.label}>Comments (Optional)</label>
                  <textarea
                    value={comments}
                    onChange={(e) => setComments(e.target.value)}
                    placeholder="Add any feedback or notes..."
                    style={styles.textarea}
                    rows={3}
                  />
                </div>

                <button
                  onClick={sendTechFeedback}
                  disabled={loading}
                  style={styles.button}
                >
                  {loading ? 'Submitting...' : 'Submit Technical Feedback'}
                </button>
              </div>
            )}

            {status.current_stage === 'FINAL_INTERVIEW' && !status.final_feedback_received && (
              <div style={styles.section}>
                <h2 style={styles.subtitle}>Final Interview Feedback</h2>
                <p style={styles.stageDescription}>
                  The final interview has been scheduled. Please provide your decision.
                </p>

                <div style={styles.formGroup}>
                  <label style={styles.label}>Decision</label>
                  <div style={styles.radioGroup}>
                    <label style={styles.radioLabel}>
                      <input
                        type="radio"
                        checked={approved}
                        onChange={() => setApproved(true)}
                        style={styles.radio}
                      />
                      Extend Offer
                    </label>
                    <label style={styles.radioLabel}>
                      <input
                        type="radio"
                        checked={!approved}
                        onChange={() => setApproved(false)}
                        style={styles.radio}
                      />
                      Do Not Extend Offer
                    </label>
                  </div>
                </div>

                <div style={styles.formGroup}>
                  <label style={styles.label}>Comments (Optional)</label>
                  <textarea
                    value={comments}
                    onChange={(e) => setComments(e.target.value)}
                    placeholder="Add any feedback or notes..."
                    style={styles.textarea}
                    rows={3}
                  />
                </div>

                <button
                  onClick={sendFinalFeedback}
                  disabled={loading}
                  style={styles.button}
                >
                  {loading ? 'Submitting...' : 'Submit Final Decision'}
                </button>
              </div>
            )}

            {/* FINAL OUTCOME */}
            {status.current_stage === 'COMPLETED' && status.result && (
              <div style={styles.section}>
                <h2 style={styles.subtitle}>Interview Process Complete</h2>

                {status.result.outcome === 'HIRED' ? (
                  <div style={styles.successBox}>
                    <div style={styles.outcomeIcon}>🎉</div>
                    <h3 style={styles.outcomeTitle}>Candidate Hired!</h3>
                    <p style={styles.outcomeText}>
                      <strong>{status.result.candidate_name}</strong> has been offered the position of <strong>{status.result.position}</strong>.
                    </p>
                    <p style={styles.outcomeSubtext}>
                      An offer letter has been sent to the candidate.
                    </p>
                  </div>
                ) : (
                  <div style={styles.rejectionBox}>
                    <div style={styles.outcomeIcon}>❌</div>
                    <h3 style={styles.outcomeTitle}>Candidate Not Selected</h3>
                    <p style={styles.outcomeText}>
                      <strong>{status.result.candidate_name}</strong> was not selected for the <strong>{status.result.position}</strong> position.
                    </p>
                    {status.result.rejection_stage && (
                      <p style={styles.outcomeSubtext}>
                        <strong>Rejected at:</strong> {status.result.rejection_stage}
                      </p>
                    )}
                    {status.result.rejection_reason && (
                      <p style={styles.outcomeSubtext}>
                        <strong>Reason:</strong> {status.result.rejection_reason}
                      </p>
                    )}
                  </div>
                )}

                <button onClick={reset} style={styles.button}>
                  Start New Interview Process
                </button>
              </div>
            )}
          </>
        )}

        <div style={styles.footer}>
          <p>
            <a href="/" style={styles.link}>← Back to Simple Workflow</a>
          </p>
          <p>
            Temporal Web UI: <a href="http://localhost:8233" target="_blank" rel="noopener noreferrer" style={styles.link}>http://localhost:8233</a>
          </p>
        </div>
      </div>
    </main>
  );
}

const styles: { [key: string]: React.CSSProperties } = {
  main: {
    minHeight: '100vh',
    padding: '2rem',
    backgroundColor: '#f5f5f5',
  },
  container: {
    maxWidth: '700px',
    margin: '0 auto',
    backgroundColor: 'white',
    padding: '2rem',
    borderRadius: '8px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
  },
  title: {
    fontSize: '2rem',
    fontWeight: 'bold',
    marginBottom: '0.5rem',
    textAlign: 'center',
    color: '#333',
  },
  description: {
    textAlign: 'center',
    color: '#666',
    marginBottom: '2rem',
    fontSize: '0.9rem',
  },
  subtitle: {
    fontSize: '1.25rem',
    fontWeight: '600',
    marginBottom: '1rem',
    color: '#555',
  },
  stageDescription: {
    color: '#666',
    marginBottom: '1.5rem',
    fontSize: '0.95rem',
  },
  section: {
    marginBottom: '2rem',
  },
  formGroup: {
    marginBottom: '1.5rem',
  },
  label: {
    display: 'block',
    marginBottom: '0.5rem',
    fontWeight: '500',
    color: '#444',
    fontSize: '0.95rem',
  },
  input: {
    width: '100%',
    padding: '0.75rem',
    border: '1px solid #ddd',
    borderRadius: '4px',
    fontSize: '1rem',
    boxSizing: 'border-box',
  },
  textarea: {
    width: '100%',
    padding: '0.75rem',
    border: '1px solid #ddd',
    borderRadius: '4px',
    fontSize: '1rem',
    boxSizing: 'border-box',
    fontFamily: 'inherit',
    resize: 'vertical',
  },
  radioGroup: {
    display: 'flex',
    gap: '1.5rem',
  },
  radioLabel: {
    display: 'flex',
    alignItems: 'center',
    cursor: 'pointer',
    fontSize: '0.95rem',
  },
  radio: {
    marginRight: '0.5rem',
    cursor: 'pointer',
  },
  button: {
    backgroundColor: '#0070f3',
    color: 'white',
    padding: '0.75rem 1.5rem',
    border: 'none',
    borderRadius: '4px',
    fontSize: '1rem',
    cursor: 'pointer',
    width: '100%',
    transition: 'background-color 0.2s',
  },
  refreshButton: {
    backgroundColor: '#6c757d',
    color: 'white',
    padding: '0.5rem 1rem',
    border: 'none',
    borderRadius: '4px',
    fontSize: '0.875rem',
    cursor: 'pointer',
    width: '100%',
    marginTop: '0.5rem',
    transition: 'background-color 0.2s',
  },
  info: {
    margin: '0.5rem 0',
    color: '#666',
    fontSize: '0.95rem',
  },
  progressContainer: {
    width: '100%',
    height: '8px',
    backgroundColor: '#e0e0e0',
    borderRadius: '4px',
    overflow: 'hidden',
    marginTop: '1rem',
  },
  progressBar: {
    height: '100%',
    backgroundColor: '#0070f3',
    transition: 'width 0.3s ease',
  },
  progressText: {
    textAlign: 'center',
    marginTop: '0.5rem',
    fontSize: '0.875rem',
    color: '#666',
  },
  infoBox: {
    backgroundColor: '#e3f2fd',
    padding: '1.5rem',
    borderRadius: '4px',
    borderLeft: '4px solid #2196f3',
  },
  infoBoxText: {
    margin: '0 0 0.5rem 0',
    color: '#1565c0',
    fontWeight: '500',
    fontSize: '1rem',
  },
  infoBoxSubtext: {
    margin: 0,
    color: '#1976d2',
    fontSize: '0.875rem',
  },
  successBox: {
    backgroundColor: '#e8f5e9',
    padding: '2rem',
    borderRadius: '8px',
    textAlign: 'center',
    marginBottom: '1.5rem',
  },
  rejectionBox: {
    backgroundColor: '#ffebee',
    padding: '2rem',
    borderRadius: '8px',
    textAlign: 'center',
    marginBottom: '1.5rem',
  },
  outcomeIcon: {
    fontSize: '3rem',
    marginBottom: '1rem',
  },
  outcomeTitle: {
    fontSize: '1.5rem',
    fontWeight: 'bold',
    marginBottom: '1rem',
    color: '#333',
  },
  outcomeText: {
    fontSize: '1rem',
    marginBottom: '0.5rem',
    color: '#555',
  },
  outcomeSubtext: {
    fontSize: '0.9rem',
    color: '#666',
    marginTop: '0.5rem',
  },
  error: {
    backgroundColor: '#ffebee',
    color: '#c62828',
    padding: '1rem',
    borderRadius: '4px',
    marginBottom: '1rem',
  },
  footer: {
    marginTop: '2rem',
    paddingTop: '1rem',
    borderTop: '1px solid #ddd',
    textAlign: 'center',
    color: '#666',
    fontSize: '0.875rem',
  },
  link: {
    color: '#0070f3',
    textDecoration: 'none',
  },
};
