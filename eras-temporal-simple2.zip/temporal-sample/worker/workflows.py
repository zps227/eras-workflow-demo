"""
Temporal Workflows - The "Orchestrator" of Your Business Logic

A workflow is like a recipe or a script that coordinates activities.
It's the "brain" that decides what to do and when.

Key Concepts:
1. WORKFLOWS = Coordination (decide what to do, when, and in what order)
2. ACTIVITIES = Execution (do the actual work)

Why Workflows?
- Durable: If the worker crashes, the workflow continues from where it left off
- Reliable: Temporal tracks every step and can replay the workflow if needed
- Long-running: Can wait for hours, days, or months (like waiting for user input)
- Observable: You can query the current state at any time

Magic of Temporal Workflows:
- They can be paused and resumed
- They survive server restarts
- They can wait for external events (like user input)
- All history is stored and can be replayed
"""

from datetime import timedelta  # For specifying time durations
from temporalio import workflow  # Core workflow decorators and functions
from temporalio.common import RetryPolicy  # For configuring retry behavior

# Special Temporal import pattern for activities
# This tells Temporal to pass through imports during workflow replay
# Think of it as: "These imports are safe and won't change behavior"
with workflow.unsafe.imports_passed_through():
    from activities import (
        say_hello,
        screen_resume,
        schedule_hr_interview,
        schedule_technical_interview,
        schedule_final_interview,
        send_offer,
        send_rejection,
    )


# @workflow.defn marks this class as a Temporal workflow
# It's like registering your recipe in a cookbook
@workflow.defn
class HelloWorldWorkflow:
    """
    A workflow that demonstrates the core Temporal features:
    1. Executing an activity
    2. Waiting for a signal (user input)
    3. Querying workflow state

    Think of this as a multi-step process:
    Step 1: Say hello (via activity)
    Step 2: Wait for user to respond
    Step 3: Combine hello message with user's response
    """

    def __init__(self) -> None:
        """
        Constructor - Initialize workflow state.

        In Temporal, workflow state is stored in memory and replayed when needed.
        These variables will survive workflow restarts!

        Note: All workflow state must be deterministic (same inputs = same outputs)
        """
        self._current_state = "STARTING"  # Track what stage we're in
        self._user_input = None  # Store user's message when they send it
        self._result = None  # Store the final result

    @workflow.run
    async def run(self) -> str:
        """
        The main workflow execution method.

        This is what runs when the workflow starts.
        Think of it as the main() function of your workflow.

        Returns:
            str: The final result combining "hello world" with user input

        Flow:
        1. Start → Execute activity → Get "hello world"
        2. Wait for user to send input
        3. Combine results and finish
        """

        # STEP 1: Execute the say_hello activity
        # ========================================
        self._current_state = "STARTING"

        # workflow.execute_activity() runs an activity and waits for its result
        # This is like calling a function, but with superpowers:
        # - If the activity fails, it can retry automatically
        # - The result is stored in Temporal's history
        # - If the worker crashes, it will resume from here
        hello_msg = await workflow.execute_activity(
            say_hello,  # Which activity to run
            start_to_close_timeout=timedelta(seconds=10),  # Max time for activity to complete
            retry_policy=RetryPolicy(maximum_attempts=3),  # Try up to 3 times if it fails
        )
        # After this line, hello_msg = "hello world"

        # STEP 2: Wait for user input signal
        # ====================================
        self._current_state = "WAITING_FOR_INPUT"

        # workflow.wait_condition() pauses the workflow until a condition is true
        # This is AMAZING: The workflow can wait for days or months!
        # The worker doesn't stay busy - Temporal just remembers we're waiting
        # When the signal arrives (user_input method below), the condition becomes true
        await workflow.wait_condition(lambda: self._user_input is not None)
        # The lambda checks: "Is self._user_input set yet?"
        # When user_input() is called (via signal), this will unblock

        # STEP 3: Combine results and finish
        # ====================================
        self._current_state = "COMPLETED"

        # Combine the activity result with the user's input
        # Example: "hello world" + "Alice" = "hello world, Alice"
        self._result = f"{hello_msg}, {self._user_input}"

        # Return the final result
        # This marks the workflow as complete
        return self._result

    @workflow.signal
    async def user_input(self, message: str) -> None:
        """
        Signal handler - Receives external input while workflow is running.

        SIGNALS are how you send data TO a running workflow.
        Think of it like sending a text message to the workflow.

        In this case:
        - The frontend calls the backend
        - The backend sends this signal to the workflow
        - The workflow receives it here and stores it
        - The wait_condition() in run() unblocks and continues

        Args:
            message: The user's input text (e.g., "Alice")

        Note: Signals are asynchronous - they don't return values
        They just update the workflow's state
        """
        # Store the user's message
        # This will make the wait_condition() in run() become true
        self._user_input = message

    @workflow.query
    def current_state(self) -> str:
        """
        Query handler - Read workflow state without changing it.

        QUERIES are how you get data FROM a running workflow.
        Think of it like asking "What's your current status?"

        The backend calls this to check if the workflow is:
        - "STARTING" - Just started, running the activity
        - "WAITING_FOR_INPUT" - Paused, waiting for user to respond
        - "COMPLETED" - Finished

        Returns:
            str: Current state of the workflow

        Note: Queries are read-only - they can't change workflow state
        They're safe to call any time
        """
        return self._current_state


# ===== JOB INTERVIEW WORKFLOW =====
# A complex workflow with branching logic and multiple stages


@workflow.defn
class JobInterviewWorkflow:
    """
    Multi-stage job interview workflow with branching logic.

    This demonstrates a real-world use case: hiring pipeline.

    Workflow Stages:
    1. Resume Screening (automatic) → approve/reject
    2. HR Interview (wait for feedback) → approve/reject
    3. Technical Interview (wait for feedback) → approve/reject
    4. Final Interview (wait for feedback) → approve/reject
    5. Send offer OR Send rejection

    Key Features:
    - Branching logic: If rejected at any stage, workflow ends
    - Multiple human-in-the-loop decision points
    - State tracking so UI knows which stage we're at
    - Detailed progress information via queries
    """

    def __init__(self) -> None:
        """
        Initialize the job interview workflow state.

        We track:
        - Current stage (which step are we at?)
        - Feedback from each interview (what did they say?)
        - Final outcome (hired or rejected?)
        - Why they were rejected (if applicable)
        """
        # Current stage: RESUME_SCREENING, HR_INTERVIEW, TECH_INTERVIEW, FINAL_INTERVIEW, COMPLETED
        self._current_stage = "RESUME_SCREENING"

        # Store feedback from each stage
        self._hr_feedback = None
        self._tech_feedback = None
        self._final_feedback = None

        # Final outcome
        self._outcome = None  # "HIRED" or "REJECTED"
        self._rejection_stage = None  # Which stage did we reject at?
        self._rejection_reason = None  # Why were they rejected?

    @workflow.run
    async def run(self, candidate_name: str, position: str) -> dict:
        """
        Main workflow execution for the job interview process.

        Args:
            candidate_name: Name of the candidate
            position: Job position they're applying for

        Returns:
            dict: Final outcome with details

        Flow:
        1. Screen resume automatically
        2. If passed → schedule HR interview, wait for feedback
        3. If passed → schedule technical interview, wait for feedback
        4. If passed → schedule final interview, wait for feedback
        5. If passed → send job offer
        6. If rejected at any stage → send rejection and end
        """

        # ========================================
        # STAGE 1: RESUME SCREENING (Automatic)
        # ========================================
        self._current_stage = "RESUME_SCREENING"

        # Execute the resume screening activity
        # This is automatic - no human input needed
        screening_result = await workflow.execute_activity(
            screen_resume,
            args=[candidate_name],
            start_to_close_timeout=timedelta(seconds=10),
            retry_policy=RetryPolicy(maximum_attempts=3),
        )

        # Check if resume was rejected
        if not screening_result["approved"]:
            # REJECTION PATH: Resume didn't pass
            self._outcome = "REJECTED"
            self._rejection_stage = "RESUME_SCREENING"
            self._rejection_reason = screening_result["reason"]

            # Send rejection email
            await workflow.execute_activity(
                send_rejection,
                args=[candidate_name, "Resume Screening", screening_result["reason"]],
                start_to_close_timeout=timedelta(seconds=10),
            )

            self._current_stage = "COMPLETED"
            return self._build_result(candidate_name, position)

        # ========================================
        # STAGE 2: HR INTERVIEW
        # ========================================
        self._current_stage = "HR_INTERVIEW"

        # Schedule the HR interview (activity)
        await workflow.execute_activity(
            schedule_hr_interview,
            args=[candidate_name],
            start_to_close_timeout=timedelta(seconds=10),
        )

        # Wait for HR feedback signal from human
        # Workflow PAUSES here until HR provides feedback
        await workflow.wait_condition(lambda: self._hr_feedback is not None)

        # Check if HR approved
        if not self._hr_feedback["approved"]:
            # REJECTION PATH: HR rejected
            self._outcome = "REJECTED"
            self._rejection_stage = "HR_INTERVIEW"
            self._rejection_reason = self._hr_feedback.get("comments", "Did not meet HR requirements")

            await workflow.execute_activity(
                send_rejection,
                args=[candidate_name, "HR Interview", self._rejection_reason],
                start_to_close_timeout=timedelta(seconds=10),
            )

            self._current_stage = "COMPLETED"
            return self._build_result(candidate_name, position)

        # ========================================
        # STAGE 3: TECHNICAL INTERVIEW
        # ========================================
        self._current_stage = "TECH_INTERVIEW"

        # Schedule the technical interview
        await workflow.execute_activity(
            schedule_technical_interview,
            args=[candidate_name],
            start_to_close_timeout=timedelta(seconds=10),
        )

        # Wait for technical team feedback
        await workflow.wait_condition(lambda: self._tech_feedback is not None)

        # Check if tech team approved
        if not self._tech_feedback["approved"]:
            # REJECTION PATH: Tech interview failed
            self._outcome = "REJECTED"
            self._rejection_stage = "TECH_INTERVIEW"
            self._rejection_reason = self._tech_feedback.get("comments", "Did not meet technical requirements")

            await workflow.execute_activity(
                send_rejection,
                args=[candidate_name, "Technical Interview", self._rejection_reason],
                start_to_close_timeout=timedelta(seconds=10),
            )

            self._current_stage = "COMPLETED"
            return self._build_result(candidate_name, position)

        # ========================================
        # STAGE 4: FINAL INTERVIEW
        # ========================================
        self._current_stage = "FINAL_INTERVIEW"

        # Schedule final interview with leadership
        await workflow.execute_activity(
            schedule_final_interview,
            args=[candidate_name],
            start_to_close_timeout=timedelta(seconds=10),
        )

        # Wait for final decision
        await workflow.wait_condition(lambda: self._final_feedback is not None)

        # Check final decision
        if not self._final_feedback["approved"]:
            # REJECTION PATH: Final interview - no offer
            self._outcome = "REJECTED"
            self._rejection_stage = "FINAL_INTERVIEW"
            self._rejection_reason = self._final_feedback.get("comments", "Not selected for final offer")

            await workflow.execute_activity(
                send_rejection,
                args=[candidate_name, "Final Interview", self._rejection_reason],
                start_to_close_timeout=timedelta(seconds=10),
            )

            self._current_stage = "COMPLETED"
            return self._build_result(candidate_name, position)

        # ========================================
        # SUCCESS PATH: SEND OFFER!
        # ========================================
        self._outcome = "HIRED"

        # Send job offer
        await workflow.execute_activity(
            send_offer,
            args=[candidate_name, position],
            start_to_close_timeout=timedelta(seconds=10),
        )

        self._current_stage = "COMPLETED"
        return self._build_result(candidate_name, position)

    def _build_result(self, candidate_name: str, position: str) -> dict:
        """
        Helper method to build the final result dictionary.

        This is deterministic (always produces same output for same inputs),
        so it's safe to use in a workflow.
        """
        return {
            "candidate_name": candidate_name,
            "position": position,
            "outcome": self._outcome,
            "rejection_stage": self._rejection_stage,
            "rejection_reason": self._rejection_reason,
            "hr_feedback": self._hr_feedback,
            "tech_feedback": self._tech_feedback,
            "final_feedback": self._final_feedback,
        }

    # ===== SIGNAL HANDLERS =====
    # These receive feedback from HR, tech team, and leadership

    @workflow.signal
    async def hr_feedback(self, approved: bool, comments: str = "") -> None:
        """
        Signal: HR provides interview feedback.

        Args:
            approved: True if HR approves, False to reject
            comments: Optional feedback/notes
        """
        self._hr_feedback = {
            "approved": approved,
            "comments": comments
        }

    @workflow.signal
    async def tech_feedback(self, approved: bool, comments: str = "") -> None:
        """
        Signal: Technical team provides interview feedback.

        Args:
            approved: True if tech team approves, False to reject
            comments: Optional feedback/notes
        """
        self._tech_feedback = {
            "approved": approved,
            "comments": comments
        }

    @workflow.signal
    async def final_feedback(self, approved: bool, comments: str = "") -> None:
        """
        Signal: Leadership provides final interview feedback.

        Args:
            approved: True to extend offer, False to reject
            comments: Optional feedback/notes
        """
        self._final_feedback = {
            "approved": approved,
            "comments": comments
        }

    # ===== QUERY HANDLERS =====
    # These allow the frontend to check status and know what to display

    @workflow.query
    def get_status(self) -> dict:
        """
        Query: Get complete workflow status.

        Returns detailed information about:
        - Which stage we're at
        - What feedback has been received
        - What we're waiting for

        Frontend uses this to:
        - Show progress bar
        - Display correct input form
        - Show stage-specific information
        """
        return {
            "current_stage": self._current_stage,
            "outcome": self._outcome,
            "hr_feedback_received": self._hr_feedback is not None,
            "tech_feedback_received": self._tech_feedback is not None,
            "final_feedback_received": self._final_feedback is not None,
            "rejection_stage": self._rejection_stage,
            "rejection_reason": self._rejection_reason,
        }
