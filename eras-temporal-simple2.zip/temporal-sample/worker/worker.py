"""
Temporal Worker - The Worker Process

This is the "worker" that executes your workflows and activities.
Think of it as a dedicated server that waits for jobs to do.

Key Concepts:
- Worker: A process that polls Temporal for tasks to execute
- Task Queue: A named queue where tasks are placed (like "hello-tasks")
- The worker connects to Temporal server and says "I can do these workflows and activities"
- When a workflow is started, Temporal puts it on the task queue
- The worker picks it up and executes it
"""

import asyncio  # Python's async/await library for concurrent programming
import os  # For reading environment variables
from temporalio.client import Client  # Temporal client to connect to the server
from temporalio.worker import Worker  # The worker that executes workflows/activities

# Import our custom workflows and activities
from workflows import HelloWorldWorkflow, JobInterviewWorkflow
from activities import (
    say_hello,
    screen_resume,
    schedule_hr_interview,
    schedule_technical_interview,
    schedule_final_interview,
    send_offer,
    send_rejection,
)


async def main():
    """
    Main function that sets up and runs the worker.

    The 'async' keyword means this function can do things concurrently.
    It's like a chef who can start cooking multiple dishes at the same time.
    """

    # Get Temporal server address from environment variable
    # If not set, default to "localhost:7233"
    # This allows us to change the server address without changing code
    temporal_host = os.getenv("TEMPORAL_HOST", "localhost:7233")

    # Connect to Temporal server
    # This is like establishing a phone line to the Temporal server
    # 'await' means "wait for this to complete before continuing"
    client = await Client.connect(temporal_host)

    # Create and configure the worker
    # The worker needs to know:
    # 1. Which Temporal server to connect to (client)
    # 2. Which task queue to listen on ("hello-tasks")
    # 3. Which workflows it can execute ([HelloWorldWorkflow])
    # 4. Which activities it can execute ([say_hello])
    worker = Worker(
        client,  # The connection to Temporal server
        task_queue="hello-tasks",  # The name of the queue to listen on
        workflows=[HelloWorldWorkflow, JobInterviewWorkflow],  # List of workflows this worker can run
        activities=[  # List of activities this worker can run
            say_hello,
            screen_resume,
            schedule_hr_interview,
            schedule_technical_interview,
            schedule_final_interview,
            send_offer,
            send_rejection,
        ],
    )

    # Print confirmation messages so we know the worker started
    print(f"Worker started on task queue: hello-tasks")
    print(f"Connected to Temporal at: {temporal_host}")

    # Start the worker and keep it running forever
    # This is a blocking call - the worker will run until stopped
    # It continuously polls Temporal asking "do you have work for me?"
    await worker.run()


# Standard Python pattern: only run main() if this file is executed directly
# (not if it's imported as a module)
if __name__ == "__main__":
    # Run the async main function
    # asyncio.run() is the entry point for async programs
    asyncio.run(main())
