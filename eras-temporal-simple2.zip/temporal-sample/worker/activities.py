"""
Temporal Activities - The "Tasks" Your Workflow Can Do

Activities are individual units of work that can be executed by a workflow.
Think of them as functions that do actual work (API calls, database queries, etc.).

Why Activities?
- They can fail and be retried automatically by Temporal
- They can run on different machines than the workflow
- They can have timeouts and retry policies
- They're the "doing" part, while workflows are the "coordinating" part

Example: If a workflow is a recipe, activities are the individual steps:
- Activity 1: Chop vegetables
- Activity 2: Boil water
- Activity 3: Cook pasta
"""

from temporalio import activity  # Import the activity decorator
import logging

# Set up logging so we can see what's happening
logger = logging.getLogger(__name__)


# ===== SIMPLE HELLO WORLD ACTIVITY =====
# This is the original simple activity from the hello world workflow


@activity.defn
async def say_hello() -> str:
    """
    A simple activity that returns "hello world".

    This is used by the HelloWorldWorkflow.
    """
    return "hello world"


# ===== JOB INTERVIEW WORKFLOW ACTIVITIES =====
# These activities simulate real-world actions in a hiring process
# In production, these would send real emails, update databases, etc.


@activity.defn
async def screen_resume(candidate_name: str) -> dict:
    """
    Automatically screen a candidate's resume.

    In real life, this might:
    - Parse resume PDF
    - Check for required skills
    - Calculate match score
    - Query ATS (Applicant Tracking System)

    For this demo, we'll mock it and always approve.

    Args:
        candidate_name: Name of the candidate

    Returns:
        dict: {"approved": True/False, "reason": "..."}
    """
    logger.info(f"📄 Screening resume for {candidate_name}...")

    # Mock: In real app, this would analyze the resume
    # For demo, we always approve
    result = {
        "approved": True,
        "reason": "Candidate has required skills and experience"
    }

    logger.info(f"✅ Resume screening result: {result}")
    return result


@activity.defn
async def schedule_hr_interview(candidate_name: str) -> str:
    """
    Schedule an HR interview.

    In real life, this might:
    - Send calendar invite
    - Email candidate with details
    - Update scheduling system
    - Notify HR team

    Args:
        candidate_name: Name of the candidate

    Returns:
        str: Confirmation message
    """
    logger.info(f"📅 Scheduling HR interview for {candidate_name}...")

    # Mock: In real app, this would call calendar API, send emails, etc.
    message = f"HR interview scheduled for {candidate_name} on Monday at 10 AM"

    logger.info(f"✅ {message}")
    return message


@activity.defn
async def schedule_technical_interview(candidate_name: str) -> str:
    """
    Schedule a technical interview.

    In real life, this might:
    - Assign coding challenge
    - Book technical interviewer
    - Send preparation materials
    - Set up video call link

    Args:
        candidate_name: Name of the candidate

    Returns:
        str: Confirmation message
    """
    logger.info(f"📅 Scheduling technical interview for {candidate_name}...")

    # Mock: In real app, would interact with scheduling system
    message = f"Technical interview scheduled for {candidate_name} on Wednesday at 2 PM"

    logger.info(f"✅ {message}")
    return message


@activity.defn
async def schedule_final_interview(candidate_name: str) -> str:
    """
    Schedule final interview with leadership.

    In real life, this might:
    - Book exec/manager time
    - Prepare interview packet
    - Send candidate case study
    - Arrange panel interview

    Args:
        candidate_name: Name of the candidate

    Returns:
        str: Confirmation message
    """
    logger.info(f"📅 Scheduling final interview for {candidate_name}...")

    # Mock: In real app, would coordinate with multiple calendars
    message = f"Final interview scheduled for {candidate_name} on Friday at 4 PM"

    logger.info(f"✅ {message}")
    return message


@activity.defn
async def send_offer(candidate_name: str, position: str) -> str:
    """
    Send job offer to candidate.

    In real life, this might:
    - Generate offer letter PDF
    - Send via DocuSign/HelloSign
    - Email HR and hiring manager
    - Update ATS status to "Offer Sent"
    - Create onboarding ticket

    Args:
        candidate_name: Name of the candidate
        position: Job title being offered

    Returns:
        str: Confirmation message
    """
    logger.info(f"💼 Sending job offer to {candidate_name} for position: {position}...")

    # Mock: In real app, would generate offer letter, send emails, etc.
    message = f"🎉 Job offer sent to {candidate_name} for {position} position!"

    logger.info(f"✅ {message}")
    return message


@activity.defn
async def send_rejection(candidate_name: str, stage: str, reason: str) -> str:
    """
    Send rejection email to candidate.

    In real life, this might:
    - Send personalized rejection email
    - Update ATS status
    - Archive candidate data per GDPR
    - Add to talent pool for future roles

    Args:
        candidate_name: Name of the candidate
        stage: Which stage they were rejected at
        reason: Reason for rejection (optional, for internal tracking)

    Returns:
        str: Confirmation message
    """
    logger.info(f"❌ Sending rejection to {candidate_name} (rejected at {stage})...")

    # Mock: In real app, would send actual email
    message = f"Rejection email sent to {candidate_name} (Stage: {stage})"

    logger.info(f"✅ {message}")
    return message
