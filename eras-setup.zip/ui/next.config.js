/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',
  async rewrites() {
    return [
      {
        source: '/api/workspace/:path*',
        destination: `${process.env.NEXT_PUBLIC_WORKSPACE_API_URL || 'http://workspace-service:8000'}/:path*`,
      },
      {
        source: '/api/workflow/:path*',
        destination: `${process.env.NEXT_PUBLIC_WORKFLOW_API_URL || 'http://workflow-service:8000'}/:path*`,
      },
    ];
  },
};

module.exports = nextConfig;
