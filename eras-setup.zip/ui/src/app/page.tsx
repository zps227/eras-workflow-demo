export default function Home() {
  return (
    <main style={{ padding: '2rem', fontFamily: 'system-ui, sans-serif' }}>
      <h1>Workspace & Workflow Manager</h1>
      <p>Welcome to your application skeleton!</p>

      <div style={{ marginTop: '2rem' }}>
        <h2>Services Status</h2>
        <ul>
          <li>NextJS UI: Running on port 3000</li>
          <li>Workspace Service: <a href="http://localhost:8001/docs" target="_blank">http://localhost:8001/docs</a></li>
          <li>Workflow Service: <a href="http://localhost:8002/docs" target="_blank">http://localhost:8002/docs</a></li>
          <li>Temporal UI: <a href="http://localhost:8233" target="_blank">http://localhost:8233</a></li>
          <li>OPA: <a href="http://localhost:8181/health" target="_blank">http://localhost:8181/health</a></li>
        </ul>
      </div>

      <div style={{ marginTop: '2rem' }}>
        <h2>Quick Links</h2>
        <nav>
          <ul>
            <li><a href="/workspaces">Workspaces</a> (stub)</li>
            <li><a href="/workflows">Workflows</a> (stub)</li>
          </ul>
        </nav>
      </div>
    </main>
  );
}
