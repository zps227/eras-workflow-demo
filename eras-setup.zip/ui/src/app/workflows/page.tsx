export default function WorkflowsPage() {
  return (
    <main style={{ padding: '2rem', fontFamily: 'system-ui, sans-serif' }}>
      <h1>Workflows</h1>
      <p>This is a stub page. Implement your workflow listing here.</p>
      <a href="/">← Back to Home</a>
    </main>
  );
}
