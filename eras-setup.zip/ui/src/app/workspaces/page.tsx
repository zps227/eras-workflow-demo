export default function WorkspacesPage() {
  return (
    <main style={{ padding: '2rem', fontFamily: 'system-ui, sans-serif' }}>
      <h1>Workspaces</h1>
      <p>This is a stub page. Implement your workspace listing here.</p>
      <a href="/">← Back to Home</a>
    </main>
  );
}
