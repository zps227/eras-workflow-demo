"""
Example Temporal Activity.

TODO: Implement your actual activities here.
"""
from temporalio import activity

@activity.defn
async def example_activity(input_data: dict) -> dict:
    """
    Example activity demonstrating basic Temporal activity patterns.

    Args:
        input_data: Input parameters for the activity

    Returns:
        Activity execution result
    """
    activity.logger.info(f"Executing example activity with input: {input_data}")

    # TODO: Add your activity logic here
    # This could be:
    # - API calls
    # - Database operations
    # - File processing
    # - Any other discrete unit of work

    result = {
        "status": "success",
        "data": input_data,
        "message": "Activity completed"
    }

    activity.logger.info(f"Activity completed with result: {result}")
    return result
