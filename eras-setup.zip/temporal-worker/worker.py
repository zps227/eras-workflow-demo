"""
Temporal Worker - Executes workflows and activities.

This worker connects to the Temporal server and processes workflows.
Add your workflow and activity implementations in the workflows/ and activities/ directories.
"""
import asyncio
import os
from temporalio.client import Client
from temporalio.worker import Worker

# Import your workflows and activities here
from workflows.example_workflow import ExampleWorkflow
from activities.example_activity import example_activity

TEMPORAL_HOST = os.getenv("TEMPORAL_HOST", "temporal:7233")
TEMPORAL_NAMESPACE = os.getenv("TEMPORAL_NAMESPACE", "default")
TASK_QUEUE = os.getenv("TASK_QUEUE", "default-task-queue")

async def main():
    """Start the Temporal worker."""
    print(f"Connecting to Temporal at {TEMPORAL_HOST}...")

    client = await Client.connect(TEMPORAL_HOST, namespace=TEMPORAL_NAMESPACE)

    print(f"Starting worker on task queue: {TASK_QUEUE}")

    # Create worker with your workflows and activities
    worker = Worker(
        client,
        task_queue=TASK_QUEUE,
        workflows=[
            # Add your workflow classes here
            ExampleWorkflow,
        ],
        activities=[
            # Add your activity functions here
            example_activity,
        ],
    )

    print("Worker started successfully. Waiting for workflows...")
    await worker.run()

if __name__ == "__main__":
    asyncio.run(main())
