"""
Example Temporal Workflow.

TODO: Implement your actual workflows here.
"""
from datetime import timedelta
from temporalio import workflow

# Import your activities
# from activities.example_activity import example_activity

@workflow.defn
class ExampleWorkflow:
    """Example workflow demonstrating basic Temporal patterns."""

    @workflow.run
    async def run(self, input_data: dict) -> dict:
        """
        Main workflow entry point.

        Args:
            input_data: Input parameters for the workflow

        Returns:
            Workflow execution result
        """
        workflow.logger.info(f"Starting example workflow with input: {input_data}")

        # TODO: Add your workflow logic here
        # Example activity execution:
        # result = await workflow.execute_activity(
        #     example_activity,
        #     input_data,
        #     start_to_close_timeout=timedelta(seconds=30),
        # )

        result = {
            "status": "completed",
            "message": "Example workflow completed successfully",
            "input": input_data
        }

        workflow.logger.info(f"Workflow completed with result: {result}")
        return result
