from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from app.db.database import get_db
from app.models import models, schemas
import uuid

router = APIRouter()

@router.post("/", response_model=schemas.WorkflowInstanceResponse, status_code=status.HTTP_201_CREATED)
def create_workflow_instance(
    workflow: schemas.WorkflowInstanceCreate,
    db: Session = Depends(get_db)
):
    """
    Create and start a new workflow instance.

    TODO: Add OPA policy check for authorization
    TODO: Integrate with Temporal to actually start the workflow
    TODO: Implement proper validation
    """
    workflow_id = f"wf-{uuid.uuid4()}"

    db_workflow = models.WorkflowInstance(
        workflow_id=workflow_id,
        **workflow.model_dump()
    )
    db.add(db_workflow)
    db.commit()
    db.refresh(db_workflow)

    # TODO: Start Temporal workflow here
    # from app.temporal_workflows.client import start_workflow
    # temporal_instance = await start_workflow(workflow_type, input_data)
    # db_workflow.temporal_workflow_id = temporal_instance.workflow_id
    # db_workflow.temporal_run_id = temporal_instance.run_id
    # db_workflow.status = models.WorkflowStatus.RUNNING
    # db.commit()

    return db_workflow

@router.get("/", response_model=List[schemas.WorkflowInstanceResponse])
def list_workflow_instances(
    skip: int = 0,
    limit: int = 100,
    status: Optional[models.WorkflowStatus] = None,
    db: Session = Depends(get_db)
):
    """
    List all workflow instances.

    TODO: Add pagination
    TODO: Add more filtering options
    TODO: Add OPA policy check for authorization
    """
    query = db.query(models.WorkflowInstance)

    if status:
        query = query.filter(models.WorkflowInstance.status == status)

    workflows = query.offset(skip).limit(limit).all()
    return workflows

@router.get("/{workflow_id}", response_model=schemas.WorkflowInstanceResponse)
def get_workflow_instance(workflow_id: str, db: Session = Depends(get_db)):
    """
    Get a specific workflow instance by ID.

    TODO: Add OPA policy check for authorization
    """
    workflow = db.query(models.WorkflowInstance).filter(
        models.WorkflowInstance.workflow_id == workflow_id
    ).first()

    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow instance not found")

    return workflow

@router.post("/{workflow_id}/cancel", response_model=schemas.WorkflowInstanceResponse)
def cancel_workflow_instance(workflow_id: str, db: Session = Depends(get_db)):
    """
    Cancel a running workflow instance.

    TODO: Add OPA policy check for authorization
    TODO: Integrate with Temporal to cancel the workflow
    """
    workflow = db.query(models.WorkflowInstance).filter(
        models.WorkflowInstance.workflow_id == workflow_id
    ).first()

    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow instance not found")

    if workflow.status in [models.WorkflowStatus.COMPLETED, models.WorkflowStatus.FAILED]:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot cancel workflow in status: {workflow.status}"
        )

    # TODO: Cancel Temporal workflow here
    # from app.temporal_workflows.client import cancel_workflow
    # await cancel_workflow(workflow.temporal_workflow_id)

    workflow.status = models.WorkflowStatus.CANCELLED
    db.commit()
    db.refresh(workflow)

    return workflow

@router.get("/{workflow_id}/status")
def get_workflow_status(workflow_id: str, db: Session = Depends(get_db)):
    """
    Get the current status of a workflow instance.

    TODO: Query Temporal for real-time status
    TODO: Add OPA policy check for authorization
    """
    workflow = db.query(models.WorkflowInstance).filter(
        models.WorkflowInstance.workflow_id == workflow_id
    ).first()

    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow instance not found")

    return {
        "workflow_id": workflow.workflow_id,
        "status": workflow.status,
        "temporal_workflow_id": workflow.temporal_workflow_id,
        "created_at": workflow.created_at,
        "updated_at": workflow.updated_at,
        "completed_at": workflow.completed_at
    }
