from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api import workflows
from app.db.database import engine
from app.models import models

# Create database tables
models.Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Workflow Service",
    description="Service for managing workflow instances and state transitions",
    version="0.1.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(workflows.router, prefix="/workflows", tags=["workflows"])

@app.get("/")
def read_root():
    return {"service": "Workflow Service", "status": "running"}

@app.get("/health")
def health_check():
    return {"status": "healthy"}
