from pydantic import BaseModel
from datetime import datetime
from typing import Optional, Any, Dict
from app.models.models import WorkflowStatus

class WorkflowInstanceBase(BaseModel):
    workflow_type: str
    input_data: Optional[Dict[str, Any]] = None
    created_by: str

class WorkflowInstanceCreate(WorkflowInstanceBase):
    pass

class WorkflowInstanceUpdate(BaseModel):
    status: Optional[WorkflowStatus] = None
    output_data: Optional[Dict[str, Any]] = None
    error_message: Optional[str] = None

class WorkflowInstanceResponse(WorkflowInstanceBase):
    id: int
    workflow_id: str
    status: WorkflowStatus
    output_data: Optional[Dict[str, Any]] = None
    error_message: Optional[str] = None
    temporal_workflow_id: Optional[str] = None
    temporal_run_id: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    class Config:
        from_attributes = True
