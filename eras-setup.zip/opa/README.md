# Open Policy Agent (OPA) Configuration

This directory contains OPA policies for authorization across the application.

## Policies

- `workspace.rego`: Authorization policies for workspace operations
- `workflow.rego`: Authorization policies for workflow operations

## Testing Policies

You can test policies using the OPA CLI or the REST API:

```bash
# Test a policy with example input
curl -X POST http://localhost:8181/v1/data/workspace/authz/allow \
  -H 'Content-Type: application/json' \
  -d @policies/example_input.json
```

## Policy Structure

Policies expect input in the following format:

```json
{
  "user": {
    "id": "user-id",
    "role": "user|admin",
    "authenticated": true,
    "workspace_memberships": ["ws-1", "ws-2"]
  },
  "action": "create|read|update|delete|cancel|retry",
  "resource": {
    "type": "workspace|workflow",
    "id": "resource-id",
    "owner_id": "owner-user-id",
    ...
  }
}
```

## Integration

To use OPA policies in your FastAPI services:

```python
import httpx

async def check_authorization(user, action, resource):
    async with httpx.AsyncClient() as client:
        response = await client.post(
            "http://opa:8181/v1/data/workspace/authz/allow",
            json={
                "input": {
                    "user": user,
                    "action": action,
                    "resource": resource
                }
            }
        )
        result = response.json()
        return result.get("result", False)
```
