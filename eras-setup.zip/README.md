# Workspace & Workflow Management System

A skeleton Docker Compose project with NextJS UI, FastAPI microservices, Temporal.io workflows, PostgreSQL, and OPA authorization.

## Architecture

```
┌────────┐  ┌───────────┐ ┌──────────┐  ┌──────────┐  ┌─────────┐
│NextJS  │  │Workspace  │ │Workflow  │  │Temporal  │  │  OPA    │
│   UI   │  │ Service   │ │ Service  │  │    UI    │  │         │
│:3000   │  │  :8001    │ │  :8002   │  │  :8233   │  │  :8181  │
└────────┘  └─────┬─────┘ └────┬─────┘  └────┬─────┘  └─────────┘
                  │            │             │
            ┌─────┴────────────┴─────┐  ┌────▼────────────┐
            │   PostgreSQL :5432     │  │Temporal Server  │
            │   (Application DB)     │  │    :7233        │
            └────────────────────────┘  └────┬────────────┘
                                             │
                                    ┌────────▼────────────┐
                                    │ Temporal PostgreSQL │
                                    │      :5433          │
                                    └─────────────────────┘
                                             │
                                    ┌────────▼────────────┐
                                    │  Temporal Worker    │
                                    └─────────────────────┘
```

## Services

| Service | Description | Port | Tech Stack |
|---------|-------------|------|------------|
| **NextJS UI** | Frontend application | 3000 | Next.js 14, React, TypeScript |
| **Workspace Service** | Workspace CRUD operations | 8001 | FastAPI, SQLAlchemy, PostgreSQL |
| **Workflow Service** | Workflow management | 8002 | FastAPI, Temporal Client |
| **Temporal Server** | Workflow orchestration | 7233 (gRPC), 8233 (UI) | Temporal.io |
| **Temporal Worker** | Workflow execution | - | Python, Temporalio SDK |
| **PostgreSQL** | Application database | 5432 | PostgreSQL 15 |
| **Temporal DB** | Temporal's database | 5433 | PostgreSQL 15 |
| **OPA** | Policy-based authorization | 8181 | Open Policy Agent |

## Prerequisites

- Docker Desktop (with Docker Compose)
- Git

## Quick Start

1. **Clone or navigate to the project directory**

```bash
cd skeleton-structure
```

2. **Copy environment variables**

```bash
cp .env.example .env
```

3. **Start all services**

```bash
docker-compose up -d
```

4. **Wait for services to be healthy** (first startup takes a few minutes)

```bash
docker-compose ps
```

5. **Access the applications**

- **Main Application**: http://localhost:3000
- **Workspace Service API Docs**: http://localhost:8001/docs
- **Workflow Service API Docs**: http://localhost:8002/docs
- **Temporal UI**: http://localhost:8233
- **OPA Health**: http://localhost:8181/health

## Service Details

### NextJS UI (`ui/`)

Frontend application with TypeScript support.

**Key Files:**
- `src/app/page.tsx` - Home page
- `src/app/workspaces/page.tsx` - Workspaces listing (stub)
- `src/app/workflows/page.tsx` - Workflows listing (stub)
- `next.config.js` - Next.js configuration with API rewrites

**Development:**
```bash
cd ui
npm install
npm run dev
```

### Workspace Service (`workspace-service/`)

FastAPI service for workspace CRUD operations.

**Key Files:**
- `app/main.py` - FastAPI application
- `app/api/workspaces.py` - Workspace endpoints
- `app/models/models.py` - SQLAlchemy models
- `app/models/schemas.py` - Pydantic schemas

**Endpoints:**
- `POST /workspaces` - Create workspace
- `GET /workspaces` - List workspaces
- `GET /workspaces/{id}` - Get workspace
- `PUT /workspaces/{id}` - Update workspace
- `DELETE /workspaces/{id}` - Delete workspace

### Workflow Service (`workflow-service/`)

FastAPI service for workflow management with Temporal integration.

**Key Files:**
- `app/main.py` - FastAPI application
- `app/api/workflows.py` - Workflow endpoints
- `app/models/models.py` - Workflow instance models
- `app/temporal_workflows/client.py` - Temporal client (stub)

**Endpoints:**
- `POST /workflows` - Create workflow instance
- `GET /workflows` - List workflow instances
- `GET /workflows/{id}` - Get workflow instance
- `POST /workflows/{id}/cancel` - Cancel workflow
- `GET /workflows/{id}/status` - Get workflow status

### Temporal Worker (`temporal-worker/`)

Python worker that executes Temporal workflows.

**Key Files:**
- `worker.py` - Worker startup
- `workflows/example_workflow.py` - Example workflow (stub)
- `activities/example_activity.py` - Example activity (stub)

**To implement your workflows:**
1. Create workflow classes in `workflows/`
2. Create activity functions in `activities/`
3. Register them in `worker.py`

### OPA Policies (`opa/policies/`)

Authorization policies written in Rego.

**Key Files:**
- `workspace.rego` - Workspace authorization rules
- `workflow.rego` - Workflow authorization rules
- `example_input.json` - Example policy input

**Testing policies:**
```bash
curl -X POST http://localhost:8181/v1/data/workspace/authz/allow \
  -H 'Content-Type: application/json' \
  -d @opa/policies/example_input.json
```

## Development Workflow

### Adding New Endpoints

#### Workspace Service

1. Add new endpoint in `workspace-service/app/api/workspaces.py`
2. Update models if needed in `workspace-service/app/models/`
3. Restart the service: `docker-compose restart workspace-service`

#### Workflow Service

1. Add new endpoint in `workflow-service/app/api/workflows.py`
2. Update models if needed in `workflow-service/app/models/`
3. Restart the service: `docker-compose restart workflow-service`

### Adding Temporal Workflows

1. Create workflow class in `temporal-worker/workflows/your_workflow.py`
2. Create activities in `temporal-worker/activities/your_activities.py`
3. Register in `temporal-worker/worker.py`
4. Restart worker: `docker-compose restart temporal-worker`

### Adding OPA Policies

1. Create or edit policy files in `opa/policies/*.rego`
2. Policies are automatically reloaded by OPA

### Viewing Logs

```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f workspace-service
docker-compose logs -f workflow-service
docker-compose logs -f temporal-worker
```

## Database Access

### Application Database

```bash
docker exec -it app-postgres psql -U app_user -d app_db
```

### Temporal Database

```bash
docker exec -it temporal-postgres psql -U temporal -d temporal
```

## Stopping Services

```bash
# Stop all services
docker-compose down

# Stop and remove volumes (warning: deletes all data)
docker-compose down -v
```

## Project Structure

```
skeleton-structure/
├── docker-compose.yml          # Main orchestration file
├── .env.example                # Environment variables template
├── README.md                   # This file
│
├── ui/                         # Frontend application
│   ├── Dockerfile
│   ├── package.json
│   ├── next.config.js
│   ├── tsconfig.json
│   └── src/
│       └── app/
│           ├── layout.tsx
│           ├── page.tsx
│           ├── workspaces/
│           └── workflows/
│
├── workspace-service/          # Workspace microservice
│   ├── Dockerfile
│   ├── requirements.txt
│   └── app/
│       ├── main.py
│       ├── api/
│       │   └── workspaces.py
│       ├── models/
│       │   ├── models.py
│       │   └── schemas.py
│       └── db/
│           └── database.py
│
├── workflow-service/           # Workflow microservice
│   ├── Dockerfile
│   ├── requirements.txt
│   └── app/
│       ├── main.py
│       ├── api/
│       │   └── workflows.py
│       ├── models/
│       │   ├── models.py
│       │   └── schemas.py
│       ├── db/
│       │   └── database.py
│       └── temporal_workflows/
│           └── client.py
│
├── temporal-worker/            # Temporal worker
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── worker.py
│   ├── workflows/
│   │   └── example_workflow.py
│   └── activities/
│       └── example_activity.py
│
└── opa/                        # OPA policies
    ├── README.md
    └── policies/
        ├── workspace.rego
        ├── workflow.rego
        └── example_input.json
```

## Next Steps

This is a skeleton project with stub implementations. Here's what you should implement:

### TODO: Workspace Service
- [ ] Add user authentication
- [ ] Implement OPA authorization checks
- [ ] Add workspace member management
- [ ] Add proper validation and error handling
- [ ] Implement database migrations with Alembic

### TODO: Workflow Service
- [ ] Integrate Temporal client to start workflows
- [ ] Implement workflow status polling from Temporal
- [ ] Add OPA authorization checks
- [ ] Add workflow cancellation via Temporal
- [ ] Implement proper error handling

### TODO: Temporal Workflows
- [ ] Define your actual workflow types
- [ ] Implement workflow activities
- [ ] Add error handling and retries
- [ ] Configure workflow timeouts
- [ ] Add workflow testing

### TODO: NextJS UI
- [ ] Implement workspace management pages
- [ ] Implement workflow management pages
- [ ] Add authentication flow
- [ ] Add API client layer
- [ ] Add proper error handling and loading states
- [ ] Style with your preferred CSS framework

### TODO: OPA Policies
- [ ] Customize authorization rules for your use case
- [ ] Integrate OPA checks in FastAPI services
- [ ] Add policy testing

### TODO: Production Readiness
- [ ] Add proper logging
- [ ] Add monitoring and metrics
- [ ] Set up CI/CD pipeline
- [ ] Add comprehensive tests
- [ ] Security hardening
- [ ] Kubernetes deployment configurations

## Resources

- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [Next.js Documentation](https://nextjs.org/docs)
- [Temporal.io Documentation](https://docs.temporal.io/)
- [OPA Documentation](https://www.openpolicyagent.org/docs/)

## Troubleshooting

### Service won't start
```bash
# Check logs
docker-compose logs <service-name>

# Rebuild service
docker-compose build <service-name>
docker-compose up -d <service-name>
```

### Database connection issues
```bash
# Check if PostgreSQL is healthy
docker-compose ps postgres

# Recreate database
docker-compose down -v
docker-compose up -d
```

### Temporal workflows not running
```bash
# Check Temporal server health
curl http://localhost:8233

# Check worker logs
docker-compose logs temporal-worker

# Restart worker
docker-compose restart temporal-worker
```

## License

This is a skeleton project template. Use it as you wish!
