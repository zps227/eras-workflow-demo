from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.db.database import get_db
from app.models import models, schemas

router = APIRouter()

@router.post("/", response_model=schemas.WorkspaceResponse, status_code=status.HTTP_201_CREATED)
def create_workspace(workspace: schemas.WorkspaceCreate, db: Session = Depends(get_db)):
    """
    Create a new workspace.

    TODO: Add OPA policy check for authorization
    TODO: Implement proper validation
    """
    db_workspace = models.Workspace(**workspace.model_dump())
    db.add(db_workspace)
    db.commit()
    db.refresh(db_workspace)
    return db_workspace

@router.get("/", response_model=List[schemas.WorkspaceResponse])
def list_workspaces(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    """
    List all workspaces.

    TODO: Add pagination
    TODO: Add filtering
    TODO: Add OPA policy check for authorization
    """
    workspaces = db.query(models.Workspace).offset(skip).limit(limit).all()
    return workspaces

@router.get("/{workspace_id}", response_model=schemas.WorkspaceResponse)
def get_workspace(workspace_id: int, db: Session = Depends(get_db)):
    """
    Get a specific workspace by ID.

    TODO: Add OPA policy check for authorization
    """
    workspace = db.query(models.Workspace).filter(models.Workspace.id == workspace_id).first()
    if not workspace:
        raise HTTPException(status_code=404, detail="Workspace not found")
    return workspace

@router.put("/{workspace_id}", response_model=schemas.WorkspaceResponse)
def update_workspace(
    workspace_id: int,
    workspace_update: schemas.WorkspaceUpdate,
    db: Session = Depends(get_db)
):
    """
    Update a workspace.

    TODO: Add OPA policy check for authorization
    TODO: Implement partial updates properly
    """
    db_workspace = db.query(models.Workspace).filter(models.Workspace.id == workspace_id).first()
    if not db_workspace:
        raise HTTPException(status_code=404, detail="Workspace not found")

    update_data = workspace_update.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(db_workspace, field, value)

    db.commit()
    db.refresh(db_workspace)
    return db_workspace

@router.delete("/{workspace_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_workspace(workspace_id: int, db: Session = Depends(get_db)):
    """
    Delete a workspace.

    TODO: Add OPA policy check for authorization
    TODO: Consider soft delete vs hard delete
    """
    db_workspace = db.query(models.Workspace).filter(models.Workspace.id == workspace_id).first()
    if not db_workspace:
        raise HTTPException(status_code=404, detail="Workspace not found")

    db.delete(db_workspace)
    db.commit()
    return None
