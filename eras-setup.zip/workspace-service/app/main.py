from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api import workspaces
from app.db.database import engine
from app.models import models

# Create database tables
models.Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Workspace Service",
    description="Service for managing workspace CRUD operations",
    version="0.1.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(workspaces.router, prefix="/workspaces", tags=["workspaces"])

@app.get("/")
def read_root():
    return {"service": "Workspace Service", "status": "running"}

@app.get("/health")
def health_check():
    return {"status": "healthy"}
