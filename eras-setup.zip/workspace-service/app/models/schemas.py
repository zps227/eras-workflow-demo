from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class WorkspaceBase(BaseModel):
    name: str
    description: Optional[str] = None
    owner_id: str

class WorkspaceCreate(WorkspaceBase):
    pass

class WorkspaceUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None

class WorkspaceResponse(WorkspaceBase):
    id: int
    is_active: bool
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
