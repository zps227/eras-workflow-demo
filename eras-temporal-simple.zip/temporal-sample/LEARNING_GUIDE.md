# Temporal Learning Guide

## Complete Flow: How Everything Works Together

This guide explains how all the pieces work together when you use the application.

### The Big Picture

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Frontend  │────▶│   Backend   │────▶│   Temporal  │────▶│   Worker    │
│  (User UI)  │◀────│  (FastAPI)  │◀────│   Server    │◀────│ (Executes)  │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
     React              Python             Temporal            Python
   Port 3000           Port 8000           Port 7233          (polls for tasks)
```

### What Each Component Does

1. **Frontend (React/Next.js)** - The User Interface
   - What you see in the browser
   - Has buttons to start workflows and send input
   - Shows workflow status

2. **Backend (FastAPI)** - The API Server
   - Receives requests from the frontend
   - Talks to Temporal server
   - Sends responses back to frontend

3. **Temporal Server** - The Orchestration Engine
   - Stores workflow state
   - Tracks what's happening
   - Never loses data, even if servers crash

4. **Worker (Python)** - The Executor
   - Polls Temporal asking "any work for me?"
   - Executes workflows and activities
   - Runs the actual business logic

---

## Step-by-Step: What Happens When You Use the App

### STEP 1: User Clicks "Start Workflow"

**Frontend (page.tsx)**
```
User clicks button → Calls fetch('http://localhost:8000/start')
```

**Backend (main.py - /start endpoint)**
```python
1. Generates unique ID: "hello-workflow-abc123"
2. Calls: temporal_client.start_workflow(
     "HelloWorldWorkflow",
     id="hello-workflow-abc123",
     task_queue="hello-tasks"
   )
3. Returns: {"workflow_id": "hello-workflow-abc123"}
```

**Temporal Server**
```
1. Creates new workflow execution
2. Puts it on "hello-tasks" queue
3. Stores initial state in database
```

**Worker (worker.py + workflows.py)**
```
1. Worker is constantly polling: "Any tasks on hello-tasks queue?"
2. Temporal says: "Yes! Run HelloWorldWorkflow"
3. Worker creates new HelloWorldWorkflow instance
4. Calls workflow.run()
```

**Workflow Execution (workflows.py)**
```python
def run(self):
    # STEP A: Set state to "STARTING"
    self._current_state = "STARTING"

    # STEP B: Execute activity
    hello_msg = await workflow.execute_activity(say_hello, ...)
    # Worker calls activities.py → say_hello() → returns "hello world"

    # STEP C: Set state to "WAITING_FOR_INPUT"
    self._current_state = "WAITING_FOR_INPUT"

    # STEP D: Pause here and wait!
    await workflow.wait_condition(lambda: self._user_input is not None)
    # Workflow is now PAUSED - worker is free to do other things
```

---

### STEP 2: User Clicks "Refresh Status"

**Frontend**
```
Calls: fetch('http://localhost:8000/status/hello-workflow-abc123')
```

**Backend (main.py - /status endpoint)**
```python
1. Gets workflow handle
2. Queries: handle.query("current_state")
3. Workflow responds: "WAITING_FOR_INPUT"
4. Returns: {
     "workflow_id": "hello-workflow-abc123",
     "state": "WAITING_FOR_INPUT",
     "result": null
   }
```

**Frontend**
```
Shows: "Status: WAITING_FOR_INPUT"
Shows: Input box + "Send Input" button
```

---

### STEP 3: User Types "Alice" and Clicks "Send Input"

**Frontend**
```
Calls: fetch('http://localhost:8000/input', {
  body: {
    "workflow_id": "hello-workflow-abc123",
    "message": "Alice"
  }
})
```

**Backend (main.py - /input endpoint)**
```python
1. Gets workflow handle
2. Sends signal: handle.signal("user_input", "Alice")
3. Waits for result: result = await handle.result()
```

**Temporal Server**
```
1. Receives signal
2. Wakes up the paused workflow
3. Delivers signal to workflow
```

**Workflow (workflows.py)**
```python
# The signal handler runs:
@workflow.signal
async def user_input(self, message: str):
    self._user_input = message  # Sets to "Alice"

# Back in run():
await workflow.wait_condition(lambda: self._user_input is not None)
# Condition is now TRUE! Continue...

self._current_state = "COMPLETED"
self._result = f"{hello_msg}, {self._user_input}"
# Creates: "hello world, Alice"

return self._result
```

**Backend**
```python
# Receives: "hello world, Alice"
# Returns to frontend: {
#   "workflow_id": "hello-workflow-abc123",
#   "result": "hello world, Alice"
# }
```

**Frontend**
```
Shows: "Final Result: hello world, Alice"
Shows: "Start New Workflow" button
```

---

## Key Temporal Concepts Explained

### 1. Workflows vs Activities

**Workflows = Orchestration (the coordinator)**
- Decide WHAT to do and WHEN
- Cannot do I/O directly (no API calls, no database)
- Must be deterministic (same inputs = same outputs)
- Can wait for days/months
- Example: "First do step A, then wait for approval, then do step B"

**Activities = Execution (the doers)**
- Do the actual work (API calls, database, emails, etc.)
- Can fail and retry
- Can timeout
- Example: "Send this email", "Query this database"

**Why separate?**
- If an activity fails, Temporal can retry it automatically
- If a worker crashes, Temporal can replay the workflow from history
- Workflows are recorded and can be inspected later

### 2. Signals

**Signals = Messages TO a workflow**
- Like sending a text message to the workflow
- Workflow can receive them while running
- Example: "Here's the user's input"

```python
# Sending a signal (from backend):
await handle.signal("user_input", "Alice")

# Receiving a signal (in workflow):
@workflow.signal
async def user_input(self, message: str):
    self._user_input = message
```

### 3. Queries

**Queries = Reading FROM a workflow**
- Like asking "What's your status?"
- Read-only - can't change workflow state
- Fast - doesn't wait for anything
- Example: "Are you waiting for input?"

```python
# Querying (from backend):
state = await handle.query("current_state")

# Query handler (in workflow):
@workflow.query
def current_state(self) -> str:
    return self._current_state
```

### 4. Task Queues

**Task Queue = A named queue for work**
- Like a post office box with a name
- Workers say "I'll check the 'hello-tasks' box"
- Workflows are put in specific boxes
- Must match! Worker and workflow must use same name

```python
# Worker listens to:
Worker(task_queue="hello-tasks", ...)

# Backend puts work on:
client.start_workflow(..., task_queue="hello-tasks")
```

### 5. Workflow IDs

**Workflow ID = Unique identifier**
- Each workflow execution has a unique ID
- Use it to query status, send signals, get results
- Like a tracking number for a package

---

## Common Python Patterns You'll See

### 1. `async` and `await`

```python
# Regular function (blocks everything until done)
def get_data():
    return fetch_from_api()  # Waits here

# Async function (allows other work while waiting)
async def get_data():
    return await fetch_from_api()  # Other tasks can run during wait
```

Think of it like a restaurant:
- **Regular**: Chef cooks one dish start to finish, everyone waits
- **Async**: Chef starts soup, while it simmers, starts main course

### 2. Decorators (`@something`)

```python
@workflow.defn
class MyWorkflow:
    pass
```

A decorator wraps a function/class with extra functionality.
Like putting a gift in a box - the gift is still there, but now it's wrapped.

### 3. Type Hints

```python
def greet(name: str) -> str:
    return f"Hello, {name}"
```

- `name: str` means "name should be a string"
- `-> str` means "this function returns a string"
- Python doesn't enforce these, but they help with documentation

### 4. f-strings

```python
name = "Alice"
message = f"Hello, {name}"  # "Hello, Alice"
```

A convenient way to put variables into strings.
The `f` means "format string"

---

## File Guide: Where to Find What

| File | Purpose | When to Edit |
|------|---------|--------------|
| `worker/worker.py` | Worker startup | Connect to different Temporal server |
| `worker/workflows.py` | Workflow logic | Add steps, change flow |
| `worker/activities.py` | Activity implementations | Add new tasks (API calls, etc.) |
| `backend/main.py` | API endpoints | Add new endpoints, change API |
| `frontend/app/page.tsx` | UI | Change how it looks/works |
| `docker-compose.yml` | Service orchestration | Add services, change ports |

---

## Debugging Tips

### Check Workflow History
1. Go to http://localhost:8233
2. Find your workflow by ID
3. Click on it to see EVERY step it took
4. You can see all activities, signals, queries

### Check Logs
```bash
# See all logs
docker-compose logs

# See specific service
docker-compose logs worker
docker-compose logs backend

# Follow logs in real-time
docker-compose logs -f worker
```

### Common Issues

**"Worker not picking up workflow"**
- Check task queue names match
- Check worker is running: `docker-compose ps`
- Check worker logs: `docker-compose logs worker`

**"Frontend can't connect to backend"**
- Check backend is running on port 8000
- Check CORS is enabled
- Check browser console for errors

**"Workflow stuck"**
- Check Temporal Web UI for errors
- Check worker logs for exceptions
- Verify signal names match exactly

---

## Next Steps: How to Extend This

### Add a New Activity

1. Add to `worker/activities.py`:
```python
@activity.defn
async def send_email(email: str, message: str) -> bool:
    # Send email logic here
    return True
```

2. Use in workflow (`worker/workflows.py`):
```python
result = await workflow.execute_activity(
    send_email,
    args=["user@example.com", "Hello!"],
    start_to_close_timeout=timedelta(seconds=30),
)
```

3. Register in worker (`worker/worker.py`):
```python
worker = Worker(
    client,
    task_queue="hello-tasks",
    workflows=[HelloWorldWorkflow],
    activities=[say_hello, send_email],  # Add here!
)
```

### Add a New Endpoint

Edit `backend/main.py`:
```python
@app.get("/my-endpoint")
async def my_endpoint():
    return {"message": "Hello from new endpoint!"}
```

### Make Workflow Wait Longer

```python
# Wait with timeout
await workflow.wait_condition(
    lambda: self._user_input is not None,
    timeout=timedelta(hours=24)  # Wait up to 24 hours!
)
```

---

## Resources

- **Temporal Python SDK Docs**: https://docs.temporal.io/dev-guide/python
- **FastAPI Docs**: https://fastapi.tiangolo.com/
- **Next.js Docs**: https://nextjs.org/docs
- **Python Async**: https://docs.python.org/3/library/asyncio.html

## Questions?

The code is heavily commented! Read through:
1. `worker/workflows.py` - See how workflows work
2. `worker/activities.py` - See how activities work
3. `backend/main.py` - See how to interact with Temporal
4. `worker/worker.py` - See how workers start up

Happy learning! 🚀
