"""
Temporal Workflows - Data-Driven Workflow Engine

This file contains the DataDrivenWorkflowEngine - a flexible workflow engine
that executes workflows defined in JSON without requiring code changes.

Key Concepts:
- WORKFLOWS = Coordination (decide what to do, when, and in what order)
- ACTIVITIES = Execution (do the actual work)
- JSON DEFINITIONS = Configure workflows without code deployment

Why Data-Driven Workflows?
- No code changes needed for new workflows
- Business users can configure workflows
- Version control workflow definitions as data
- A/B test different workflow variants
- Store workflows in database

Magic of the Workflow Engine:
- Supports activities (execute functions)
- Supports signals (wait for external input)
- Supports decisions (branch based on conditions)
- All workflow state stored and replayable
- Deterministic execution
"""

from datetime import timedelta
from temporalio import workflow
from temporalio.common import RetryPolicy
import json

# Import activities for the workflow engine
with workflow.unsafe.imports_passed_through():
    from activities import (
        review_application,
        schedule_interviews,
        aggregate_feedback,
        send_offer_email,
        send_rejection_email,
    )


@workflow.defn
class DataDrivenWorkflowEngine:
    """
    Data-Driven Workflow Engine - Execute workflows defined in JSON.

    This workflow engine allows you to define complete workflows in JSON
    without writing any Python code. Perfect for:
    - Admin-configurable approval processes
    - Multi-stage workflows with human-in-the-loop
    - Workflows that change frequently
    - A/B testing different workflow variants

    WORKFLOW DEFINITION STRUCTURE:
    {
      "start": "first_node_id",
      "steps": [
        {
          "id": "unique_node_id",
          "step_type": "activity" | "signal" | "decision",
          "task": {"name": "function_name", "params": {}},
          "next": "next_node_id",
          "branch": {  # Optional for signal/decision nodes
            "if": "context['node_id']['field'] == 'value'",
            "true_next": "node_if_true",
            "false_next": "node_if_false"
          }
        }
      ]
    }

    NODE TYPES:
    1. Activity - Execute a function (e.g., send email, process data)
    2. Signal - Wait for external input (e.g., human approval)
    3. Decision - Branch based on workflow context

    EXAMPLE:
    See worker/workflow_definition.json for a complete job interview example.
    """

    def __init__(self) -> None:
        """
        Initialize workflow engine state.

        State:
        - _workflow_definition: Parsed JSON workflow
        - _context: Outputs from all executed nodes
        - _received_signals: Signals sent to workflow
        - _current_node_id: Currently executing node
        - _completed: Whether workflow has finished
        - _execution_order: List of node IDs in order of execution
        """
        self._workflow_definition = None
        self._context = {}
        self._received_signals = {}
        self._current_node_id = None
        self._completed = False
        self._execution_order = []

    @workflow.run
    async def run(self, workflow_json: str) -> dict:
        """
        Execute a workflow defined in JSON.

        Args:
            workflow_json: JSON string defining the workflow

        Returns:
            dict: {
                "status": "completed",
                "context": {...},  # All node outputs
                "signals": {...}   # All received signals
            }

        Flow:
        1. Parse JSON definition
        2. Start at designated start node
        3. Loop through nodes:
           - Activity → execute function, store result
           - Signal → wait for external input, store data
           - Decision → evaluate condition, branch
        4. Return final context
        """
        # Parse workflow definition from JSON
        self._workflow_definition = json.loads(workflow_json)

        # Start execution at the designated start node
        current_node_id = self._workflow_definition["start"]

        # Build lookup map for fast node access
        steps_map = {step["id"]: step for step in self._workflow_definition["steps"]}

        # Execute workflow nodes sequentially
        while current_node_id is not None:
            self._current_node_id = current_node_id
            current_step = steps_map.get(current_node_id)

            if current_step is None:
                workflow.logger.warning(f"Node '{current_node_id}' not found. Ending workflow.")
                break

            workflow.logger.info(f"Executing node: {current_node_id} (type: {current_step['step_type']})")

            # Execute node based on its type
            if current_step["step_type"] == "activity":
                current_node_id = await self._execute_activity(current_step)
            elif current_step["step_type"] == "signal":
                current_node_id = await self._execute_signal(current_step)
            elif current_step["step_type"] == "decision":
                current_node_id = await self._execute_decision(current_step)
            else:
                workflow.logger.error(f"Unknown step type: {current_step['step_type']}")
                break

        # Mark workflow as completed
        self._completed = True

        # Return final results
        return {
            "status": "completed",
            "context": self._context,
            "signals": self._received_signals
        }

    async def _execute_activity(self, step: dict) -> str:
        """
        Execute an activity node.

        Activity nodes execute Python functions (activities) and store
        the result in the workflow context.

        Args:
            step: Node definition with activity name

        Returns:
            str: ID of next node to execute
        """
        node_id = step["id"]
        task = step["task"]
        activity_name = task["name"]

        # Map activity names to Python functions
        # TO ADD NEW ACTIVITIES: Add them to this map and import at top
        activity_map = {
            "review_application": review_application,
            "schedule_interviews": schedule_interviews,
            "aggregate_feedback": aggregate_feedback,
            "send_offer_email": send_offer_email,
            "send_rejection_email": send_rejection_email,
        }

        activity_func = activity_map.get(activity_name)
        if activity_func is None:
            workflow.logger.error(f"Activity '{activity_name}' not found!")
            return None

        # Execute the activity with retry policy
        workflow.logger.info(f"Executing activity: {activity_name}")
        result = await workflow.execute_activity(
            activity_func,
            start_to_close_timeout=timedelta(seconds=30),
            retry_policy=RetryPolicy(maximum_attempts=3),
        )

        # Store result in context for use in decisions
        self._context[node_id] = result
        workflow.logger.info(f"Activity result stored in context['{node_id}']: {result}")

        # Return next node ID
        return step.get("next")

    async def _execute_signal(self, step: dict) -> str:
        """
        Execute a signal node - wait for external input.

        Signal nodes pause the workflow until external input arrives.
        Common use cases: human approval, webhook callback, manual trigger.

        Args:
            step: Node definition

        Returns:
            str: ID of next node (may branch based on signal data)
        """
        node_id = step["id"]

        workflow.logger.info(f"Waiting for signal at node: {node_id}")

        # Wait for signal to arrive (workflow pauses here)
        await workflow.wait_condition(lambda: node_id in self._received_signals)

        # Retrieve and store signal data
        signal_data = self._received_signals[node_id]
        self._context[node_id] = signal_data
        workflow.logger.info(f"Signal received at '{node_id}': {signal_data}")

        # Check if this signal has branching logic
        if "branch" in step:
            return self._evaluate_branch(step["branch"])
        else:
            return step.get("next")

    async def _execute_decision(self, step: dict) -> str:
        """
        Execute a decision node - branch based on context.

        Decision nodes evaluate a Python expression against the
        workflow context and branch accordingly.

        Args:
            step: Node definition with branch condition

        Returns:
            str: ID of next node based on condition
        """
        node_id = step["id"]
        workflow.logger.info(f"Evaluating decision at node: {node_id}")

        return self._evaluate_branch(step["branch"])

    def _evaluate_branch(self, branch: dict) -> str:
        """
        Evaluate a branch condition.

        Args:
            branch: Dict with "if", "true_next", "false_next"

        Returns:
            str: Next node ID based on condition result
        """
        condition = branch["if"]
        workflow.logger.info(f"Condition: {condition}")

        try:
            # Create safe evaluation context
            # Only allows access to workflow context, no builtins
            eval_context = {"context": self._context}
            result = eval(condition, {"__builtins__": {}}, eval_context)

            if result:
                workflow.logger.info(f"Condition TRUE -> {branch['true_next']}")
                return branch["true_next"]
            else:
                workflow.logger.info(f"Condition FALSE -> {branch['false_next']}")
                return branch["false_next"]
        except Exception as e:
            workflow.logger.error(f"Error evaluating condition '{condition}': {e}")
            # Default to false path on error
            return branch.get("false_next")

    @workflow.signal
    async def send_signal(self, node_id: str, data: dict) -> None:
        """
        Signal handler - receive external input.

        External systems send signals to provide data to waiting workflows.

        Args:
            node_id: Which signal node this data is for
            data: Signal payload (any dict)

        Example:
            await handle.signal(
                "send_signal",
                node_id="hr_interview",
                data={"decision": "approve", "comments": "Great!"}
            )
        """
        workflow.logger.info(f"Signal received for node '{node_id}': {data}")
        self._received_signals[node_id] = data

    @workflow.query
    def get_status(self) -> dict:
        """
        Query - get current workflow execution status.

        Returns:
            dict: Current state with:
                - current_node_id: Which node is executing
                - completed: Whether finished
                - context: All collected data
                - received_signals: All signals received
        """
        return {
            "current_node_id": self._current_node_id,
            "completed": self._completed,
            "context": self._context,
            "received_signals": self._received_signals,
        }

    @workflow.query
    def get_context(self) -> dict:
        """
        Query - get workflow context only.

        Returns:
            dict: Context containing all node outputs
        """
        return self._context
