"""
Temporal Worker - Data-Driven Workflow Engine

This worker executes the DataDrivenWorkflowEngine, which allows you to define
complete workflows in JSON without writing any code.

Key Concepts:
- Worker: A process that polls Temporal for workflow tasks to execute
- Task Queue: A named queue where tasks are placed ("hello-tasks")
- The worker registers the workflow engine and all available activities
- When a workflow is started via JSON definition, Temporal dispatches it to this worker
- The worker executes the workflow according to the JSON definition

Workflow Engine Features:
- Define workflows in JSON (no code deployment needed)
- Supports activities (execute functions)
- Supports signals (wait for external input)
- Supports decisions (branch based on conditions)
- All workflow state is durable and replayable
"""

import asyncio  # Python's async/await library for concurrent programming
import os  # For reading environment variables
from temporalio.client import Client  # Temporal client to connect to the server
from temporalio.worker import Worker  # The worker that executes workflows/activities

# Import the workflow engine and its activities
from workflows import DataDrivenWorkflowEngine
from activities import (
    review_application,
    schedule_interviews,
    aggregate_feedback,
    send_offer_email,
    send_rejection_email,
)


async def main():
    """
    Main function that sets up and runs the worker.

    This function:
    1. Connects to the Temporal server
    2. Registers the DataDrivenWorkflowEngine and its activities
    3. Starts polling for workflow tasks
    4. Executes workflows according to their JSON definitions
    """

    # Get Temporal server address from environment variable
    # Default to "localhost:7233" if not set
    # This allows flexibility for different environments (dev, prod, docker)
    temporal_host = os.getenv("TEMPORAL_HOST", "localhost:7233")

    # Connect to Temporal server
    # This establishes a connection to the Temporal cluster
    # 'await' means "wait for this operation to complete"
    client = await Client.connect(temporal_host)

    # Create and configure the worker
    # The worker registers:
    # 1. The DataDrivenWorkflowEngine (executes JSON-defined workflows)
    # 2. All available activities that can be called from workflows
    worker = Worker(
        client,  # The Temporal server connection
        task_queue="hello-tasks",  # The queue name (must match gateway)
        workflows=[
            DataDrivenWorkflowEngine,  # The only workflow - everything runs through this
        ],
        activities=[
            # All activities available to the workflow engine
            review_application,
            schedule_interviews,
            aggregate_feedback,
            send_offer_email,
            send_rejection_email,
        ],
    )

    # Print confirmation messages
    print("=" * 60)
    print("Data-Driven Workflow Engine Worker Started")
    print("=" * 60)
    print(f"Task Queue: hello-tasks")
    print(f"Temporal Server: {temporal_host}")
    print(f"Registered Workflows: DataDrivenWorkflowEngine")
    print(f"Registered Activities: 5 activities")
    print("  - review_application")
    print("  - schedule_interviews")
    print("  - aggregate_feedback")
    print("  - send_offer_email")
    print("  - send_rejection_email")
    print("=" * 60)
    print("Worker is ready to execute JSON-defined workflows...")
    print("=" * 60)

    # Start the worker and keep it running
    # This is a blocking call - the worker continuously polls Temporal
    # for workflow tasks to execute
    await worker.run()


# Standard Python pattern: only run main() if this file is executed directly
# (not if it's imported as a module)
if __name__ == "__main__":
    # Run the async main function
    # asyncio.run() is the entry point for async programs
    asyncio.run(main())
