# Data-Driven Workflow Engine

A flexible, JSON-configurable workflow engine built on Temporal Python SDK that allows you to define and execute complex workflows without writing code.

## Overview

This workflow engine supports:

- **Activities**: Pure work functions (sending emails, processing data, API calls)
- **Signals**: Wait for external/human input (e.g., HR approval, user feedback)
- **Decision Nodes**: Branch based on workflow context
- **Linear Execution**: Sequential workflow execution (no parallel branches)

## Key Features

- **JSON-Defined Workflows**: Define workflows in JSON - no code changes needed
- **Context Storage**: All activity and signal outputs stored for decision-making
- **Deterministic**: Fully supports Temporal's replay requirements
- **Flexible**: Easy to add new activities or modify workflow structure
- **Human-in-the-Loop**: Wait for human input via signals at any point

## Workflow Definition Structure

```json
{
  "start": "first_node_id",
  "steps": [
    {
      "id": "unique_node_id",
      "step_type": "activity" | "signal" | "decision",
      "task": {
        "name": "function_name",
        "params": {}
      },
      "next": "next_node_id",
      "branch": {
        "if": "context['node_id']['field']=='value'",
        "true_next": "node_if_true",
        "false_next": "node_if_false"
      }
    }
  ]
}
```

## Node Types

### 1. Activity Node

Executes a Temporal activity (a function that does actual work).

```json
{
  "id": "review_application",
  "step_type": "activity",
  "task": {
    "name": "review_application",
    "params": {}
  },
  "next": "schedule_interviews"
}
```

**Available Activities:**
- `review_application`: Automatically review a job application
- `schedule_interviews`: Schedule interview sessions
- `aggregate_feedback`: Compile feedback from multiple sources
- `send_offer_email`: Send job offer to candidate
- `send_rejection_email`: Send rejection notification

### 2. Signal Node

Waits for external input (human decision, webhook, etc.).

```json
{
  "id": "hr_interview",
  "step_type": "signal",
  "task": {
    "name": "waitForSignal",
    "params": {}
  },
  "branch": {
    "if": "context['hr_interview']['decision']=='reject'",
    "true_next": "send_rejection",
    "false_next": "aggregate_feedback"
  }
}
```

**Key Points:**
- Workflow pauses until signal is received
- Can include branching logic based on signal data
- Signal data is stored in context for later use

### 3. Decision Node

Evaluates a condition and branches accordingly.

```json
{
  "id": "make_decision",
  "step_type": "decision",
  "branch": {
    "if": "context['aggregate_feedback']['decision']=='hire'",
    "true_next": "send_offer",
    "false_next": "send_rejection"
  }
}
```

**Key Points:**
- Evaluates Python expressions using workflow context
- No external input - purely logic-based
- Must have `branch` with `if`, `true_next`, and `false_next`

## Context System

The workflow engine maintains a **context dictionary** that stores outputs from all executed nodes.

```python
context = {
  "review_application": {
    "decision": "approve",
    "notes": "Strong candidate",
    "score": 85
  },
  "hr_interview": {
    "decision": "approve",
    "comments": "Great communication skills"
  },
  "aggregate_feedback": {
    "decision": "hire",
    "overall_score": 4.5
  }
}
```

You can reference context values in conditions:
- `context['node_id']['field']`
- `context['aggregate_feedback']['decision']=='hire'`
- `context['review_application']['score'] >= 80`

## Example Workflow: Job Interview Process

See `workflow_definition.json` for a complete example.

**Flow:**
1. `review_application` - Automatically review application
2. `schedule_interviews` - Schedule interview sessions
3. `hr_interview` - Wait for HR feedback (SIGNAL)
   - If rejected → go to `send_rejection`
   - If approved → continue to `aggregate_feedback`
4. `aggregate_feedback` - Compile all feedback
5. `make_decision` - Decide hire/reject (DECISION)
   - If hire → `send_offer`
   - If reject → `send_rejection`

## Usage

### 1. Start the Workflow

```python
import asyncio
import json
from temporalio.client import Client

async def start_workflow():
    client = await Client.connect("localhost:7233")

    # Load workflow definition
    with open("workflow_definition.json", "r") as f:
        workflow_json = f.read()

    # Start workflow
    handle = await client.start_workflow(
        "DataDrivenWorkflowEngine",
        workflow_json,
        id="my-workflow-001",
        task_queue="hello-tasks",
    )

    print(f"Workflow started: {handle.id}")
    return handle

asyncio.run(start_workflow())
```

### 2. Send a Signal

```python
async def send_hr_feedback():
    client = await Client.connect("localhost:7233")

    # Get workflow handle
    handle = client.get_workflow_handle("my-workflow-001")

    # Send signal
    await handle.signal(
        "send_signal",
        node_id="hr_interview",
        data={
            "decision": "approve",
            "comments": "Excellent candidate!"
        }
    )

    print("Signal sent successfully")

asyncio.run(send_hr_feedback())
```

### 3. Query Workflow Status

```python
async def check_status():
    client = await Client.connect("localhost:7233")
    handle = client.get_workflow_handle("my-workflow-001")

    # Query current status
    status = await handle.query("get_status")

    print(f"Current node: {status['current_node_id']}")
    print(f"Completed: {status['completed']}")
    print(f"Context: {status['context']}")

asyncio.run(check_status())
```

### 4. Wait for Completion

```python
async def wait_for_completion():
    client = await Client.connect("localhost:7233")
    handle = client.get_workflow_handle("my-workflow-001")

    # Wait for workflow to complete
    result = await handle.result()

    print(f"Status: {result['status']}")
    print(f"Final context: {result['context']}")

asyncio.run(wait_for_completion())
```

## Testing

Run the test script to see the workflow engine in action:

```bash
# Make sure Temporal server is running
docker compose up -d

# Start the worker in one terminal
cd worker
python worker.py

# Run the test script in another terminal
cd worker
python test_workflow_engine.py
```

The test script will:
1. Start a workflow using the JSON definition
2. Query the workflow status
3. Send an HR approval signal
4. Wait for workflow completion
5. Display the final results

## Adding New Activities

To add a new activity to the workflow engine:

### 1. Define the Activity in `activities.py`

```python
@activity.defn
async def my_new_activity() -> dict:
    """
    Description of what this activity does.

    Returns:
        dict: Result data
    """
    logger.info("Executing my_new_activity...")

    result = {
        "status": "success",
        "data": "some data"
    }

    return result
```

### 2. Import in `workflows.py`

```python
with workflow.unsafe.imports_passed_through():
    from activities import (
        # ... existing imports
        my_new_activity,  # Add this
    )
```

### 3. Register in Worker (`worker.py`)

```python
from activities import (
    # ... existing imports
    my_new_activity,  # Add this
)

worker = Worker(
    client,
    task_queue="hello-tasks",
    workflows=[DataDrivenWorkflowEngine],
    activities=[
        # ... existing activities
        my_new_activity,  # Add this
    ],
)
```

### 4. Add to Activity Map in Workflow Engine

In `workflows.py`, update the `_execute_activity` method:

```python
activity_map = {
    # ... existing activities
    "my_new_activity": my_new_activity,
}
```

### 5. Use in JSON Workflow

```json
{
  "id": "my_step",
  "step_type": "activity",
  "task": {
    "name": "my_new_activity",
    "params": {}
  },
  "next": "next_step"
}
```

## Architecture

```
┌─────────────────────────────────────────┐
│  JSON Workflow Definition               │
│  (workflow_definition.json)             │
└─────────────────┬───────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────┐
│  DataDrivenWorkflowEngine               │
│  - Parses JSON                          │
│  - Manages context                      │
│  - Executes nodes sequentially          │
│  - Handles signals                      │
└─────────────────┬───────────────────────┘
                  │
        ┌─────────┼─────────┐
        │         │         │
        ▼         ▼         ▼
    Activity   Signal   Decision
    Node       Node      Node
        │         │         │
        ▼         ▼         ▼
    Execute   Wait for   Evaluate
    Function  External   Condition
              Input
```

## Best Practices

1. **Deterministic Activities**: Activities should return consistent outputs for the same inputs
2. **Context Keys**: Use descriptive node IDs - they become context keys
3. **Error Handling**: Activities will retry automatically (configured in workflow)
4. **Signal Data**: Always include meaningful data in signals for decision-making
5. **Condition Expressions**: Keep conditions simple and safe (no complex operations)

## Limitations

1. **Linear Flow Only**: No parallel execution of branches
2. **Python Expressions**: Conditions use Python eval (limited to context access)
3. **No Loops**: Workflows execute once through the node graph
4. **Fixed Activities**: Activity map must be updated in code (not fully dynamic)

## Future Enhancements

Possible improvements:
- [ ] Support for parallel branches
- [ ] Loop/iteration support
- [ ] Dynamic activity loading
- [ ] More complex expressions (multiple conditions)
- [ ] Timeout handling for signals
- [ ] Activity parameter passing from context
- [ ] Sub-workflow support

## Troubleshooting

**Workflow not starting:**
- Ensure Temporal server is running
- Check that worker is running and connected
- Verify workflow name matches class name

**Signal not working:**
- Confirm workflow is at the signal node (query status)
- Ensure node_id matches the JSON definition
- Check signal data format matches expectations

**Context not available:**
- Node must have executed before context is available
- Use queries to check what's in context
- Verify node IDs are unique and consistent

## Files

- `workflows.py`: Contains `DataDrivenWorkflowEngine` class
- `activities.py`: Contains all activity functions
- `worker.py`: Registers workflows and activities
- `workflow_definition.json`: Example workflow definition
- `test_workflow_engine.py`: Test script with examples
- `WORKFLOW_ENGINE_README.md`: This documentation

## Learn More

- [Temporal Python SDK Documentation](https://docs.temporal.io/dev-guide/python)
- [Temporal Workflows](https://docs.temporal.io/workflows)
- [Temporal Activities](https://docs.temporal.io/activities)
- [Temporal Signals](https://docs.temporal.io/workflows#signal)
