# Data-Driven Workflow Engine with Temporal

A production-ready implementation of a data-driven workflow engine using Temporal. Define complete workflows in JSON without writing code - perfect for configurable approval processes, multi-stage workflows, and human-in-the-loop operations.

## Architecture Overview

```
┌──────────────────────────────────────────────────────────────┐
│                    USER INTERFACE                            │
│  Next.js Frontend (port 3000)                                │
│  - JSON workflow editor                                      │
│  - Workflow execution monitoring                             │
│  - Signal sending interface                                  │
└─────────────────────────┬────────────────────────────────────┘
                          │
                          ▼
┌──────────────────────────────────────────────────────────────┐
│              APPLICATION BACKEND (port 8000)                 │
│  - Main business logic API                                   │
│  - Authentication & authorization (future)                   │
│  - Workflow definition validation                            │
│  - Routes: /api/workflows/engine/*                           │
│  - Orchestrates calls to Temporal Gateway                    │
└─────────────────────────┬────────────────────────────────────┘
                          │
                          ▼
┌──────────────────────────────────────────────────────────────┐
│           TEMPORAL GATEWAY (port 8001 - internal)            │
│  - Thin wrapper around Temporal SDK                          │
│  - Pure workflow operations only                             │
│  - Start workflows, send signals, query status               │
│  - No business logic                                         │
└─────────────────────────┬────────────────────────────────────┘
                          │
                          ▼
┌──────────────────────────────────────────────────────────────┐
│             TEMPORAL SERVER (port 7233)                      │
│  - Workflow orchestration engine                             │
│  - Postgres for persistence                                  │
│  - Web UI (port 8233)                                        │
└─────────────────────────┬────────────────────────────────────┘
                          │
                          ▼
┌──────────────────────────────────────────────────────────────┐
│                  TEMPORAL WORKER                             │
│  - Executes DataDrivenWorkflowEngine                         │
│  - Supports activities, signals, and decisions               │
│  - All workflow state stored and replayable                  │
└──────────────────────────────────────────────────────────────┘
```

## Key Features

### Data-Driven Workflow Engine

Define complete workflows in JSON without writing any code:

- **Activities**: Execute functions (send emails, process data, API calls)
- **Signals**: Wait for external input (human approval, webhook callbacks)
- **Decisions**: Branch based on conditions
- **Durable**: Workflow state persists across server restarts
- **Replayable**: Full execution history for debugging

### Clean Architecture

- **Frontend**: User interface only, no business logic
- **App Backend**: Business logic, validation, authentication layer
- **Temporal Gateway**: Internal-only Temporal SDK wrapper
- **Worker**: Workflow execution only

### Production-Ready

- Docker Compose orchestration
- Separate scaling for each layer
- Security-first architecture (gateway not exposed to internet)
- Comprehensive logging and monitoring via Temporal Web UI

## Project Structure

```
temporal-sample/
├── docker-compose.yml           # All services orchestration
├── README.md                    # This file
│
├── frontend/                    # Next.js UI (TypeScript)
│   ├── Dockerfile
│   ├── package.json
│   ├── next.config.js
│   └── app/
│       ├── page.tsx                  # Redirect to workflow engine
│       └── workflow-engine/page.tsx  # Workflow engine UI
│
├── app-backend/                 # Main application backend (Python/FastAPI)
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── main.py                       # FastAPI app
│   ├── api/
│   │   └── workflows.py              # Workflow engine API routes
│   └── services/
│       └── temporal_client.py        # HTTP client to Temporal Gateway
│
├── temporal-gateway/            # Temporal operations only (Python/FastAPI)
│   ├── Dockerfile
│   ├── requirements.txt
│   └── main.py                       # Temporal SDK wrapper
│
└── worker/                      # Temporal worker (Python)
    ├── Dockerfile
    ├── requirements.txt
    ├── worker.py                     # Worker registration
    ├── workflows.py                  # DataDrivenWorkflowEngine
    ├── activities.py                 # Activity implementations
    └── workflow_definition.json      # Example workflow definition
```

## Getting Started

### Prerequisites

- Docker
- Docker Compose

### Running the Application

1. Navigate to the project directory:
```bash
cd temporal-sample
```

2. Build and start all services:
```bash
docker-compose up --build
```

3. Wait for all services to start (1-2 minutes)

4. Access the application:
   - **Frontend**: http://localhost:3000
   - **App Backend API**: http://localhost:8000
   - **Temporal Gateway** (internal): http://localhost:8001
   - **Temporal Web UI**: http://localhost:8233

### Using the Workflow Engine

1. Open http://localhost:3000 (auto-redirects to workflow engine)

2. Review or edit the JSON workflow definition

3. Click "Start Workflow Engine"

4. Watch as activities execute automatically

5. When workflow waits at a signal node:
   - Enter node ID (e.g., `hr_interview`)
   - Enter signal data: `{"decision": "approve", "comments": "Great!"}`
   - Click "Send Signal"

6. Workflow continues and completes

7. View execution history in Temporal Web UI: http://localhost:8233

## Workflow Definition Structure

Workflows are defined in JSON with three node types:

### 1. Activity Node
Executes a function:
```json
{
  "id": "review_application",
  "step_type": "activity",
  "task": {
    "name": "review_application",
    "params": {}
  },
  "next": "schedule_interviews"
}
```

### 2. Signal Node
Waits for external input:
```json
{
  "id": "hr_interview",
  "step_type": "signal",
  "task": {
    "name": "waitForSignal",
    "params": {}
  },
  "branch": {
    "if": "context['hr_interview']['decision']=='reject'",
    "true_next": "send_rejection",
    "false_next": "aggregate_feedback"
  }
}
```

### 3. Decision Node
Branches based on context:
```json
{
  "id": "make_decision",
  "step_type": "decision",
  "branch": {
    "if": "context['aggregate_feedback']['decision']=='hire'",
    "true_next": "send_offer",
    "false_next": "send_rejection"
  }
}
```

### Complete Workflow Example

See `worker/workflow_definition.json` for a complete job interview workflow.

## Available Activities

Activities that can be referenced in workflow definitions:

- `review_application` - Automatically review application
- `schedule_interviews` - Schedule interview sessions
- `aggregate_feedback` - Compile feedback from interviews
- `send_offer_email` - Send job offer to candidate
- `send_rejection_email` - Send rejection notification

### Adding New Activities

1. Define activity in `worker/activities.py`:
```python
@activity.defn
async def my_new_activity(param: str) -> dict:
    # Do work here
    return {"result": "success"}
```

2. Add to worker registration in `worker/worker.py`:
```python
activities=[
    review_application,
    my_new_activity,  # Add here
    ...
]
```

3. Add to activity map in `worker/workflows.py`:
```python
activity_map = {
    "review_application": review_application,
    "my_new_activity": my_new_activity,  # Add here
    ...
}
```

4. Reference in JSON workflow:
```json
{
  "id": "my_node",
  "step_type": "activity",
  "task": {
    "name": "my_new_activity",
    "params": {}
  },
  "next": "next_node"
}
```

## API Documentation

### Workflow Engine Endpoints

All endpoints are prefixed with `/api/workflows/engine/`

**POST /api/workflows/engine/start**
```json
Request: {
  "workflow_definition": {
    "start": "first_node",
    "steps": [...]
  },
  "workflow_id": "optional-custom-id"
}

Response: {
  "workflow_id": "workflow-engine-uuid"
}
```

**GET /api/workflows/engine/status/{workflow_id}**
```json
Response: {
  "workflow_id": "...",
  "current_node_id": "hr_interview",
  "completed": false,
  "context": {...},
  "result": null
}
```

**POST /api/workflows/engine/signal**
```json
Request: {
  "workflow_id": "workflow-engine-uuid",
  "node_id": "hr_interview",
  "data": {
    "decision": "approve",
    "comments": "Looks good"
  }
}

Response: {
  "message": "Signal sent successfully"
}
```

## Architecture Benefits

### Separation of Concerns

**Frontend** → User Interface only
- No business logic
- No Temporal knowledge
- Just API calls and state management

**App Backend** → Business logic layer
- Authentication & authorization (future)
- Data validation
- Business rules
- Decides when to use workflows

**Temporal Gateway** → Pure workflow operations
- Thin wrapper around Temporal SDK
- No business logic
- Internal service only
- Easy to replace or upgrade

**Worker** → Workflow execution only
- Executes workflow engine
- Runs activities
- Deterministic execution
- Automatic retries

### Scalability

Each service scales independently:

```bash
# Scale app backend for high traffic
docker-compose up --scale app-backend=3

# Scale worker for heavy workflow load
docker-compose up --scale worker=5
```

### Security

- Temporal Gateway NOT exposed to internet
- App Backend controls all access to workflows
- Easy to add authentication layer
- Can rate limit workflow creation

### Flexibility

- Define new workflows without code deployment
- A/B test different workflow variants
- Store workflow definitions in database
- Version control workflows as data
- Business users can configure workflows

## Development

### Modifying Services

**Frontend:**
```bash
# Edit files in frontend/app/
docker-compose up --build frontend
```

**App Backend:**
```bash
# Edit app-backend/api/workflows.py or main.py
docker-compose restart app-backend
```

**Temporal Gateway:**
```bash
# Edit temporal-gateway/main.py
docker-compose restart temporal-gateway
```

**Worker:**
```bash
# Edit worker/workflows.py or activities.py
docker-compose restart worker
```

### Viewing Logs

```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f app-backend
docker-compose logs -f worker
```

## Stopping the Application

```bash
# Stop services
docker-compose down

# Remove volumes (Postgres data)
docker-compose down -v
```

## Troubleshooting

### Services not starting
```bash
# Check logs
docker-compose logs -f

# Ensure Docker has enough resources (4GB RAM recommended)
```

### Port conflicts
```bash
# Check if ports are in use
netstat -an | grep "8000\|8001\|3000"

# Change ports in docker-compose.yml if needed
```

### Worker connection issues
```bash
# Worker waits for Temporal server to be healthy
docker-compose logs temporal

# Check worker logs
docker-compose logs worker
```

## Technologies Used

- **Frontend**: Next.js 14, React 18, TypeScript
- **App Backend**: FastAPI, Python 3.11, httpx
- **Temporal Gateway**: FastAPI, Temporal Python SDK 1.5.1
- **Worker**: Temporal Python SDK 1.5.1
- **Database**: PostgreSQL 13
- **Containerization**: Docker, Docker Compose

## Use Cases

This workflow engine is perfect for:

- **Approval Workflows**: Multi-stage approval processes with branching logic
- **Human-in-the-Loop**: Workflows that require human input at specific stages
- **Job Interviews**: Multi-round interview processes with feedback collection
- **Order Processing**: Complex order workflows with payment, fulfillment, shipping
- **Content Moderation**: Review workflows with escalation paths
- **Onboarding**: Employee or customer onboarding with multiple steps
- **Document Approval**: Contract or document review workflows

## Key Concepts

### Workflows
Durable, long-running processes that coordinate activities. Can wait for signals (days, weeks, months) and survive server restarts.

### Activities
Individual units of work (send email, call API, process data). Automatically retry on failure.

### Signals
External inputs to workflows. Allows human-in-the-loop processes.

### Queries
Read workflow state without modifying it. Great for status checks.

### Task Queue
Named queue where workflows and activities are distributed. Workers poll task queues for work.

## Learning Resources

- See `worker/WORKFLOW_ENGINE_README.md` for detailed workflow engine docs
- [Temporal Documentation](https://docs.temporal.io/)
- [Temporal Python SDK](https://docs.temporal.io/dev-guide/python)

## License

This is a demonstration project for educational purposes.
