'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function Home() {
  const router = useRouter();

  useEffect(() => {
    // Redirect to workflow engine page
    router.push('/workflow-engine');
  }, [router]);

  return (
    <main style={styles.main}>
      <div style={styles.container}>
        <h1 style={styles.title}>Data-Driven Workflow Engine</h1>
        <p style={styles.text}>Redirecting to workflow engine...</p>
        <p style={styles.text}>
          <a href="/workflow-engine" style={styles.link}>
            Click here if not redirected automatically
          </a>
        </p>
      </div>
    </main>
  );
}

const styles: { [key: string]: React.CSSProperties } = {
  main: {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f5f5f5',
  },
  container: {
    maxWidth: '600px',
    backgroundColor: 'white',
    padding: '3rem',
    borderRadius: '8px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    textAlign: 'center',
  },
  title: {
    fontSize: '2rem',
    fontWeight: 'bold',
    marginBottom: '1.5rem',
    color: '#333',
  },
  text: {
    fontSize: '1rem',
    color: '#666',
    marginBottom: '1rem',
  },
  link: {
    color: '#0070f3',
    textDecoration: 'none',
  },
};
