'use client';

import { useState, useEffect } from 'react';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

// Example workflow definitions
const SIMPLE_LINEAR = {
  "name": "Simple Linear Workflow",
  "description": "A straightforward 3-step workflow with no branching. Perfect for getting started.",
  "start": "review",
  "steps": [
    {
      "id": "review",
      "step_type": "activity",
      "task": {
        "name": "review_application",
        "params": {}
      },
      "next": "schedule"
    },
    {
      "id": "schedule",
      "step_type": "activity",
      "task": {
        "name": "schedule_interviews",
        "params": {}
      },
      "next": "send_offer"
    },
    {
      "id": "send_offer",
      "step_type": "activity",
      "task": {
        "name": "send_offer_email",
        "params": {}
      },
      "next": null
    }
  ]
};

const MEDIUM_APPROVAL = {
  "name": "Medium: Approval Workflow",
  "description": "A workflow that waits for human approval before proceeding. Demonstrates signals and basic branching.",
  "start": "review",
  "steps": [
    {
      "id": "review",
      "step_type": "activity",
      "task": {
        "name": "review_application",
        "params": {}
      },
      "next": "wait_for_approval"
    },
    {
      "id": "wait_for_approval",
      "step_type": "signal",
      "task": {
        "name": "waitForSignal",
        "params": {
          "signal_name": "manager_approval"
        }
      },
      "branch": {
        "if": "context['wait_for_approval']['decision']=='approve'",
        "true_next": "schedule",
        "false_next": "send_rejection"
      }
    },
    {
      "id": "schedule",
      "step_type": "activity",
      "task": {
        "name": "schedule_interviews",
        "params": {}
      },
      "next": "send_offer"
    },
    {
      "id": "send_offer",
      "step_type": "activity",
      "task": {
        "name": "send_offer_email",
        "params": {}
      },
      "next": null
    },
    {
      "id": "send_rejection",
      "step_type": "activity",
      "task": {
        "name": "send_rejection_email",
        "params": {}
      },
      "next": null
    }
  ]
};

const COMPLEX_MULTI_STAGE = {
  "name": "Complex: Multi-Stage Interview Process",
  "description": "A complete job interview workflow with multiple approval stages, decision branching, and feedback aggregation. This demonstrates the full power of the workflow engine.",
  "start": "review_application",
  "steps": [
    {
      "id": "review_application",
      "step_type": "activity",
      "task": {
        "name": "review_application",
        "params": {}
      },
      "next": "check_initial_review"
    },
    {
      "id": "check_initial_review",
      "step_type": "decision",
      "branch": {
        "if": "context['review_application']['score'] >= 70",
        "true_next": "schedule_interviews",
        "false_next": "send_rejection"
      }
    },
    {
      "id": "schedule_interviews",
      "step_type": "activity",
      "task": {
        "name": "schedule_interviews",
        "params": {}
      },
      "next": "hr_interview"
    },
    {
      "id": "hr_interview",
      "step_type": "signal",
      "task": {
        "name": "waitForSignal",
        "params": {
          "signal_name": "hr_feedback"
        }
      },
      "branch": {
        "if": "context['hr_interview']['decision']=='reject'",
        "true_next": "send_rejection",
        "false_next": "technical_interview"
      }
    },
    {
      "id": "technical_interview",
      "step_type": "signal",
      "task": {
        "name": "waitForSignal",
        "params": {
          "signal_name": "technical_feedback"
        }
      },
      "branch": {
        "if": "context['technical_interview']['decision']=='reject'",
        "true_next": "send_rejection",
        "false_next": "final_interview"
      }
    },
    {
      "id": "final_interview",
      "step_type": "signal",
      "task": {
        "name": "waitForSignal",
        "params": {
          "signal_name": "final_feedback"
        }
      },
      "branch": {
        "if": "context['final_interview']['decision']=='reject'",
        "true_next": "send_rejection",
        "false_next": "aggregate_feedback"
      }
    },
    {
      "id": "aggregate_feedback",
      "step_type": "activity",
      "task": {
        "name": "aggregate_feedback",
        "params": {}
      },
      "next": "make_final_decision"
    },
    {
      "id": "make_final_decision",
      "step_type": "decision",
      "branch": {
        "if": "context['aggregate_feedback']['decision']=='hire'",
        "true_next": "send_offer",
        "false_next": "send_rejection"
      }
    },
    {
      "id": "send_offer",
      "step_type": "activity",
      "task": {
        "name": "send_offer_email",
        "params": {}
      },
      "next": null
    },
    {
      "id": "send_rejection",
      "step_type": "activity",
      "task": {
        "name": "send_rejection_email",
        "params": {}
      },
      "next": null
    }
  ]
};

const EXAMPLE_WORKFLOWS = {
  simple: SIMPLE_LINEAR,
  medium: MEDIUM_APPROVAL,
  complex: COMPLEX_MULTI_STAGE,
};

interface WorkflowStatus {
  workflow_id: string;
  current_node_id: string | null;
  completed: boolean;
  context: Record<string, any>;
  result?: any;
}

export default function WorkflowEngine() {
  const [selectedExample, setSelectedExample] = useState<'simple' | 'medium' | 'complex'>('simple');
  const [workflowJson, setWorkflowJson] = useState(JSON.stringify(SIMPLE_LINEAR, null, 2));
  const [workflowId, setWorkflowId] = useState<string | null>(null);
  const [status, setStatus] = useState<WorkflowStatus | null>(null);
  const [signalNodeId, setSignalNodeId] = useState('');
  const [signalData, setSignalData] = useState('{"decision": "approve", "comments": "Looks good!"}');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Auto-refresh status when workflow is running
  useEffect(() => {
    if (!workflowId || status?.completed) return;

    const interval = setInterval(() => {
      refreshStatus();
    }, 2000); // Refresh every 2 seconds

    return () => clearInterval(interval);
  }, [workflowId, status?.completed]);

  const startWorkflow = async () => {
    setError(null);
    setLoading(true);

    try {
      // Parse and validate JSON
      const workflowDefinition = JSON.parse(workflowJson);

      const response = await fetch(`${API_URL}/api/workflows/engine/start`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          workflow_definition: workflowDefinition,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Failed to start workflow');
      }

      const data = await response.json();
      setWorkflowId(data.workflow_id);

      // Immediately fetch status
      setTimeout(() => refreshStatus(), 500);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  const refreshStatus = async () => {
    if (!workflowId) return;

    try {
      const response = await fetch(`${API_URL}/api/workflows/engine/status/${workflowId}`);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Failed to fetch workflow status');
      }

      const data = await response.json();
      setStatus(data);
    } catch (err) {
      console.error('Error refreshing status:', err);
    }
  };

  const sendSignal = async () => {
    if (!workflowId || !signalNodeId.trim()) {
      setError('Please enter a node ID');
      return;
    }

    setError(null);
    setLoading(true);

    try {
      // Parse and validate signal data JSON
      const data = JSON.parse(signalData);

      const response = await fetch(`${API_URL}/api/workflows/engine/signal`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          workflow_id: workflowId,
          node_id: signalNodeId.trim(),
          data: data,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Failed to send signal');
      }

      // Immediately refresh status after signal
      setTimeout(() => refreshStatus(), 500);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setWorkflowId(null);
    setStatus(null);
    setSignalNodeId('');
    setError(null);
  };

  const loadExample = (example: 'simple' | 'medium' | 'complex') => {
    setSelectedExample(example);
    setWorkflowJson(JSON.stringify(EXAMPLE_WORKFLOWS[example], null, 2));
  };

  return (
    <main style={styles.main}>
      <div style={styles.container}>
        <h1 style={styles.title}>Data-Driven Workflow Engine</h1>
        <p style={styles.description}>
          Define workflows in JSON without writing code. Supports activities, signals, and decision branching.
        </p>

        {error && (
          <div style={styles.error}>
            Error: {error}
          </div>
        )}

        {!workflowId ? (
          <div>
            <div style={styles.section}>
              <h2 style={styles.subtitle}>Choose an Example Workflow</h2>
              <div style={styles.exampleSelector}>
                <div style={styles.exampleGrid}>
                  <div
                    style={{
                      ...styles.exampleCard,
                      ...(selectedExample === 'simple' ? styles.exampleCardSelected : {})
                    }}
                    onClick={() => loadExample('simple')}
                  >
                    <div style={styles.exampleBadge}>⭐ Easy</div>
                    <h3 style={styles.exampleTitle}>Simple Linear</h3>
                    <p style={styles.exampleDescription}>
                      3 automatic steps, no user input needed. Perfect for getting started!
                    </p>
                    <p style={styles.exampleDuration}>⏱️ ~5 seconds</p>
                  </div>

                  <div
                    style={{
                      ...styles.exampleCard,
                      ...(selectedExample === 'medium' ? styles.exampleCardSelected : {})
                    }}
                    onClick={() => loadExample('medium')}
                  >
                    <div style={styles.exampleBadge}>⭐⭐ Medium</div>
                    <h3 style={styles.exampleTitle}>Approval Required</h3>
                    <p style={styles.exampleDescription}>
                      Workflow pauses for your approval decision. Learn signals & branching.
                    </p>
                    <p style={styles.exampleDuration}>⏱️ ~30 seconds</p>
                  </div>

                  <div
                    style={{
                      ...styles.exampleCard,
                      ...(selectedExample === 'complex' ? styles.exampleCardSelected : {})
                    }}
                    onClick={() => loadExample('complex')}
                  >
                    <div style={styles.exampleBadge}>⭐⭐⭐ Complex</div>
                    <h3 style={styles.exampleTitle}>Multi-Stage Interview</h3>
                    <p style={styles.exampleDescription}>
                      3 approval stages, decision branching, early exits. Full power demo!
                    </p>
                    <p style={styles.exampleDuration}>⏱️ 2-3 minutes</p>
                  </div>
                </div>
              </div>
            </div>

            <div style={styles.section}>
              <h2 style={styles.subtitle}>Workflow Definition (JSON)</h2>
              <textarea
                value={workflowJson}
                onChange={(e) => setWorkflowJson(e.target.value)}
                style={styles.textarea}
                placeholder="Enter your workflow definition JSON..."
              />
            </div>

            <button
              onClick={startWorkflow}
              disabled={loading}
              style={styles.button}
            >
              {loading ? 'Starting...' : 'Start Workflow Engine'}
            </button>
          </div>
        ) : (
          <div>
            <div style={styles.section}>
              <h2 style={styles.subtitle}>Workflow Status</h2>
              <div style={styles.statusCard}>
                <p><strong>Workflow ID:</strong> {workflowId}</p>
                <p><strong>Current Node:</strong> {status?.current_node_id || 'Loading...'}</p>
                <p><strong>Completed:</strong> {status?.completed ? 'Yes' : 'No'}</p>
              </div>

              {status?.context && Object.keys(status.context).length > 0 && (
                <div>
                  <h3 style={styles.subtitle}>Workflow Context</h3>
                  <pre style={styles.jsonDisplay}>
                    {JSON.stringify(status.context, null, 2)}
                  </pre>
                </div>
              )}

              {status?.result && (
                <div>
                  <h3 style={styles.subtitle}>Final Result</h3>
                  <pre style={styles.jsonDisplay}>
                    {JSON.stringify(status.result, null, 2)}
                  </pre>
                </div>
              )}
            </div>

            {!status?.completed && (
              <div style={styles.section}>
                <h2 style={styles.subtitle}>Send Signal to Workflow</h2>
                <p style={styles.hint}>
                  If the workflow is waiting at a signal node (e.g., "hr_interview"),
                  you can send a signal to continue execution.
                </p>

                <label style={styles.label}>Node ID:</label>
                <input
                  type="text"
                  value={signalNodeId}
                  onChange={(e) => setSignalNodeId(e.target.value)}
                  placeholder="e.g., hr_interview"
                  style={styles.input}
                />

                <label style={styles.label}>Signal Data (JSON):</label>
                <textarea
                  value={signalData}
                  onChange={(e) => setSignalData(e.target.value)}
                  style={{...styles.textarea, height: '100px'}}
                  placeholder='{"decision": "approve", "comments": "Great!"}'
                />

                <button
                  onClick={sendSignal}
                  disabled={loading || !signalNodeId.trim()}
                  style={styles.button}
                >
                  {loading ? 'Sending...' : 'Send Signal'}
                </button>
              </div>
            )}

            <div style={styles.section}>
              <button onClick={reset} style={styles.secondaryButton}>
                Start New Workflow
              </button>
            </div>
          </div>
        )}

        <div style={styles.footer}>
          <p>Temporal Web UI: <a href="http://localhost:8233" target="_blank" rel="noopener noreferrer" style={styles.link}>http://localhost:8233</a></p>
          <p style={{ marginTop: '0.5rem', fontSize: '0.75rem', color: '#999' }}>
            View workflow execution history and details in the Temporal Web UI
          </p>
        </div>
      </div>
    </main>
  );
}

const styles: { [key: string]: React.CSSProperties } = {
  main: {
    minHeight: '100vh',
    padding: '2rem',
    backgroundColor: '#f5f5f5',
  },
  container: {
    maxWidth: '900px',
    margin: '0 auto',
    backgroundColor: 'white',
    padding: '2rem',
    borderRadius: '8px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
  },
  title: {
    fontSize: '2rem',
    fontWeight: 'bold',
    marginBottom: '0.5rem',
    color: '#333',
  },
  description: {
    fontSize: '1rem',
    color: '#666',
    marginBottom: '1.5rem',
  },
  subtitle: {
    fontSize: '1.25rem',
    fontWeight: '600',
    marginBottom: '1rem',
    color: '#555',
  },
  section: {
    marginBottom: '2rem',
  },
  button: {
    backgroundColor: '#0070f3',
    color: 'white',
    padding: '0.75rem 1.5rem',
    border: 'none',
    borderRadius: '4px',
    fontSize: '1rem',
    cursor: 'pointer',
    width: '100%',
    transition: 'background-color 0.2s',
  },
  secondaryButton: {
    backgroundColor: '#6c757d',
    color: 'white',
    padding: '0.75rem 1.5rem',
    border: 'none',
    borderRadius: '4px',
    fontSize: '1rem',
    cursor: 'pointer',
    width: '100%',
    transition: 'background-color 0.2s',
  },
  smallButton: {
    backgroundColor: '#28a745',
    color: 'white',
    padding: '0.5rem 1rem',
    border: 'none',
    borderRadius: '4px',
    fontSize: '0.875rem',
    cursor: 'pointer',
    transition: 'background-color 0.2s',
  },
  input: {
    width: '100%',
    padding: '0.75rem',
    border: '1px solid #ddd',
    borderRadius: '4px',
    fontSize: '1rem',
    marginBottom: '1rem',
    boxSizing: 'border-box',
    fontFamily: 'system-ui, -apple-system, sans-serif',
  },
  textarea: {
    width: '100%',
    height: '400px',
    padding: '0.75rem',
    border: '1px solid #ddd',
    borderRadius: '4px',
    fontSize: '0.875rem',
    marginBottom: '1rem',
    boxSizing: 'border-box',
    fontFamily: 'monospace',
    resize: 'vertical',
  },
  label: {
    display: 'block',
    marginBottom: '0.5rem',
    fontWeight: '600',
    color: '#555',
  },
  statusCard: {
    backgroundColor: '#f8f9fa',
    padding: '1rem',
    borderRadius: '4px',
    marginBottom: '1rem',
  },
  jsonDisplay: {
    backgroundColor: '#f4f4f4',
    padding: '1rem',
    borderRadius: '4px',
    overflow: 'auto',
    fontSize: '0.875rem',
    fontFamily: 'monospace',
    border: '1px solid #ddd',
  },
  hint: {
    fontSize: '0.875rem',
    color: '#666',
    marginBottom: '1rem',
    fontStyle: 'italic',
  },
  error: {
    backgroundColor: '#ffebee',
    color: '#c62828',
    padding: '1rem',
    borderRadius: '4px',
    marginBottom: '1rem',
  },
  footer: {
    marginTop: '2rem',
    paddingTop: '1rem',
    borderTop: '1px solid #ddd',
    textAlign: 'center',
    color: '#666',
    fontSize: '0.875rem',
  },
  link: {
    color: '#0070f3',
    textDecoration: 'none',
  },
  exampleSelector: {
    marginTop: '1rem',
  },
  exampleGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '1rem',
  },
  exampleCard: {
    backgroundColor: '#f8f9fa',
    border: '2px solid #dee2e6',
    borderRadius: '8px',
    padding: '1.25rem',
    cursor: 'pointer',
    transition: 'all 0.2s',
    position: 'relative',
  },
  exampleCardSelected: {
    backgroundColor: '#e7f3ff',
    borderColor: '#0070f3',
    boxShadow: '0 4px 12px rgba(0, 112, 243, 0.15)',
  },
  exampleBadge: {
    display: 'inline-block',
    backgroundColor: '#ffc107',
    color: '#000',
    padding: '0.25rem 0.5rem',
    borderRadius: '4px',
    fontSize: '0.75rem',
    fontWeight: 'bold',
    marginBottom: '0.75rem',
  },
  exampleTitle: {
    fontSize: '1.125rem',
    fontWeight: '600',
    color: '#333',
    marginBottom: '0.5rem',
    marginTop: '0',
  },
  exampleDescription: {
    fontSize: '0.875rem',
    color: '#666',
    marginBottom: '0.75rem',
    lineHeight: '1.4',
  },
  exampleDuration: {
    fontSize: '0.75rem',
    color: '#888',
    marginBottom: '0',
  },
};
