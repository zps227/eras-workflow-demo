# Workflow Testing Guide

This guide will walk you through testing three example workflows of increasing complexity.

## Prerequisites

1. Make sure all services are running:
   ```bash
   docker compose up -d
   ```

2. Open the frontend at: http://localhost:3000

3. Have the Temporal Web UI open in another tab: http://localhost:8233

---

## Workflow 1: Simple Linear (No User Input Required)

**Difficulty**: Easy
**Duration**: ~5 seconds
**Description**: Three sequential activities with no branching or user interaction.

### Steps to Test:

1. Open `1_simple_linear.json` in your editor

2. Copy the entire JSON content

3. In the frontend at http://localhost:3000:
   - Paste the JSON into the workflow definition editor
   - Click "Start Workflow Engine"

4. **Watch it run automatically!** You'll see:
   - Status shows "review" → "schedule" → "send_offer"
   - Context grows as each activity completes
   - Final status: "Completed"

### What You'll See in Context:

```json
{
  "review": {
    "decision": "approve",
    "notes": "Application meets basic requirements",
    "score": 85
  },
  "schedule": {
    "hr_interview": "2025-10-20 10:00 AM",
    "tech_interview": "2025-10-22 2:00 PM",
    "final_interview": "2025-10-25 4:00 PM",
    "status": "scheduled"
  },
  "send_offer": {
    "status": "sent",
    "sent_at": "2025-10-26 9:00 AM",
    "offer_expires": "2025-11-02",
    "message": "Job offer has been sent to candidate"
  }
}
```

### Learning Points:
- ✅ Activities execute automatically
- ✅ Context accumulates data from each step
- ✅ Workflows can be completely automated
- ✅ "next" field controls flow

---

## Workflow 2: Medium - Approval Required

**Difficulty**: Medium
**Duration**: ~30 seconds (depends on you)
**Description**: Workflow pauses and waits for your approval decision.

### Steps to Test:

1. Open `2_medium_with_approval.json`

2. Copy and paste into the frontend

3. Click "Start Workflow Engine"

4. **The workflow will pause** at `wait_for_approval` node
   - Status will show: `"current_node_id": "wait_for_approval"`
   - Context will have the review result

5. **Send an Approval Signal**:
   - In the "Send Signal" section:
   - **Node ID**: `wait_for_approval`
   - **Signal Data** (to approve):
     ```json
     {
       "decision": "approve",
       "comments": "Candidate looks great!"
     }
     ```
   - Click "Send Signal"

6. **Watch it continue!**
   - Workflow proceeds to "schedule" → "send_offer"
   - Completes successfully

### Alternative Path - Rejection:

Repeat the test but send this signal instead:

```json
{
  "decision": "reject",
  "comments": "Not a good fit"
}
```

The workflow will branch to "send_rejection" instead!

### What You'll See in Context:

```json
{
  "review": { ... },
  "wait_for_approval": {
    "decision": "approve",
    "comments": "Candidate looks great!"
  },
  "schedule": { ... },
  "send_offer": { ... }
}
```

### Learning Points:
- ✅ Signal nodes pause workflows
- ✅ Human-in-the-loop workflows
- ✅ Branching based on signal data
- ✅ Workflows can wait indefinitely
- ✅ Context includes signal data

---

## Workflow 3: Complex Multi-Stage Interview

**Difficulty**: Complex
**Duration**: 2-3 minutes
**Description**: Full interview process with 3 approval stages, initial screening, and decision logic.

### Steps to Test:

1. Open `3_complex_multi_stage.json`

2. Copy and paste into the frontend

3. Click "Start Workflow Engine"

4. **Initial Review** (automatic)
   - Workflow automatically reviews application
   - Score is 85 (>= 70), so passes to interviews
   - If score was < 70, would go straight to rejection

5. **Schedules interviews** (automatic)
   - All interviews are scheduled

6. **HR Interview Stage** (PAUSE - needs your input)

   Current node: `hr_interview`

   **Send Signal:**
   - **Node ID**: `hr_interview`
   - **Signal Data**:
     ```json
     {
       "decision": "approve",
       "comments": "Great communication skills",
       "score": 9
     }
     ```

7. **Technical Interview Stage** (PAUSE - needs your input)

   Current node: `technical_interview`

   **Send Signal:**
   - **Node ID**: `technical_interview`
   - **Signal Data**:
     ```json
     {
       "decision": "approve",
       "comments": "Strong coding ability",
       "score": 8
     }
     ```

8. **Final Interview Stage** (PAUSE - needs your input)

   Current node: `final_interview`

   **Send Signal:**
   - **Node ID**: `final_interview`
   - **Signal Data**:
     ```json
     {
       "decision": "approve",
       "comments": "Culture fit is excellent",
       "score": 9
     }
     ```

9. **Aggregates Feedback** (automatic)
   - Workflow automatically aggregates all feedback
   - Makes hiring decision based on all inputs

10. **Final Decision** (automatic)
    - Since aggregate decision is "hire", sends offer
    - Workflow completes!

### Final Context Example:

```json
{
  "review_application": {
    "decision": "approve",
    "score": 85
  },
  "schedule_interviews": {
    "hr_interview": "2025-10-20 10:00 AM",
    "tech_interview": "2025-10-22 2:00 PM",
    "final_interview": "2025-10-25 4:00 PM"
  },
  "hr_interview": {
    "decision": "approve",
    "comments": "Great communication skills",
    "score": 9
  },
  "technical_interview": {
    "decision": "approve",
    "comments": "Strong coding ability",
    "score": 8
  },
  "final_interview": {
    "decision": "approve",
    "comments": "Culture fit is excellent",
    "score": 9
  },
  "aggregate_feedback": {
    "decision": "hire",
    "overall_score": 4.5,
    "strengths": ["Strong technical skills", "Great culture fit"]
  },
  "send_offer": {
    "status": "sent",
    "message": "Job offer has been sent to candidate"
  }
}
```

### Alternative Paths to Test:

**Early Rejection at HR Stage:**
- Send `{"decision": "reject", "comments": "Not qualified"}` at hr_interview
- Workflow skips remaining interviews and sends rejection

**Rejection After All Interviews:**
- Approve all 3 interviews
- The aggregate_feedback activity might decide "hire" or not
- (Currently it always returns "hire", but in real app would be based on scores)

### Learning Points:
- ✅ Multiple sequential signals
- ✅ Complex branching logic
- ✅ Early exit paths (reject at any stage)
- ✅ Decision nodes evaluate context
- ✅ Long-running workflows with multiple pauses
- ✅ Context accumulation across many steps

---

## Viewing in Temporal Web UI

For any workflow, go to http://localhost:8233 to see:

1. **Workflow Executions**: All running and completed workflows
2. **Event History**: Every activity, signal, decision with timestamps
3. **Stack Trace**: Current execution position
4. **Input/Output**: All data passed between nodes

This is incredibly valuable for debugging!

---

## Tips for Experimentation

### Create Your Own Workflows:

1. **Mix and Match**: Combine activities, signals, and decisions
2. **Add Branching**: Use decision nodes to check context values
3. **Multiple Approvals**: Chain several signal nodes together
4. **Parallel Paths**: (Not yet supported, but possible to add)

### Common Signal Patterns:

```json
// Simple approval
{
  "decision": "approve"
}

// Approval with feedback
{
  "decision": "approve",
  "comments": "Looks good",
  "score": 8
}

// Rejection
{
  "decision": "reject",
  "reason": "Not qualified"
}

// Custom data
{
  "action": "request_changes",
  "changes_needed": ["Fix typo", "Add more details"]
}
```

### Decision Node Examples:

```json
// Check score threshold
"if": "context['review']['score'] >= 80"

// Check string equality
"if": "context['approval']['decision']=='approve'"

// Multiple conditions (use 'and')
"if": "context['review']['score'] >= 70 and context['review']['decision']=='approve'"

// Check if field exists
"if": "'comments' in context['approval']"
```

---

## Troubleshooting

### Workflow stuck at signal node?
- Check the "Current Node" ID
- Make sure your signal **Node ID** exactly matches that ID
- Signal data must be valid JSON

### Workflow went to unexpected path?
- Check the decision node's condition
- Verify the context data matches what the condition expects
- Look at the Temporal Web UI to see the exact decision made

### Workflow failed?
- Check worker logs: `docker compose logs worker`
- Check if activity name is misspelled
- Verify JSON syntax is valid

---

## Next Steps

After testing these examples:

1. **Modify Existing Workflows**: Change branching logic, add steps
2. **Create Your Own**: Design a workflow for your use case
3. **Add New Activities**: Extend worker/activities.py
4. **Store in Database**: Save workflow definitions for reuse
5. **Version Control**: Track workflow definitions as data

Happy workflow building! 🚀
