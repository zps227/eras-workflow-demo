"""
Temporal Activities - Workflow Engine Activities

Activities are individual units of work that can be executed by workflows.
These activities are available to the DataDrivenWorkflowEngine and can be
referenced in JSON workflow definitions.

Key Concepts:
- Activities are the "doing" part (workflows are the "coordinating" part)
- They can fail and be retried automatically by Temporal
- They can have timeouts and retry policies
- They can run on different machines than the workflow

Adding New Activities:
1. Define a new function with the @activity.defn decorator
2. Add it to the activities list in worker.py
3. Add it to the activity_map in workflows.py
4. Reference it in your JSON workflow definition by name

Example:
    @activity.defn
    async def send_notification(email: str, message: str) -> dict:
        # Send email notification
        return {"status": "sent"}
"""

from temporalio import activity  # Import the activity decorator
import logging

# Set up logging so we can see activity execution
logger = logging.getLogger(__name__)


# ===== WORKFLOW ENGINE ACTIVITIES =====
# These activities are available to JSON-defined workflows


@activity.defn
async def review_application() -> dict:
    """
    Review a job application automatically.

    This simulates an automated review of an application,
    checking for basic qualifications.

    In a real application, this might:
    - Parse and analyze resume/CV
    - Check required skills and experience
    - Calculate match score against job requirements
    - Query applicant tracking system (ATS)

    Returns:
        dict: Result containing decision, notes, and score
    """
    logger.info("📋 Reviewing application...")

    # Mock result - in production, this would perform actual analysis
    result = {
        "decision": "approve",
        "notes": "Application meets basic requirements",
        "score": 85
    }

    logger.info(f"✅ Application review result: {result}")
    return result


@activity.defn
async def schedule_interviews() -> dict:
    """
    Schedule all required interviews for the candidate.

    In a real application, this might:
    - Send calendar invites via Google Calendar or Outlook
    - Email candidate with interview details
    - Notify interviewers
    - Book conference rooms or video call links
    - Update scheduling system

    Returns:
        dict: Confirmation with scheduled interview details
    """
    logger.info("📅 Scheduling interviews...")

    # Mock result - in production, this would integrate with calendar APIs
    result = {
        "hr_interview": "2025-10-20 10:00 AM",
        "tech_interview": "2025-10-22 2:00 PM",
        "final_interview": "2025-10-25 4:00 PM",
        "status": "scheduled"
    }

    logger.info(f"✅ Interviews scheduled: {result}")
    return result


@activity.defn
async def aggregate_feedback() -> dict:
    """
    Aggregate feedback from all interview stages.

    This compiles feedback from HR and technical interviews
    to make a final hiring decision.

    In a real application, this might:
    - Query feedback from database
    - Calculate weighted scores
    - Apply business rules for hiring decision
    - Generate summary report
    - Notify hiring manager

    Returns:
        dict: Aggregated feedback with final decision
    """
    logger.info("📊 Aggregating feedback from all interviews...")

    # Mock result - in production, this would pull actual feedback from DB
    result = {
        "decision": "hire",
        "overall_score": 4.5,
        "strengths": ["Strong technical skills", "Great culture fit"],
        "concerns": [],
        "recommendation": "Strong hire"
    }

    logger.info(f"✅ Feedback aggregated: {result}")
    return result


@activity.defn
async def send_offer_email() -> dict:
    """
    Send job offer email to candidate.

    In a real application, this might:
    - Generate offer letter PDF from template
    - Send via DocuSign or HelloSign for e-signature
    - Email HR team and hiring manager
    - Update ATS status to "Offer Sent"
    - Create onboarding ticket
    - Track offer expiration date

    Returns:
        dict: Confirmation of offer sent with details
    """
    logger.info("💼 Sending job offer email...")

    # Mock result - in production, this would send actual emails
    result = {
        "status": "sent",
        "sent_at": "2025-10-26 9:00 AM",
        "offer_expires": "2025-11-02",
        "message": "Job offer has been sent to candidate"
    }

    logger.info(f"✅ {result['message']}")
    return result


@activity.defn
async def send_rejection_email() -> dict:
    """
    Send rejection email to candidate.

    In a real application, this might:
    - Send personalized rejection email
    - Update ATS status to "Rejected"
    - Archive candidate data per GDPR compliance
    - Add to talent pool for future roles
    - Log rejection reason for analytics

    Returns:
        dict: Confirmation of rejection sent
    """
    logger.info("❌ Sending rejection email...")

    # Mock result - in production, this would send actual emails
    result = {
        "status": "sent",
        "sent_at": "2025-10-26 9:00 AM",
        "message": "Rejection email has been sent to candidate"
    }

    logger.info(f"✅ {result['message']}")
    return result
