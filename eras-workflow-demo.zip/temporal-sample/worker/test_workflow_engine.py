"""
Test Script for Data-Driven Workflow Engine

This script demonstrates how to:
1. Start a workflow using a JSON definition
2. Query the workflow status
3. Send signals to the workflow
4. Wait for workflow completion

Usage:
    python test_workflow_engine.py

Prerequisites:
    - Temporal server must be running (docker compose up)
    - Worker must be running (python worker.py)
"""

import asyncio
import json
from temporalio.client import Client


async def main():
    """
    Main test function that demonstrates the workflow engine.
    """

    # Connect to Temporal server
    print("Connecting to Temporal server...")
    client = await Client.connect("localhost:7233")

    # Load the workflow definition from JSON file
    print("\nLoading workflow definition from workflow_definition.json...")
    with open("workflow_definition.json", "r") as f:
        workflow_json = f.read()

    workflow_def = json.loads(workflow_json)
    print(f"Workflow starts at: {workflow_def['start']}")
    print(f"Total steps: {len(workflow_def['steps'])}")

    # Start the workflow
    print("\n" + "="*60)
    print("STARTING WORKFLOW")
    print("="*60)

    workflow_id = "workflow-engine-test-001"

    handle = await client.start_workflow(
        "DataDrivenWorkflowEngine",  # Workflow name (class name)
        workflow_json,  # Pass JSON definition as argument
        id=workflow_id,
        task_queue="hello-tasks",
    )

    print(f"✅ Workflow started with ID: {workflow_id}")
    print(f"Run ID: {handle.result_run_id}")

    # Wait a bit for initial activities to execute
    print("\n⏳ Waiting for activities to execute...")
    await asyncio.sleep(2)

    # Query workflow status
    print("\n" + "="*60)
    print("QUERYING WORKFLOW STATUS")
    print("="*60)

    status = await handle.query("get_status")
    print(f"Current node: {status['current_node_id']}")
    print(f"Completed: {status['completed']}")
    print(f"\nContext so far:")
    for node_id, output in status['context'].items():
        print(f"  {node_id}: {output}")

    # Check if workflow is waiting for HR interview signal
    if status['current_node_id'] == 'hr_interview':
        print("\n" + "="*60)
        print("WORKFLOW WAITING FOR HR INTERVIEW SIGNAL")
        print("="*60)

        # Scenario 1: Approve HR interview (continue to next stage)
        print("\n📨 Sending HR interview approval signal...")
        await handle.signal(
            "send_signal",
            node_id="hr_interview",
            data={
                "decision": "approve",
                "comments": "Great candidate! Strong communication skills."
            }
        )
        print("✅ Signal sent: HR approved")

        # Wait for workflow to process signal and continue
        print("\n⏳ Waiting for workflow to continue...")
        await asyncio.sleep(2)

        # Query status again
        status = await handle.query("get_status")
        print(f"\nCurrent node after signal: {status['current_node_id']}")
        print(f"\nUpdated context:")
        for node_id, output in status['context'].items():
            print(f"  {node_id}: {output}")

    # Wait for workflow to complete
    print("\n" + "="*60)
    print("WAITING FOR WORKFLOW COMPLETION")
    print("="*60)

    print("⏳ Workflow is executing remaining steps...")
    result = await handle.result()

    print("\n" + "="*60)
    print("WORKFLOW COMPLETED")
    print("="*60)
    print(f"\nFinal status: {result['status']}")
    print(f"\nFinal context:")
    for node_id, output in result['context'].items():
        print(f"  {node_id}: {output}")

    print("\n✅ Test completed successfully!")


async def test_rejection_scenario():
    """
    Test scenario where HR rejects the candidate.
    This demonstrates early exit via signal branching.
    """

    print("\n" + "="*60)
    print("TEST SCENARIO: HR REJECTION")
    print("="*60)

    # Connect to Temporal server
    client = await Client.connect("localhost:7233")

    # Load workflow definition
    with open("workflow_definition.json", "r") as f:
        workflow_json = f.read()

    # Start workflow
    workflow_id = "workflow-engine-test-rejection"

    handle = await client.start_workflow(
        "DataDrivenWorkflowEngine",
        workflow_json,
        id=workflow_id,
        task_queue="hello-tasks",
    )

    print(f"✅ Workflow started: {workflow_id}")

    # Wait for workflow to reach HR interview signal
    await asyncio.sleep(2)

    # Send rejection signal
    print("\n📨 Sending HR rejection signal...")
    await handle.signal(
        "send_signal",
        node_id="hr_interview",
        data={
            "decision": "reject",
            "comments": "Not a good fit for the role."
        }
    )
    print("✅ Signal sent: HR rejected")

    # Wait for workflow to complete
    result = await handle.result()

    print("\n📊 Final result:")
    print(f"Status: {result['status']}")
    print(f"Last node executed: {list(result['context'].keys())[-1]}")
    print(f"Expected: send_rejection (should skip all other steps)")

    print("\n✅ Rejection scenario test completed!")


if __name__ == "__main__":
    # Run the main test
    print("Starting workflow engine tests...")
    asyncio.run(main())

    # Optionally, uncomment to test rejection scenario
    # print("\n\n")
    # asyncio.run(test_rejection_scenario())
