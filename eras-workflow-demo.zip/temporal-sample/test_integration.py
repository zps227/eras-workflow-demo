"""
Integration test for the Workflow Engine through the API
Tests the full stack: Frontend API -> Backend -> Temporal -> Worker
"""

import requests
import json
import time
import sys

# Fix encoding for Windows
if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8')

API_URL = "http://localhost:8000"

# Load the workflow definition
with open("worker/workflow_definition.json", "r") as f:
    workflow_def = json.load(f)

print("=" * 60)
print("WORKFLOW ENGINE INTEGRATION TEST")
print("=" * 60)

# Step 1: Start the workflow engine
print("\n[1] Starting workflow engine...")
response = requests.post(
    f"{API_URL}/workflow-engine/start",
    json={"workflow_definition": workflow_def}
)

if response.status_code != 200:
    print(f"❌ Failed to start workflow: {response.text}")
    exit(1)

data = response.json()
workflow_id = data["workflow_id"]
print(f"✅ Workflow started: {workflow_id}")

# Step 2: Wait for workflow to reach signal node
print("\n[2] Waiting for workflow to reach signal node...")
time.sleep(3)

# Step 3: Query workflow status
print("\n[3] Querying workflow status...")
response = requests.get(f"{API_URL}/workflow-engine/status/{workflow_id}")

if response.status_code != 200:
    print(f"❌ Failed to get status: {response.text}")
    exit(1)

status = response.json()
print(f"✅ Current node: {status['current_node_id']}")
print(f"   Completed: {status['completed']}")
print(f"   Context: {json.dumps(status['context'], indent=2)}")

# Step 4: Send signal if waiting at hr_interview
if status['current_node_id'] == 'hr_interview':
    print("\n[4] Workflow waiting at hr_interview signal node")
    print("    Sending approval signal...")

    response = requests.post(
        f"{API_URL}/workflow-engine/signal",
        json={
            "workflow_id": workflow_id,
            "node_id": "hr_interview",
            "data": {
                "decision": "approve",
                "comments": "Great candidate from API test!"
            }
        }
    )

    if response.status_code != 200:
        print(f"❌ Failed to send signal: {response.text}")
        exit(1)

    print("✅ Signal sent successfully")

    # Wait for workflow to process signal
    print("\n[5] Waiting for workflow to complete...")
    time.sleep(3)

    # Check final status
    response = requests.get(f"{API_URL}/workflow-engine/status/{workflow_id}")
    status = response.json()

    print(f"\n✅ Workflow completed: {status['completed']}")
    print(f"   Final node: {status['current_node_id']}")
    print(f"   Final context: {json.dumps(status['context'], indent=2)}")

print("\n" + "=" * 60)
print("INTEGRATION TEST COMPLETED SUCCESSFULLY!")
print("=" * 60)
print(f"\n✅ The workflow engine is fully integrated with your Docker Compose setup!")
print(f"✅ You can now access it at: http://localhost:3000/workflow-engine")
