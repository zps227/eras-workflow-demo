"""
Temporal Gateway - Thin Wrapper Around Temporal SDK

This is an INTERNAL service that provides HTTP access to Temporal operations.
DO NOT call this directly from the frontend - it's only called by app-backend.

RESPONSIBILITIES:
- Wrap Temporal Python SDK in a REST API
- Start workflow engine with JSON definitions
- Send signals to running workflows
- Query workflow status
- NO business logic - pure Temporal operations only

ARCHITECTURE PATTERN:
  Frontend → App Backend → Temporal Gateway (this file) ← YOU ARE HERE
                              ↓
                          Temporal Server
                              ↓
                            Worker

WHY THIS LAYER EXISTS:
1. Separation: Temporal SDK code isolated from business logic
2. Language Flexibility: App backend could be in Node.js, this stays Python
3. Easy to Replace: Can swap Temporal SDK versions without touching app code
4. Internal Only: Not exposed to internet, only app-backend can call it
5. Thin: No validation, auth, or business rules - just Temporal operations

WHAT THIS IS NOT:
- NOT the main API (that's app-backend)
- NOT where you add authentication
- NOT where you add business validation
- NOT where you add database operations

WHAT THIS IS:
- JUST a REST wrapper around Temporal client
- Simple, thin, focused on Temporal only
- Called by app-backend via HTTP

EXAMPLE FLOW:
1. App backend receives: POST /api/workflows/engine/start
2. App backend validates, checks auth, etc.
3. App backend calls this service: POST http://temporal-gateway:8001/workflow-engine/start
4. This service creates Temporal client.start_workflow()
5. Workflow starts on Temporal server
6. Worker picks up and executes
7. This service returns workflow_id to app-backend
8. App-backend returns to frontend

PORT: 8001 (internal only, NOT exposed to internet)
CALLED BY: app-backend only
"""

import os  # For reading environment variables
import uuid  # For generating unique workflow IDs
import json  # For converting workflow definitions to JSON
from fastapi import FastAPI, HTTPException  # Web framework for building APIs
from fastapi.middleware.cors import CORSMiddleware  # For allowing frontend to call backend
from pydantic import BaseModel  # For validating request/response data
from temporalio.client import Client, WorkflowExecutionStatus  # Temporal client for talking to workflows


# Create the FastAPI application
# This is like opening a restaurant - we're ready to serve requests
app = FastAPI()

# Enable CORS (Cross-Origin Resource Sharing)
# This allows the frontend (running on port 3000) to call the backend (running on port 8000)
# Without this, browsers would block the requests for security reasons
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow requests from any origin (* means all)
    allow_credentials=True,  # Allow cookies/authentication
    allow_methods=["*"],  # Allow all HTTP methods (GET, POST, etc.)
    allow_headers=["*"],  # Allow all headers
)

# Global variable to store the Temporal client
# We'll initialize this when the server starts up
# 'None' means it hasn't been initialized yet
temporal_client = None


# ===== Data Models (Request/Response Shapes) =====
# These classes define what data looks like going in and out of our API

class StartWorkflowEngineRequest(BaseModel):
    """
    Request to start a workflow engine with JSON definition.

    Example:
    {
        "workflow_definition": {...},  // JSON workflow definition
        "workflow_id": "optional-custom-id"  // Optional custom ID
    }
    """
    workflow_definition: dict  # The JSON workflow definition
    workflow_id: str | None = None  # Optional custom workflow ID


class SendSignalRequest(BaseModel):
    """
    Request to send a signal to a workflow engine.

    Example:
    {
        "workflow_id": "workflow-engine-123",
        "node_id": "hr_interview",
        "data": {"decision": "approve", "comments": "Great!"}
    }
    """
    workflow_id: str
    node_id: str
    data: dict


@app.on_event("startup")
async def startup_event():
    """
    Runs when the FastAPI server starts up.

    This is like a restaurant opening for the day:
    - Connect to Temporal server
    - Get ready to handle requests

    This runs ONCE when the container starts.
    """
    global temporal_client  # We're going to modify the global variable

    # Get Temporal server address from environment variable
    # In Docker Compose, this is set to "temporal:7233"
    temporal_host = os.getenv("TEMPORAL_HOST", "localhost:7233")

    # Connect to Temporal server
    # This creates a client that can start workflows, send signals, etc.
    temporal_client = await Client.connect(temporal_host)

    print(f"Connected to Temporal at: {temporal_host}")


@app.get("/")
async def root():
    """
    Health check endpoint.

    Returns a simple message to confirm the API is running.
    You can test this with: curl http://localhost:8001/
    """
    return {"message": "Temporal Gateway - Workflow Engine Only"}


@app.post("/workflow-engine/start")
async def start_workflow_engine(request: StartWorkflowEngineRequest):
    """
    Start a new workflow using the data-driven workflow engine.

    The workflow engine allows you to define workflows in JSON without
    writing code. The workflow definition includes:
    - Activities: Functions that do work
    - Signals: Wait for external input
    - Decisions: Branch based on conditions

    Args:
        request: Contains workflow_definition (JSON) and optional workflow_id

    Returns:
        {"workflow_id": "..."}
    """
    try:
        # Generate workflow ID if not provided
        workflow_id = request.workflow_id or f"workflow-engine-{uuid.uuid4()}"

        # Convert workflow definition to JSON string
        workflow_json = json.dumps(request.workflow_definition)

        # Start the DataDrivenWorkflowEngine
        handle = await temporal_client.start_workflow(
            "DataDrivenWorkflowEngine",
            args=[workflow_json],
            id=workflow_id,
            task_queue="hello-tasks",
        )

        return {"workflow_id": handle.id}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/workflow-engine/status/{workflow_id}")
async def get_workflow_engine_status(workflow_id: str):
    """
    Get the current status of a workflow engine instance.

    Returns:
    - current_node_id: Which node is currently executing
    - completed: Whether the workflow has finished
    - context: All data collected so far from activities and signals
    - result: Final result if workflow is completed

    Args:
        workflow_id: The unique ID of the workflow

    Returns:
        {
            "workflow_id": "...",
            "current_node_id": "...",
            "completed": false,
            "context": {...},
            "result": {...}  // Only if completed
        }
    """
    try:
        handle = temporal_client.get_workflow_handle(workflow_id)

        # Query the workflow status
        try:
            status = await handle.query("get_status")
        except Exception as e:
            # If query fails, workflow might not exist or not running
            raise HTTPException(status_code=404, detail=f"Workflow not found or not running: {str(e)}")

        # Check if workflow is completed
        result = None
        try:
            description = await handle.describe()
            if description.status == WorkflowExecutionStatus.COMPLETED:
                result = await handle.result()
        except Exception:
            pass

        return {
            "workflow_id": workflow_id,
            "current_node_id": status.get("current_node_id"),
            "completed": status.get("completed", False),
            "context": status.get("context", {}),
            "result": result
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/workflow-engine/signal")
async def send_workflow_engine_signal(request: SendSignalRequest):
    """
    Send a signal to a workflow engine instance.

    Signals are used to provide external input to workflows that are
    waiting at a signal node. For example, sending HR approval feedback.

    Args:
        request: Contains workflow_id, node_id, and data

    Returns:
        {"message": "Signal sent successfully"}
    """
    try:
        handle = temporal_client.get_workflow_handle(request.workflow_id)

        # Send the signal with args parameter containing node_id and data
        await handle.signal(
            "send_signal",
            args=[request.node_id, request.data]
        )

        return {"message": "Signal sent successfully"}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Standard Python pattern: only run the server if this file is executed directly
if __name__ == "__main__":
    # Import uvicorn (the web server that runs FastAPI)
    import uvicorn

    # Run the FastAPI app
    # host="0.0.0.0" means "accept connections from any IP address"
    # port=8000 means "listen on port 8000"
    uvicorn.run(app, host="0.0.0.0", port=8000)
