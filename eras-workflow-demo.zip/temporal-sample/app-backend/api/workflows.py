"""
Workflow Engine API Endpoints

These endpoints provide a high-level API for the frontend to interact
with the data-driven workflow engine. They handle business logic,
validation, and orchestrate calls to the Temporal Gateway.

The workflow engine allows you to define complete workflows in JSON
without writing any code, making it easy to configure complex approval
processes, multi-stage workflows, and human-in-the-loop operations.

Future enhancements:
- Add authentication/authorization
- Add request validation and workflow definition schema validation
- Add rate limiting
- Log all workflow operations
- Store workflow definitions and executions in database
- Version workflow definitions
"""

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Optional
from services.temporal_client import get_temporal_client, TemporalClient


router = APIRouter()


# ===== Request/Response Models =====

class StartWorkflowEngineRequest(BaseModel):
    """
    Request to start a workflow engine with a JSON definition.

    The workflow_definition should contain:
    - start: ID of the first node to execute
    - steps: List of nodes (activities, signals, decisions)
    """
    workflow_definition: dict
    workflow_id: Optional[str] = None


class SendSignalRequest(BaseModel):
    """
    Request to send a signal to a waiting workflow.

    Signals provide external input to workflows that are paused
    at a signal node, enabling human-in-the-loop processes.
    """
    workflow_id: str
    node_id: str
    data: dict


# ===== Workflow Engine Endpoints =====

@router.post("/engine/start")
async def start_workflow_engine(
    request: StartWorkflowEngineRequest,
    temporal: TemporalClient = Depends(get_temporal_client)
):
    """
    Start a data-driven workflow engine.

    This allows users to define workflows in JSON and execute them.

    In a production app, you would:
    - Store workflow definitions in database
    - Version workflow definitions
    - Validate workflow JSON schema
    - Check user permissions to create workflows
    """
    try:
        result = await temporal.start_workflow_engine(
            request.workflow_definition,
            request.workflow_id
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/engine/status/{workflow_id}")
async def get_workflow_engine_status(
    workflow_id: str,
    temporal: TemporalClient = Depends(get_temporal_client)
):
    """Get workflow engine status."""
    try:
        result = await temporal.get_workflow_engine_status(workflow_id)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/engine/signal")
async def send_workflow_engine_signal(
    request: SendSignalRequest,
    temporal: TemporalClient = Depends(get_temporal_client)
):
    """Send a signal to a workflow engine instance."""
    try:
        result = await temporal.send_workflow_engine_signal(
            request.workflow_id,
            request.node_id,
            request.data
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
