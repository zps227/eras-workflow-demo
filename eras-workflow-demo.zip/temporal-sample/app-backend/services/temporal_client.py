"""
Temporal Client Service

HTTP client wrapper for communicating with the Temporal Gateway.
This abstracts away the gateway API and provides a clean interface
for the app backend to interact with the data-driven workflow engine.

The workflow engine allows you to define complete workflows in JSON
without writing code, supporting activities, signals, and decision nodes.
"""

import httpx
import os
from typing import Any, Dict, Optional


class TemporalClient:
    """
    Client for interacting with Temporal Gateway.

    This is a simple HTTP client that wraps calls to the temporal-gateway service.
    It provides methods for starting workflow engines, querying status, and sending
    signals to running workflows.

    Future enhancements:
    - Retry logic with exponential backoff
    - Circuit breakers for fault tolerance
    - Response caching for frequently queried workflows
    - Metrics and logging for observability
    - Request/response validation
    """

    def __init__(self, gateway_url: str = None):
        self.gateway_url = gateway_url or os.getenv(
            "TEMPORAL_GATEWAY_URL",
            "http://temporal-gateway:8001"
        )
        self.client = httpx.AsyncClient(timeout=30.0)

    async def close(self):
        """Close the HTTP client and cleanup resources."""
        await self.client.aclose()

    # ===== Workflow Engine Operations =====

    async def start_workflow_engine(
        self,
        workflow_definition: dict,
        workflow_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Start a data-driven workflow engine with JSON definition.

        Args:
            workflow_definition: The workflow JSON definition
            workflow_id: Optional custom workflow ID

        Returns:
            dict: {"workflow_id": "..."}
        """
        response = await self.client.post(
            f"{self.gateway_url}/workflow-engine/start",
            json={
                "workflow_definition": workflow_definition,
                "workflow_id": workflow_id
            }
        )
        response.raise_for_status()
        return response.json()

    async def get_workflow_engine_status(self, workflow_id: str) -> Dict[str, Any]:
        """Get workflow engine status."""
        response = await self.client.get(
            f"{self.gateway_url}/workflow-engine/status/{workflow_id}"
        )
        response.raise_for_status()
        return response.json()

    async def send_workflow_engine_signal(
        self,
        workflow_id: str,
        node_id: str,
        data: dict
    ) -> Dict[str, Any]:
        """Send a signal to a workflow engine."""
        response = await self.client.post(
            f"{self.gateway_url}/workflow-engine/signal",
            json={
                "workflow_id": workflow_id,
                "node_id": node_id,
                "data": data
            }
        )
        response.raise_for_status()
        return response.json()


# Singleton instance
_temporal_client: Optional[TemporalClient] = None


def get_temporal_client() -> TemporalClient:
    """
    Get the singleton Temporal client instance.

    This ensures we reuse the same HTTP client connection pool
    across requests for better performance.
    """
    global _temporal_client
    if _temporal_client is None:
        _temporal_client = TemporalClient()
    return _temporal_client
