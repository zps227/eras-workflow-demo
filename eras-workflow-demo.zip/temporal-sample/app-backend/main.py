"""
Application Backend - Main Business Logic API

This is the PRIMARY backend that your users interact with.
Think of it as the "brain" of your application.

RESPONSIBILITIES:
- Main REST API for all application features
- Business logic and data validation
- User management and authentication (future)
- Database operations (future)
- Decides WHEN and HOW to use workflows
- Orchestrates calls to Temporal Gateway when workflows are needed

ARCHITECTURE PATTERN:
  Frontend (UI)
      ↓
  App Backend (this file) ← YOU ARE HERE
      ↓
  Temporal Gateway (internal only, thin Temporal wrapper)
      ↓
  Temporal Server (workflow orchestration)
      ↓
  Worker (executes workflows)

WHY THIS SEPARATION?
1. Security: Temporal Gateway is internal-only, not exposed to internet
2. Business Logic: This layer can validate, authenticate, rate-limit
3. Flexibility: Can handle requests with OR without workflows
4. Scalability: Each layer scales independently
5. Clean Code: Temporal concerns separated from business logic

EXAMPLE FLOW:
1. User clicks "Start Workflow" in frontend
2. Frontend calls: POST /api/workflows/basic/start (this file)
3. This file validates request, checks user auth (future)
4. This file calls Temporal Gateway: POST http://temporal-gateway:8000/start
5. Temporal Gateway starts workflow via Temporal SDK
6. Worker picks up and executes workflow
7. Response flows back through the layers

ADDING NEW FEATURES:
- New endpoints? Add to app-backend/api/
- New business logic? Add to app-backend/services/
- New database models? Add to app-backend/models/ (future)
- New workflows? They still go in worker/, not here

PORT: 8000 (exposed to internet/frontend)
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import httpx
import os

# Import API routers
from api import workflows

app = FastAPI(title="Application Backend")

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Temporal Gateway URL (internal Docker network)
TEMPORAL_GATEWAY_URL = os.getenv("TEMPORAL_GATEWAY_URL", "http://temporal-gateway:8001")


@app.get("/")
async def root():
    """Health check endpoint."""
    return {
        "service": "Application Backend",
        "status": "running",
        "temporal_gateway": TEMPORAL_GATEWAY_URL
    }


@app.get("/health")
async def health_check():
    """
    Health check that also verifies connectivity to Temporal Gateway.
    """
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(f"{TEMPORAL_GATEWAY_URL}/", timeout=5.0)
            gateway_status = "healthy" if response.status_code == 200 else "unhealthy"
    except Exception as e:
        gateway_status = f"unreachable: {str(e)}"

    return {
        "app_backend": "healthy",
        "temporal_gateway": gateway_status
    }


# Include API routers
app.include_router(workflows.router, prefix="/api/workflows", tags=["workflows"])


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
