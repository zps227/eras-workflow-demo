"""
FastAPI Backend for Flowable Workflow Application

This backend serves as a bridge between the Next.js frontend and Flowable REST API.
It provides simplified endpoints for:
- Deploying workflow definitions
- Starting workflow instances
- Querying and completing user tasks
"""

import os
import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any

# Initialize FastAPI app
app = FastAPI(title="Workflow API", description="Backend for job interview workflow")

# Enable CORS for Next.js frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # Next.js dev server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Flowable REST API configuration from environment variables
FLOWABLE_URL = os.getenv("FLOWABLE_URL", "http://localhost:8080/flowable-rest")
FLOWABLE_USER = os.getenv("FLOWABLE_USER", "admin")
FLOWABLE_PASSWORD = os.getenv("FLOWABLE_PASSWORD", "test")

# Basic auth for Flowable
flowable_auth = (FLOWABLE_USER, FLOWABLE_PASSWORD)


# --- Request/Response Models ---

class StartWorkflowRequest(BaseModel):
    """Request body for starting a new workflow instance"""
    candidateName: str
    yearsOfExperience: int
    position: str
    needsTechnicalInterview: bool


class CompleteTaskRequest(BaseModel):
    """Request body for completing a user task"""
    variables: Dict[str, Any]


class ValidateExperienceRequest(BaseModel):
    """Request body for experience validation"""
    yearsOfExperience: int
    position: str


# --- API Endpoints ---

@app.get("/")
async def root():
    """Health check endpoint"""
    return {"status": "ok", "service": "workflow-backend"}


@app.post("/validate-experience")
async def validate_experience(request: ValidateExperienceRequest):
    """
    Service endpoint called by Flowable HTTP service task.

    This demonstrates how business logic can live in your backend API
    rather than embedded in the workflow engine. Flowable calls this
    endpoint asynchronously and uses the response to route the workflow.

    Business logic:
    - Minimum 3 years experience required for all positions
    - Senior positions require 5+ years
    """
    # Simulate some processing time (optional - shows async nature)
    import asyncio
    await asyncio.sleep(0.1)

    # Business logic for experience validation
    min_experience = 3
    if "senior" in request.position.lower() or "lead" in request.position.lower():
        min_experience = 5

    meets_requirement = request.yearsOfExperience >= min_experience

    # Return response that Flowable will store as process variable
    return {
        "meetsExperienceRequirement": meets_requirement,
        "minimumRequired": min_experience,
        "message": f"Candidate has {request.yearsOfExperience} years, "
                   f"{'meets' if meets_requirement else 'does not meet'} "
                   f"minimum of {min_experience} years for {request.position}"
    }


@app.post("/workflows/deploy")
async def deploy_workflow():
    """
    Deploy the job interview workflow definition to Flowable.

    This reads the BPMN XML file and uploads it to Flowable's repository.
    Only needs to be called once (or when the workflow definition changes).
    """
    try:
        # Read the BPMN workflow definition file
        with open("workflows/job_interview.bpmn20.xml", "rb") as f:
            bpmn_content = f.read()

        # Prepare multipart file upload
        files = {
            "file": ("job_interview.bpmn20.xml", bpmn_content, "application/xml")
        }

        # Deploy to Flowable via REST API
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{FLOWABLE_URL}/service/repository/deployments",
                files=files,
                auth=flowable_auth,
                timeout=30.0
            )
            response.raise_for_status()

        return {
            "message": "Workflow deployed successfully",
            "deployment": response.json()
        }

    except FileNotFoundError:
        raise HTTPException(status_code=500, detail="Workflow definition file not found")
    except httpx.HTTPError as e:
        raise HTTPException(status_code=500, detail=f"Failed to deploy workflow: {str(e)}")


@app.post("/workflows/start")
async def start_workflow(request: StartWorkflowRequest):
    """
    Start a new job interview workflow instance.

    Creates a new process instance with the candidate's information.
    Returns the process instance ID which can be used to track the workflow.
    """
    try:
        # Prepare workflow variables (candidate data)
        payload = {
            "processDefinitionKey": "jobInterviewProcess",  # Must match BPMN process ID
            "variables": [
                {"name": "candidateName", "value": request.candidateName},
                {"name": "yearsOfExperience", "value": request.yearsOfExperience},
                {"name": "position", "value": request.position},
                {"name": "needsTechnicalInterview", "value": request.needsTechnicalInterview},
            ]
        }

        # Start the process instance via Flowable REST API
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{FLOWABLE_URL}/service/runtime/process-instances",
                json=payload,
                auth=flowable_auth,
                timeout=30.0
            )
            response.raise_for_status()

        result = response.json()
        return {
            "message": "Workflow started successfully",
            "processInstanceId": result.get("id"),
            "processInstance": result
        }

    except httpx.HTTPError as e:
        raise HTTPException(status_code=500, detail=f"Failed to start workflow: {str(e)}")


@app.get("/tasks")
async def get_tasks():
    """
    Get all active user tasks across all workflow instances.

    Returns tasks that are waiting for human interaction (HR review, interviews, etc.)
    """
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{FLOWABLE_URL}/service/runtime/tasks",
                auth=flowable_auth,
                timeout=30.0
            )
            response.raise_for_status()

        return response.json()

    except httpx.HTTPError as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch tasks: {str(e)}")


@app.get("/tasks/{task_id}")
async def get_task_details(task_id: str):
    """
    Get details for a specific task, including its variables.

    This includes the candidate information and any decisions made in previous steps.
    """
    try:
        async with httpx.AsyncClient() as client:
            # Get task details
            task_response = await client.get(
                f"{FLOWABLE_URL}/service/runtime/tasks/{task_id}",
                auth=flowable_auth,
                timeout=30.0
            )
            task_response.raise_for_status()
            task = task_response.json()

            # Get task variables
            vars_response = await client.get(
                f"{FLOWABLE_URL}/service/runtime/tasks/{task_id}/variables",
                auth=flowable_auth,
                timeout=30.0
            )
            vars_response.raise_for_status()
            variables = vars_response.json()

        return {
            "task": task,
            "variables": variables
        }

    except httpx.HTTPError as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch task details: {str(e)}")


@app.post("/tasks/{task_id}/complete")
async def complete_task(task_id: str, request: CompleteTaskRequest):
    """
    Complete a user task with the provided decision/data.

    This moves the workflow to the next step based on the task completion variables.
    For example, completing HR review with hrApproved=true will proceed to technical interview.
    """
    try:
        # Format variables for Flowable API
        variables = [
            {"name": key, "value": value}
            for key, value in request.variables.items()
        ]

        payload = {"variables": variables} if variables else {}

        # Complete the task via Flowable REST API
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{FLOWABLE_URL}/service/runtime/tasks/{task_id}",
                json={"action": "complete", **payload},
                auth=flowable_auth,
                timeout=30.0
            )
            response.raise_for_status()

        return {"message": "Task completed successfully"}

    except httpx.HTTPError as e:
        raise HTTPException(status_code=500, detail=f"Failed to complete task: {str(e)}")


@app.get("/process-instances/{process_id}")
async def get_process_instance(process_id: str):
    """
    Get details about a specific workflow instance.

    Useful for tracking the overall status of a candidate's application.
    """
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{FLOWABLE_URL}/service/runtime/process-instances/{process_id}",
                auth=flowable_auth,
                timeout=30.0
            )

            # If process not found in runtime, it might be completed - check history
            if response.status_code == 404:
                history_response = await client.get(
                    f"{FLOWABLE_URL}/service/history/historic-process-instances/{process_id}",
                    auth=flowable_auth,
                    timeout=30.0
                )
                history_response.raise_for_status()
                return {
                    "status": "completed",
                    "instance": history_response.json()
                }

            response.raise_for_status()
            return {
                "status": "active",
                "instance": response.json()
            }

    except httpx.HTTPError as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch process instance: {str(e)}")


@app.get("/audit-trail")
async def get_audit_trail():
    """
    Get all workflow instances (both active and completed) with their audit trail.

    Returns a list of all process instances with their execution history,
    showing what steps were completed and by whom.
    """
    try:
        async with httpx.AsyncClient() as client:
            # Get all historic process instances (includes completed ones)
            history_response = await client.get(
                f"{FLOWABLE_URL}/service/history/historic-process-instances",
                params={
                    "sort": "startTime",
                    "order": "desc",
                    "size": 50  # Limit to last 50 instances
                },
                auth=flowable_auth,
                timeout=30.0
            )
            history_response.raise_for_status()
            instances = history_response.json().get("data", [])

            # For each instance, get its activity history
            audit_data = []
            for instance in instances:
                process_id = instance["id"]

                # Get historic activities (steps taken in the workflow)
                # Note: Flowable paginates results, default size is 10, so we request more
                activities_response = await client.get(
                    f"{FLOWABLE_URL}/service/history/historic-activity-instances",
                    params={
                        "processInstanceId": process_id,
                        "orderBy": "startTime",
                        "order": "asc",
                        "size": 100  # Request up to 100 activities per process
                    },
                    auth=flowable_auth,
                    timeout=30.0
                )
                activities_response.raise_for_status()
                activities = activities_response.json().get("data", [])

                # Get process variables to show candidate info
                variables_response = await client.get(
                    f"{FLOWABLE_URL}/service/history/historic-variable-instances",
                    params={"processInstanceId": process_id},
                    auth=flowable_auth,
                    timeout=30.0
                )
                variables_response.raise_for_status()
                variables_data = variables_response.json().get("data", [])

                # Convert variables array to dict for easy access
                variables = {
                    var["variable"]["name"]: var["variable"]["value"]
                    for var in variables_data
                    if "variable" in var
                }

                audit_data.append({
                    "processInstanceId": process_id,
                    "processDefinitionName": instance.get("processDefinitionName", "Unknown"),
                    "startTime": instance.get("startTime"),
                    "endTime": instance.get("endTime"),
                    "duration": instance.get("durationInMillis"),
                    "deleteReason": instance.get("deleteReason"),
                    "variables": variables,
                    "activities": activities
                })

            return {"data": audit_data, "total": len(audit_data)}

    except httpx.HTTPError as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch audit trail: {str(e)}")
