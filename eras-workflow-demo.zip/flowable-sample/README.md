# Job Interview Workflow Application

A barebones demonstration of workflow orchestration using **Flowable REST API**, **Next.js**, **FastAPI**, and **PostgreSQL**.

This application demonstrates a job interview workflow with:
- **Automated steps**: Checking years of experience automatically
- **User interaction steps**: HR review, technical interviews, final hiring decision
- **Conditional routing**: Different paths based on decisions (e.g., technical interview only for technical roles)

## Architecture

```
┌─────────────┐      ┌─────────────┐      ┌─────────────┐      ┌─────────────┐
│   Next.js   │ ───> │   FastAPI   │ ───> │  Flowable   │ ───> │ PostgreSQL  │
│  Frontend   │      │   Backend   │      │  REST API   │      │  Database   │
│  (Port 3000)│      │  (Port 8000)│      │ (Port 8080) │      │ (Port 5432) │
└─────────────┘      └─────────────┘      └─────────────┘      └─────────────┘
```

- **Next.js** (frontend): UI for starting workflows and completing user tasks
- **FastAPI** (backend): REST API wrapper around Flowable, simplifies workflow operations
- **Flowable**: BPMN workflow engine exposing REST API
- **PostgreSQL**: Database for Flowable's workflow state

## Project Structure

```
flowable-sample/
├── docker-compose.yml          # Orchestrates all services
├── backend/
│   ├── Dockerfile             # FastAPI container
│   ├── requirements.txt       # Python dependencies
│   ├── main.py               # FastAPI application with Flowable integration
│   └── workflows/
│       └── job_interview.bpmn20.xml  # BPMN workflow definition
└── frontend/
    ├── Dockerfile            # Next.js container
    ├── package.json          # Node.js dependencies
    ├── next.config.js        # Next.js configuration
    ├── tsconfig.json         # TypeScript configuration
    └── app/
        ├── layout.tsx        # Root layout
        └── page.tsx          # Main page with workflow UI
```

## Workflow Steps

The job interview workflow (`job_interview.bpmn20.xml`) includes:

1. **Start**: Application received
2. **Automated Check**: Verify candidate has ≥3 years of experience
   - If NO → Reject automatically
   - If YES → Continue to HR review
3. **User Task - HR Review**: HR team reviews application
   - Approve → Continue
   - Reject → End (rejected)
4. **Conditional Gateway**: Technical interview needed?
   - If YES → Technical interview
   - If NO → Skip to final decision
5. **User Task - Technical Interview**: Technical team conducts interview
6. **User Task - Final Decision**: Management makes hiring decision
   - Hire → End (hired)
   - Reject → End (rejected)

## Getting Started

### Prerequisites

- Docker and Docker Compose installed
- Ports 3000, 8000, 8080, and 5432 available

### Running the Application

1. **Start all services**:
   ```bash
   docker-compose up --build
   ```

   This will start:
   - PostgreSQL (database)
   - Flowable REST API (workflow engine)
   - FastAPI backend
   - Next.js frontend

2. **Wait for services to be ready** (approximately 1-2 minutes):
   - Flowable needs time to initialize the database and start up
   - Watch for "Flowable REST API started" type messages in logs

3. **Open the application**:
   ```
   http://localhost:3000
   ```

### First-Time Setup

When you first access the UI:

1. Click **"Deploy Workflow Definition"** button
   - This uploads the BPMN workflow to Flowable
   - Only needs to be done once (or when the workflow changes)

2. Start creating workflows!

## Using the Application

### Starting a Workflow

1. Fill in the form:
   - **Candidate Name**: Name of the job applicant
   - **Years of Experience**: Number (if <3, will be auto-rejected)
   - **Position**: Job title
   - **Requires Technical Interview**: Check if this is a technical role

2. Click **"Start Interview Process"**

3. If years of experience ≥ 3, a user task will appear below for HR review

### Completing Tasks

Active user tasks appear in the "Active User Tasks" section:

- **HR Review Application**: Approve or Reject
- **Conduct Technical Interview**: Pass or Fail
- **Make Final Hiring Decision**: Hire or Reject

Click the appropriate button to complete each task and move the workflow forward.

## API Endpoints

The FastAPI backend (`http://localhost:8000`) exposes:

### Workflow Management
- `POST /workflows/deploy` - Deploy workflow definition to Flowable
- `POST /workflows/start` - Start new workflow instance
  ```json
  {
    "candidateName": "John Doe",
    "yearsOfExperience": 5,
    "position": "Software Engineer",
    "needsTechnicalInterview": true
  }
  ```

### Task Management
- `GET /tasks` - List all active user tasks
- `GET /tasks/{task_id}` - Get task details with variables
- `POST /tasks/{task_id}/complete` - Complete a task
  ```json
  {
    "variables": {
      "hrApproved": true
    }
  }
  ```

### Process Instances
- `GET /process-instances/{process_id}` - Get workflow instance status

## Flowable REST API

Direct access to Flowable REST API (for advanced use):
- **URL**: http://localhost:8080/flowable-rest
- **Credentials**: admin / test
- **Documentation**: http://localhost:8080/flowable-rest/docs

Example endpoints:
- `GET /service/repository/process-definitions` - List deployed workflows
- `GET /service/runtime/process-instances` - List running workflows
- `GET /service/runtime/tasks` - List active tasks

## Environment Variables

### Backend (FastAPI)
- `FLOWABLE_URL`: Flowable REST API URL (default: `http://flowable:8080/flowable-rest`)
- `FLOWABLE_USER`: Flowable admin username (default: `admin`)
- `FLOWABLE_PASSWORD`: Flowable admin password (default: `test`)

### Frontend (Next.js)
- `NEXT_PUBLIC_API_URL`: Backend API URL (default: `http://localhost:8000`)

## Stopping the Application

```bash
docker-compose down
```

To remove all data (including PostgreSQL database):
```bash
docker-compose down -v
```

## Troubleshooting

### Services won't start
- Check if ports 3000, 8000, 8080, or 5432 are already in use
- Try `docker-compose down -v` and restart

### Workflow deployment fails
- Wait longer for Flowable to fully start (check logs with `docker-compose logs flowable`)
- Ensure the BPMN file is valid XML

### Tasks not appearing
- Check the workflow actually started (look for success message)
- Verify years of experience ≥ 3 (otherwise auto-rejected)
- Refresh the page or wait a few seconds (tasks poll every 5 seconds)

### Cannot complete tasks
- Verify the FastAPI backend is running (`docker-compose logs backend`)
- Check browser console for errors

## Development Notes

This is a **barebones demonstration** focused on showcasing Flowable workflow capabilities:

- **No authentication**: Anyone can start workflows and complete tasks
- **No validation**: Minimal input validation
- **No styling framework**: Inline styles only for simplicity
- **No state management**: Simple React useState hooks
- **No error recovery**: Basic error handling only
- **No tests**: Demo purposes only

For production use, you would add:
- User authentication and authorization
- Role-based task assignment
- Proper error handling and validation
- Database migrations
- Production-grade styling
- Comprehensive testing
- Logging and monitoring
- Security hardening

## Technologies Used

- **[Flowable 7.0.1](https://www.flowable.com/)**: Open-source BPMN workflow engine
- **[Next.js 14](https://nextjs.org/)**: React framework for frontend
- **[FastAPI](https://fastapi.tiangolo.com/)**: Modern Python web framework
- **[PostgreSQL 15](https://www.postgresql.org/)**: Relational database
- **[Docker Compose](https://docs.docker.com/compose/)**: Container orchestration

## License

This is a demonstration project - use freely for learning and experimentation.
