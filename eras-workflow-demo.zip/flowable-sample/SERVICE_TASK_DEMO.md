# HTTP Service Task Demonstration

## Overview

This document explains how to use Flowable's HTTP service tasks to call external REST APIs for business logic, demonstrating the separation of concerns where business rules live in your backend API rather than embedded in the workflow engine.

## What We Built

### 1. **Backend API Endpoint** (`backend/main.py:68-99`)

```python
@app.post("/validate-experience")
async def validate_experience(request: ValidateExperienceRequest):
    """
    Service endpoint called by Flowable HTTP service task.

    Business logic:
    - Minimum 3 years experience required for all positions
    - Senior positions require 5+ years
    """
    min_experience = 3
    if "senior" in request.position.lower() or "lead" in request.position.lower():
        min_experience = 5

    meets_requirement = request.yearsOfExperience >= min_experience

    return {
        "meetsExperienceRequirement": meets_requirement,
        "minimumRequired": min_experience,
        "message": f"Candidate has {request.yearsOfExperience} years..."
    }
```

**Key Points:**
- Business logic lives in Python code, easy to test and modify
- Returns JSON that Flowable stores as process variables
- Can be called by any service, not just Flowable
- Async/non-blocking execution

### 2. **BPMN Service Task Configuration** (`backend/workflows/job_interview.bpmn20.xml:25-73`)

The workflow includes a properly configured HTTP service task:

```xml
<serviceTask id="validateExperience"
             name="Validate Experience via API"
             flowable:type="http">
  <extensionElements>
    <!-- HTTP Method -->
    <flowable:field name="requestMethod">
      <flowable:string><![CDATA[POST]]></flowable:string>
    </flowable:field>

    <!-- API Endpoint URL -->
    <flowable:field name="requestUrl">
      <flowable:string><![CDATA[http://backend:8000/validate-experience]]></flowable:string>
    </flowable:field>

    <!-- Request Headers -->
    <flowable:field name="requestHeaders">
      <flowable:string><![CDATA[Content-Type: application/json]]></flowable:string>
    </flowable:field>

    <!-- Request Body with process variables -->
    <flowable:field name="requestBody">
      <flowable:expression><![CDATA[{
        "yearsOfExperience": ${yearsOfExperience},
        "position": "${position}"
      }]]></flowable:expression>
    </flowable:field>

    <!-- Store response in variable -->
    <flowable:field name="responseVariableName">
      <flowable:string><![CDATA[validationResponse]]></flowable:string>
    </flowable:field>
  </extensionElements>
</serviceTask>
```

### 3. **Gateway Using API Response** (`backend/workflows/job_interview.bpmn20.xml:85-97`)

```xml
<exclusiveGateway id="experienceGateway" name="Meets Experience Requirement?"/>

<!-- Route based on API response -->
<sequenceFlow sourceRef="experienceGateway" targetRef="rejectApplication">
  <conditionExpression xsi:type="tFormalExpression">
    ${validationResponse.meetsExperienceRequirement == false}
  </conditionExpression>
</sequenceFlow>
```

## How It Works

1. **Workflow starts** with candidate data (name, years, position)
2. **Service task executes**: Flowable makes HTTP POST to `http://backend:8000/validate-experience`
3. **Backend processes**: Applies business rules, returns JSON response
4. **Response stored**: Flowable saves response in `validationResponse` variable
5. **Gateway decides**: Uses `validationResponse.meetsExperienceRequirement` to route
6. **Workflow continues**: Proceeds to HR review or rejection based on API response

## Benefits of This Pattern

### ✅ Separation of Concerns
- **Business Logic**: Lives in Python/FastAPI (easy to test, version control)
- **Workflow Logic**: Lives in BPMN (orchestration only)

### ✅ Flexibility
- Change validation rules without redeploying workflows
- Same API can be called by multiple workflows or external systems
- Easy to add caching, rate limiting, etc. in the API layer

### ✅ Observability
- API calls can be logged, monitored, traced independently
- Easy to see what decisions were made and why
- Backend can emit metrics, alerts based on validation results

### ✅ Testability
- Test business logic independently: `POST /validate-experience`
- Mock API responses in workflow tests
- Integration tests can verify end-to-end behavior

## Testing the Endpoint

You can test the validation endpoint directly:

```bash
# Test with sufficient experience
curl -X POST http://localhost:8000/validate-experience \
  -H "Content-Type: application/json" \
  -d '{"yearsOfExperience": 6, "position": "Senior Engineer"}'

# Response:
{
  "meetsExperienceRequirement": true,
  "minimumRequired": 5,
  "message": "Candidate has 6 years, meets minimum of 5 years for Senior Engineer"
}

# Test with insufficient experience
curl -X POST http://localhost:8000/validate-experience \
  -H "Content-Type: application/json" \
  -d '{"yearsOfExperience": 2, "position": "Senior Engineer"}'

# Response:
{
  "meetsExperienceRequirement": false,
  "minimumRequired": 5,
  "message": "Candidate has 2 years, does not meet minimum of 5 years for Senior Engineer"
}
```

## Known Limitation with Flowable REST Docker Image

**Important**: The Flowable REST 7.0.1 Docker image has a known issue where HTTP service tasks fail due to missing Apache HttpComponents HTTP/2 dependencies:

```
java.lang.NoClassDefFoundError: org/apache/hc/core5/http2/impl/nio/ClientHttpProtocolNegotiator
```

### Workarounds

#### Option 1: Use Flowable UI/IDM Image (includes all dependencies)
```yaml
flowable:
  image: flowable/all-in-one:7.0.1  # Includes HTTP client libraries
```

#### Option 2: Build Custom Docker Image
Create a custom Dockerfile that adds the missing dependencies to the REST image.

#### Option 3: Use Script Tasks Instead
Replace HTTP service task with a Groovy/JavaScript script that makes the HTTP call.

#### Option 4: Use External Worker Pattern
Implement the service task as an external worker that polls for work (similar to Camunda external tasks).

## Production Recommendations

For production use of HTTP service tasks:

1. **Timeouts**: Configure appropriate timeouts
   ```xml
   <flowable:field name="requestTimeout">
     <flowable:string><![CDATA[5000]]></flowable:string><!-- 5 seconds -->
   </flowable:field>
   ```

2. **Error Handling**: Handle HTTP errors gracefully
   ```xml
   <flowable:field name="ignoreException">
     <flowable:string><![CDATA[false]]></flowable:string>
   </flowable:field>
   ```

3. **Retries**: Add boundary error events with retry logic

4. **Circuit Breaker**: Implement circuit breaker pattern in the API

5. **Async Processing**: For long-running validations, use async callbacks

6. **Security**: Use proper authentication (API keys, OAuth, etc.)

7. **Monitoring**: Add logging and metrics around service task execution

## Alternative: Current Working Implementation

For this demo, we simplified to use an inline gateway expression instead of the HTTP service task to avoid the dependency issue. However, the backend endpoint is fully functional and demonstrates where your business logic would live in a real implementation.

The pattern shown here is production-ready and widely used in enterprise workflow systems - the only limitation is the Docker image choice for this demo environment.
