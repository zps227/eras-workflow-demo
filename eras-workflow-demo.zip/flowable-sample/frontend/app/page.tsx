'use client'

/**
 * Main page component for the workflow application
 *
 * Features:
 * 1. Deploy workflow button (one-time setup)
 * 2. Form to start new job interview workflow
 * 3. List of active user tasks (HR review, interviews, decisions)
 * 4. Ability to complete tasks with decisions
 */

import { useState, useEffect } from 'react'

// Backend API URL from environment variable
const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

export default function Home() {
  // Form state for starting new workflow
  const [candidateName, setCandidateName] = useState('')
  const [yearsOfExperience, setYearsOfExperience] = useState(0)
  const [position, setPosition] = useState('')
  const [needsTechnicalInterview, setNeedsTechnicalInterview] = useState(false)

  // State for tasks, audit trail, and messages
  const [tasks, setTasks] = useState<any[]>([])
  const [auditTrail, setAuditTrail] = useState<any[]>([])
  const [message, setMessage] = useState('')
  const [loading, setLoading] = useState(false)

  /**
   * Deploy the workflow definition to Flowable
   * Only needs to be called once when first setting up
   */
  const deployWorkflow = async () => {
    setLoading(true)
    setMessage('')
    try {
      const response = await fetch(`${API_URL}/workflows/deploy`, {
        method: 'POST',
      })
      const data = await response.json()
      if (response.ok) {
        setMessage('✓ Workflow deployed successfully!')
      } else {
        setMessage(`✗ Error: ${data.detail}`)
      }
    } catch (error) {
      setMessage(`✗ Failed to deploy workflow: ${error}`)
    }
    setLoading(false)
  }

  /**
   * Start a new job interview workflow instance
   * Creates a new process for the candidate
   */
  const startWorkflow = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setMessage('')

    try {
      const response = await fetch(`${API_URL}/workflows/start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          candidateName,
          yearsOfExperience: parseInt(yearsOfExperience.toString()),
          position,
          needsTechnicalInterview,
        }),
      })
      const data = await response.json()

      if (response.ok) {
        setMessage(`✓ Workflow started for ${candidateName} (ID: ${data.processInstanceId})`)
        // Reset form
        setCandidateName('')
        setYearsOfExperience(0)
        setPosition('')
        setNeedsTechnicalInterview(false)
        // Refresh tasks and audit trail
        fetchTasks()
        fetchAuditTrail()
      } else {
        setMessage(`✗ Error: ${data.detail}`)
      }
    } catch (error) {
      setMessage(`✗ Failed to start workflow: ${error}`)
    }
    setLoading(false)
  }

  /**
   * Fetch all active user tasks waiting for completion
   */
  const fetchTasks = async () => {
    try {
      const response = await fetch(`${API_URL}/tasks`)
      const data = await response.json()
      setTasks(data.data || [])
    } catch (error) {
      console.error('Failed to fetch tasks:', error)
    }
  }

  /**
   * Fetch audit trail of all workflow instances
   */
  const fetchAuditTrail = async () => {
    try {
      const response = await fetch(`${API_URL}/audit-trail`)
      const data = await response.json()
      setAuditTrail(data.data || [])
    } catch (error) {
      console.error('Failed to fetch audit trail:', error)
    }
  }

  /**
   * Complete a user task with decision variables
   * This moves the workflow forward based on the decision
   */
  const completeTask = async (taskId: string, variables: Record<string, any>) => {
    setLoading(true)
    setMessage('')

    try {
      const response = await fetch(`${API_URL}/tasks/${taskId}/complete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ variables }),
      })
      const data = await response.json()

      if (response.ok) {
        setMessage('✓ Task completed successfully!')
        fetchTasks() // Refresh task list
        fetchAuditTrail() // Refresh audit trail
      } else {
        setMessage(`✗ Error: ${data.detail}`)
      }
    } catch (error) {
      setMessage(`✗ Failed to complete task: ${error}`)
    }
    setLoading(false)
  }

  // Fetch tasks and audit trail on component mount and every 5 seconds
  useEffect(() => {
    fetchTasks()
    fetchAuditTrail()
    const interval = setInterval(() => {
      fetchTasks()
      fetchAuditTrail()
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div>
      {/* Status message display */}
      {message && (
        <div style={{
          padding: '10px',
          marginBottom: '20px',
          borderRadius: '4px',
          backgroundColor: message.includes('✓') ? '#d4edda' : '#f8d7da',
          color: message.includes('✓') ? '#155724' : '#721c24',
          border: `1px solid ${message.includes('✓') ? '#c3e6cb' : '#f5c6cb'}`
        }}>
          {message}
        </div>
      )}

      {/* Deploy workflow button */}
      <div style={{ marginBottom: '30px' }}>
        <button
          onClick={deployWorkflow}
          disabled={loading}
          style={{
            padding: '10px 20px',
            backgroundColor: '#28a745',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: loading ? 'not-allowed' : 'pointer',
            fontSize: '14px'
          }}
        >
          {loading ? 'Deploying...' : 'Deploy Workflow Definition'}
        </button>
        <span style={{ marginLeft: '10px', fontSize: '14px', color: '#666' }}>
          (Click once when first starting the app)
        </span>
      </div>

      {/* Form to start new workflow */}
      <div style={{
        backgroundColor: 'white',
        padding: '20px',
        borderRadius: '8px',
        marginBottom: '30px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <h2 style={{ marginTop: 0 }}>Start New Interview Process</h2>
        <form onSubmit={startWorkflow}>
          <div style={{ marginBottom: '15px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
              Candidate Name:
            </label>
            <input
              type="text"
              value={candidateName}
              onChange={(e) => setCandidateName(e.target.value)}
              required
              style={{
                width: '100%',
                padding: '8px',
                border: '1px solid #ddd',
                borderRadius: '4px',
                fontSize: '14px'
              }}
            />
          </div>

          <div style={{ marginBottom: '15px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
              Years of Experience:
            </label>
            <input
              type="number"
              value={yearsOfExperience}
              onChange={(e) => setYearsOfExperience(parseInt(e.target.value) || 0)}
              required
              min="0"
              style={{
                width: '100%',
                padding: '8px',
                border: '1px solid #ddd',
                borderRadius: '4px',
                fontSize: '14px'
              }}
            />
          </div>

          <div style={{ marginBottom: '15px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
              Position:
            </label>
            <input
              type="text"
              value={position}
              onChange={(e) => setPosition(e.target.value)}
              required
              style={{
                width: '100%',
                padding: '8px',
                border: '1px solid #ddd',
                borderRadius: '4px',
                fontSize: '14px'
              }}
            />
          </div>

          <div style={{ marginBottom: '15px' }}>
            <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={needsTechnicalInterview}
                onChange={(e) => setNeedsTechnicalInterview(e.target.checked)}
                style={{ marginRight: '8px' }}
              />
              <span style={{ fontWeight: 'bold' }}>Requires Technical Interview</span>
            </label>
          </div>

          <button
            type="submit"
            disabled={loading}
            style={{
              padding: '10px 30px',
              backgroundColor: '#0070f3',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: loading ? 'not-allowed' : 'pointer',
              fontSize: '16px',
              fontWeight: 'bold'
            }}
          >
            {loading ? 'Starting...' : 'Start Interview Process'}
          </button>
        </form>
      </div>

      {/* List of active user tasks */}
      <div style={{
        backgroundColor: 'white',
        padding: '20px',
        borderRadius: '8px',
        marginBottom: '30px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <h2 style={{ marginTop: 0 }}>Active User Tasks ({tasks.length})</h2>

        {tasks.length === 0 ? (
          <p style={{ color: '#666' }}>No active tasks. Start a workflow to see tasks appear here.</p>
        ) : (
          <div>
            {tasks.map((task) => (
              <TaskItem
                key={task.id}
                task={task}
                onComplete={completeTask}
                loading={loading}
              />
            ))}
          </div>
        )}
      </div>

      {/* Audit Trail Section */}
      <div style={{
        backgroundColor: 'white',
        padding: '20px',
        borderRadius: '8px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <h2 style={{ marginTop: 0 }}>Workflow Audit Trail ({auditTrail.length})</h2>
        <p style={{ color: '#666', fontSize: '14px', marginBottom: '20px' }}>
          History of all workflow instances showing steps completed and decisions made
        </p>

        {auditTrail.length === 0 ? (
          <p style={{ color: '#666' }}>No workflow history yet. Start a workflow to see its audit trail here.</p>
        ) : (
          <div>
            {auditTrail.map((instance) => (
              <AuditTrailItem key={instance.processInstanceId} instance={instance} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

/**
 * Component to display a single workflow instance's audit trail
 */
function AuditTrailItem({ instance }: { instance: any }) {
  const [expanded, setExpanded] = useState(false)

  // Format timestamp
  const formatTime = (timestamp: string) => {
    if (!timestamp) return 'N/A'
    return new Date(timestamp).toLocaleString()
  }

  // Calculate duration in readable format
  const formatDuration = (millis: number) => {
    if (!millis) return 'In progress'
    const seconds = Math.floor(millis / 1000)
    const minutes = Math.floor(seconds / 60)
    const hours = Math.floor(minutes / 60)
    if (hours > 0) return `${hours}h ${minutes % 60}m`
    if (minutes > 0) return `${minutes}m ${seconds % 60}s`
    return `${seconds}s`
  }

  // Determine status and color
  const isCompleted = instance.endTime !== null
  const statusColor = isCompleted ? '#28a745' : '#ffc107'
  const statusText = isCompleted ? 'Completed' : 'Active'

  // Get candidate name from variables
  const candidateName = instance.variables?.candidateName || 'Unknown'
  const position = instance.variables?.position || 'Unknown'
  const yearsOfExperience = instance.variables?.yearsOfExperience || 0

  // Filter activities to show only meaningful steps (exclude start/end events and gateways)
  const meaningfulActivities = instance.activities.filter((activity: any) =>
    activity.activityType === 'userTask' ||
    activity.activityType === 'startEvent' ||
    activity.activityType === 'endEvent'
  )

  return (
    <div style={{
      border: '1px solid #ddd',
      borderRadius: '4px',
      padding: '15px',
      marginBottom: '15px',
      backgroundColor: '#fafafa'
    }}>
      {/* Header with expand/collapse */}
      <div
        onClick={() => setExpanded(!expanded)}
        style={{ cursor: 'pointer', userSelect: 'none' }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h3 style={{ margin: 0, color: '#333' }}>
              {expanded ? '▼' : '▶'} {candidateName} - {position}
            </h3>
          </div>
          <div style={{
            padding: '4px 12px',
            borderRadius: '12px',
            backgroundColor: statusColor,
            color: 'white',
            fontSize: '12px',
            fontWeight: 'bold'
          }}>
            {statusText}
          </div>
        </div>

        <div style={{ marginTop: '8px', fontSize: '14px', color: '#666' }}>
          <span><strong>Started:</strong> {formatTime(instance.startTime)}</span>
          <span style={{ marginLeft: '20px' }}><strong>Duration:</strong> {formatDuration(instance.duration)}</span>
          <span style={{ marginLeft: '20px' }}><strong>Experience:</strong> {yearsOfExperience} years</span>
        </div>
      </div>

      {/* Expanded details */}
      {expanded && (
        <div style={{ marginTop: '20px', paddingTop: '15px', borderTop: '1px solid #ddd' }}>
          {/* Process variables */}
          <div style={{ marginBottom: '15px' }}>
            <h4 style={{ margin: '0 0 10px 0', color: '#0070f3' }}>Candidate Information</h4>
            <div style={{ fontSize: '14px' }}>
              {Object.entries(instance.variables).map(([key, value]) => (
                <div key={key} style={{ marginBottom: '5px' }}>
                  <strong>{key}:</strong> {String(value)}
                </div>
              ))}
            </div>
          </div>

          {/* Activity timeline */}
          <div>
            <h4 style={{ margin: '0 0 10px 0', color: '#0070f3' }}>Process Steps</h4>
            <div style={{ position: 'relative', paddingLeft: '30px' }}>
              {/* Timeline line */}
              <div style={{
                position: 'absolute',
                left: '11px',
                top: '10px',
                bottom: '10px',
                width: '2px',
                backgroundColor: '#ddd'
              }} />

              {meaningfulActivities.map((activity: any, index: number) => {
                const isLast = index === meaningfulActivities.length - 1
                const activityColor = activity.endTime ? '#28a745' : '#6c757d'

                return (
                  <div key={activity.id} style={{ position: 'relative', marginBottom: '15px' }}>
                    {/* Timeline dot */}
                    <div style={{
                      position: 'absolute',
                      left: '-26px',
                      top: '5px',
                      width: '12px',
                      height: '12px',
                      borderRadius: '50%',
                      backgroundColor: activityColor,
                      border: '2px solid white',
                      boxShadow: '0 0 0 2px #ddd'
                    }} />

                    <div style={{
                      padding: '8px 12px',
                      backgroundColor: 'white',
                      border: '1px solid #ddd',
                      borderRadius: '4px',
                      fontSize: '13px'
                    }}>
                      <div style={{ fontWeight: 'bold', marginBottom: '4px' }}>
                        {activity.activityName || activity.activityId}
                      </div>
                      <div style={{ color: '#666', fontSize: '12px' }}>
                        <div><strong>Type:</strong> {activity.activityType}</div>
                        <div><strong>Started:</strong> {formatTime(activity.startTime)}</div>
                        {activity.endTime && (
                          <div><strong>Completed:</strong> {formatTime(activity.endTime)}</div>
                        )}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

/**
 * Component to display and interact with a single user task
 */
function TaskItem({
  task,
  onComplete,
  loading
}: {
  task: any
  onComplete: (taskId: string, variables: Record<string, any>) => void
  loading: boolean
}) {
  // Determine which form to show based on task name
  const renderTaskForm = () => {
    // HR Review task
    if (task.name === 'HR Review Application') {
      return (
        <div>
          <button
            onClick={() => onComplete(task.id, { hrApproved: true })}
            disabled={loading}
            style={buttonStyle('#28a745')}
          >
            Approve
          </button>
          <button
            onClick={() => onComplete(task.id, { hrApproved: false })}
            disabled={loading}
            style={{ ...buttonStyle('#dc3545'), marginLeft: '10px' }}
          >
            Reject
          </button>
        </div>
      )
    }

    // Technical Interview task
    if (task.name === 'Conduct Technical Interview') {
      return (
        <div>
          <button
            onClick={() => onComplete(task.id, { technicalPassed: true })}
            disabled={loading}
            style={buttonStyle('#28a745')}
          >
            Pass
          </button>
          <button
            onClick={() => onComplete(task.id, { technicalPassed: false })}
            disabled={loading}
            style={{ ...buttonStyle('#dc3545'), marginLeft: '10px' }}
          >
            Fail
          </button>
        </div>
      )
    }

    // Final Decision task
    if (task.name === 'Make Final Hiring Decision') {
      return (
        <div>
          <button
            onClick={() => onComplete(task.id, { hired: true })}
            disabled={loading}
            style={buttonStyle('#28a745')}
          >
            Hire
          </button>
          <button
            onClick={() => onComplete(task.id, { hired: false })}
            disabled={loading}
            style={{ ...buttonStyle('#dc3545'), marginLeft: '10px' }}
          >
            Reject
          </button>
        </div>
      )
    }

    return <p style={{ color: '#666' }}>Unknown task type</p>
  }

  return (
    <div style={{
      border: '1px solid #ddd',
      borderRadius: '4px',
      padding: '15px',
      marginBottom: '15px',
      backgroundColor: '#f9f9f9'
    }}>
      <h3 style={{ marginTop: 0, color: '#0070f3' }}>{task.name}</h3>
      <p style={{ margin: '5px 0' }}>
        <strong>Task ID:</strong> {task.id}
      </p>
      <p style={{ margin: '5px 0' }}>
        <strong>Process Instance:</strong> {task.processInstanceId}
      </p>
      <div style={{ marginTop: '15px' }}>
        {renderTaskForm()}
      </div>
    </div>
  )
}

/**
 * Helper function to generate button styles
 */
function buttonStyle(bgColor: string) {
  return {
    padding: '8px 20px',
    backgroundColor: bgColor,
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold' as const,
  }
}
