/**
 * Root layout component for Next.js app
 * Provides basic HTML structure and styling
 */

import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Job Interview Workflow',
  description: 'Flowable workflow demo for job interview process',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body style={{
        margin: 0,
        padding: '20px',
        fontFamily: 'system-ui, -apple-system, sans-serif',
        backgroundColor: '#f5f5f5'
      }}>
        {/* Main container with max width for readability */}
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <h1 style={{
            color: '#333',
            borderBottom: '2px solid #0070f3',
            paddingBottom: '10px'
          }}>
            Job Interview Workflow System
          </h1>
          {children}
        </div>
      </body>
    </html>
  )
}
