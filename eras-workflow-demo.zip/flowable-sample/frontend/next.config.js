/** @type {import('next').NextConfig} */
const nextConfig = {
  // Disable strict mode for development simplicity
  reactStrictMode: true,
}

module.exports = nextConfig
